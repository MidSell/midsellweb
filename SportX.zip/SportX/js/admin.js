/* ============================================================
   SportX — панель администратора
   Дашборд, заказы, товары, категории, бренды, промокоды, пользователи, отзывы, экспорт
   ============================================================ */
(function (S) {
  'use strict';
  const { $, $$, esc, formatPrice, toast, modal, closeModal, confirmModal,
          auth, route, go, breadcrumbs, state, read, write, uid } = S;

  /* ---------- Layout ---------- */
  function renderAdminMenu(active) {
    return `
      <nav class="account__menu">
        <a href="#/admin" class="${active === 'dash' ? 'active' : ''}">📊 Дашборд</a>
        <a href="#/admin/orders" class="${active === 'orders' ? 'active' : ''}">📦 Заказы</a>
        <a href="#/admin/products" class="${active === 'products' ? 'active' : ''}">🏷️ Товары</a>
        <a href="#/admin/categories" class="${active === 'categories' ? 'active' : ''}">📂 Категории</a>
        <a href="#/admin/brands" class="${active === 'brands' ? 'active' : ''}">🏢 Бренды</a>
        <a href="#/admin/promos" class="${active === 'promos' ? 'active' : ''}">🎟️ Промокоды</a>
        <a href="#/admin/users" class="${active === 'users' ? 'active' : ''}">👥 Пользователи</a>
        <a href="#/admin/reviews" class="${active === 'reviews' ? 'active' : ''}">⭐ Отзывы</a>
        <a href="#" id="adminLogout" style="color:var(--danger)">🚪 Выйти</a>
      </nav>`;
  }

  function adminLayout(active, content) {
    return `
      <div class="container">
        ${breadcrumbs([{ label: 'Главная', href: '#/' }, { label: 'Админка', href: '' }])}
        <h1>Панель администратора</h1>
        <div class="account">
          ${renderAdminMenu(active)}
          <div class="account__content">${content}</div>
        </div>
      </div>`;
  }

  function bindAdminLayout() {
    const out = $('#adminLogout');
    if (out) out.addEventListener('click', e => { e.preventDefault(); auth.logout(); });
  }

  function requireAdmin() {
    if (!state.user) { go('/login'); return false; }
    if (state.user.role !== 'admin') { toast('Доступ только для администратора', 'error'); go('/'); return false; }
    return true;
  }

  /* ---------- Экспорт CSV ---------- */
  function exportCSV(rows, filename) {
    if (!rows.length) { toast('Нет данных для экспорта', 'error'); return; }
    const keys = Object.keys(rows[0]);
    const lines = [keys.join(';')];
    rows.forEach(r => lines.push(keys.map(k => String(r[k] ?? '').replace(/;/g, ',')).join(';')));
    const blob = new Blob(['\uFEFF' + lines.join('\n')], { type: 'text/csv;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = filename + '_' + new Date().toISOString().slice(0, 10) + '.csv';
    a.click();
    toast('Файл выгружен', 'success');
  }

  /* ============================================================
     ДАШБОРД
     ============================================================ */
  route('/admin', (app) => {
    if (!requireAdmin()) return;
    const orders = state.orders;
    const paid = orders.filter(o => o.status !== 'cancelled');
    const revenue = paid.reduce((s, o) => s + o.total, 0);
    const avg = paid.length ? Math.round(revenue / paid.length) : 0;
    const conversion = 3.8; // демо
    const topProducts = {};
    paid.forEach(o => o.items.forEach(it => {
      topProducts[it.productId] = (topProducts[it.productId] || 0) + it.qty;
    }));
    const top = Object.entries(topProducts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([id, qty]) => ({ p: state.products.find(x => x.id === id), qty }))
      .filter(x => x.p);

    const statusCounts = orders.reduce((acc, o) => {
      acc[o.status] = (acc[o.status] || 0) + 1;
      return acc;
    }, {});

    app.innerHTML = adminLayout('dash', `
      <div class="stats">
        <div class="stat"><div class="stat__lbl">Выручка</div><div class="stat__val">${formatPrice(revenue)}</div><div class="stat__delta up">▲ 12%</div></div>
        <div class="stat"><div class="stat__lbl">Заказов</div><div class="stat__val">${orders.length}</div><div class="stat__delta up">▲ 8%</div></div>
        <div class="stat"><div class="stat__lbl">Средний чек</div><div class="stat__val">${formatPrice(avg)}</div><div class="stat__delta up">▲ 3%</div></div>
        <div class="stat"><div class="stat__lbl">Конверсия</div><div class="stat__val">${conversion}%</div><div class="stat__delta down">▼ 0.4%</div></div>
      </div>

      <h3>Воронка заказов</h3>
      <div class="products" style="margin-top:12px">
        ${['new','packing','shipped','delivered','cancelled','returned'].map(s => `
          <div class="stat">
            <div class="stat__lbl">${s}</div>
            <div class="stat__val">${statusCounts[s] || 0}</div>
          </div>
        `).join('')}
      </div>

      <h3 style="margin-top:24px">Топ товаров</h3>
      <div class="table-wrap" style="margin-top:12px">
        <table>
          <thead><tr><th>#</th><th>Товар</th><th>Продано</th><th>Остаток</th></tr></thead>
          <tbody>
            ${top.map((t, i) => `
              <tr>
                <td>${i + 1}</td>
                <td>${esc(t.p.name)}</td>
                <td>${t.qty}</td>
                <td>${t.p.stock}</td>
              </tr>`).join('')}
          </tbody>
        </table>
      </div>

      <div style="display:flex;gap:10px;margin-top:20px;flex-wrap:wrap">
        <button class="btn btn--primary" id="expOrders">Экспорт заказов (CSV)</button>
        <button class="btn btn--outline" id="expProducts">Экспорт товаров (CSV)</button>
        <button class="btn btn--danger" id="resetDemo">Сбросить демо-данные</button>
      </div>
    `);
    bindAdminLayout();

    $('#expOrders').addEventListener('click', () => exportCSV(
      orders.map(o => ({
        id: o.id, date: new Date(o.date).toLocaleString('ru-RU'),
        status: o.status, total: o.total, payment: o.payment, delivery: o.delivery
      })), 'sportx_orders'));

    $('#expProducts').addEventListener('click', () => exportCSV(
      state.products.map(p => ({
        id: p.id, name: p.name, category: p.category, brand: p.brand,
        price: p.price, stock: p.stock, rating: p.rating
      })), 'sportx_products'));

    $('#resetDemo').addEventListener('click', () => {
      confirmModal('Сбросить все демо-данные? Это удалит заказы, отзывы, пользователей и вернёт初始 каталог.', () => {
        Object.keys(localStorage).filter(k => k.startsWith('sportx_')).forEach(k => localStorage.removeItem(k));
        location.reload();
      });
    });
  });

  /* ============================================================
     ЗАКАЗЫ
     ============================================================ */
  route('/admin/orders', (app, params) => {
    if (!requireAdmin()) return;
    const q = params.q || '';
    const status = params.status || '';
    const page = +params.page || 1;
    const perPage = 10;

    let orders = state.orders.slice().sort((a, b) => b.date - a.date);
    if (q) orders = orders.filter(o => o.id.toLowerCase().includes(q.toLowerCase()));
    if (status) orders = orders.filter(o => o.status === status);

    const totalPages = Math.ceil(orders.length / perPage);
    const pageItems = orders.slice((page - 1) * perPage, page * perPage);

    const statusMap = {
      new: 'Новый', packing: 'Собирается', shipped: 'Отправлен',
      delivered: 'Доставлен', cancelled: 'Отменён', returned: 'Возврат'
    };

    app.innerHTML = adminLayout('orders', `
      <div class="toolbar" style="margin-bottom:14px">
        <input type="search" id="oQ" placeholder="Поиск по номеру…" value="${esc(q)}"
          style="padding:10px 14px;border:1px solid var(--border);border-radius:8px;min-width:220px">
        <select id="oStatus" style="padding:10px 14px;border:1px solid var(--border);border-radius:8px">
          <option value="">Все статусы</option>
          ${Object.entries(statusMap).map(([k, v]) => `<option value="${k}" ${status === k ? 'selected' : ''}>${v}</option>`).join('')}
        </select>
        <button class="btn btn--outline btn--sm" id="oExport">Экспорт CSV</button>
      </div>

      <div class="table-wrap">
        <table>
          <thead>
            <tr><th>Номер</th><th>Дата</th><th>Клиент</th><th>Сумма</th><th>Оплата</th><th>Статус</th><th></th></tr>
          </thead>
          <tbody>
            ${pageItems.map(o => `
              <tr>
                <td>${o.id}</td>
                <td>${new Date(o.date).toLocaleDateString('ru-RU')}</td>
                <td>${esc((o.customer && o.customer.name) || '')}</td>
                <td>${formatPrice(o.total)}</td>
                <td>${esc(o.payment)}</td>
                <td><span class="status status--${o.status}">${statusMap[o.status]}</span></td>
                <td><button class="btn btn--sm btn--outline" data-view="${o.id}">Открыть</button></td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>

      ${totalPages > 1 ? `
        <div class="pagination">
          ${Array.from({ length: totalPages }, (_, i) => i + 1).map(n => `
            <button class="${n === page ? 'active' : ''}" data-page="${n}">${n}</button>
          `).join('')}
        </div>` : ''}
    `);
    bindAdminLayout();

    $('#oQ').addEventListener('input', S.debounce(e => {
      const p = new URLSearchParams(location.hash.split('?')[1] || '');
      if (e.target.value) p.set('q', e.target.value); else p.delete('q');
      p.set('page', 1);
      location.hash = '#/admin/orders?' + p.toString();
    }, 350));

    $('#oStatus').addEventListener('change', e => {
      const p = new URLSearchParams(location.hash.split('?')[1] || '');
      if (e.target.value) p.set('status', e.target.value); else p.delete('status');
      p.set('page', 1);
      location.hash = '#/admin/orders?' + p.toString();
    });

    $('#oExport').addEventListener('click', () => exportCSV(
      orders.map(o => ({
        id: o.id, date: new Date(o.date).toLocaleString('ru-RU'),
        status: o.status, total: o.total, payment: o.payment, delivery: o.delivery,
        customer: (o.customer && o.customer.name) || ''
      })), 'sportx_orders'));

    app.querySelectorAll('[data-page]').forEach(b => b.addEventListener('click', () => {
      const p = new URLSearchParams(location.hash.split('?')[1] || '');
      p.set('page', b.dataset.page);
      location.hash = '#/admin/orders?' + p.toString();
    }));

    app.querySelectorAll('[data-view]').forEach(b => b.addEventListener('click', () => {
      const o = state.orders.find(x => x.id === b.dataset.view);
      modal(`
        <h3>Заказ ${o.id}</h3>
        <p style="color:var(--text-2);font-size:13px">${new Date(o.date).toLocaleString('ru-RU')}</p>

        <h4 style="margin-top:14px">Клиент</h4>
        <p>${esc((o.customer && o.customer.name) || '—')}<br>
        ${esc((o.customer && o.customer.phone) || '')}<br>
        ${esc((o.customer && o.customer.email) || '')}</p>

        <h4 style="margin-top:14px">Состав</h4>
        ${o.items.map(it => `
          <div class="summary__row"><span>${esc(it.name)} × ${it.qty}</span><span>${formatPrice(it.price * it.qty)}</span></div>
        `).join('')}

        <h4 style="margin-top:14px">Доставка</h4>
        <p>${esc(o.address || 'Самовывоз')}</p>

        <h4 style="margin-top:14px">Статус</h4>
        <select id="statusSel" style="width:100%;padding:10px;border:2px solid var(--border);border-radius:10px">
          ${Object.entries(statusMap).map(([k, v]) => `<option value="${k}" ${o.status === k ? 'selected' : ''}>${v}</option>`).join('')}
        </select>

        <div style="display:flex;gap:10px;margin-top:16px">
          <button class="btn btn--primary" id="saveStatus">Сохранить</button>
          <button class="btn btn--outline" data-close>Закрыть</button>
        </div>
      `, {
        onOpen(root) {
          root.querySelector('#saveStatus').addEventListener('click', () => {
            o.status = root.querySelector('#statusSel').value;
            write('sportx_orders', state.orders);
            closeModal();
            toast('Статус обновлён', 'success');
            S.navigate();
          });
        }
      });
    }));
  });

  /* ============================================================
     ТОВАРЫ
     ============================================================ */
  route('/admin/products', (app, params) => {
    if (!requireAdmin()) return;
    const q = (params.q || '').toLowerCase();
    const cat = params.cat || '';

    let items = state.products.slice();
    if (q) items = items.filter(p => p.name.toLowerCase().includes(q) || p.id.includes(q));
    if (cat) items = items.filter(p => p.category === cat);

    app.innerHTML = adminLayout('products', `
      <div class="toolbar" style="margin-bottom:14px">
        <input type="search" id="pQ" placeholder="Поиск…" value="${esc(params.q || '')}"
          style="padding:10px 14px;border:1px solid var(--border);border-radius:8px;min-width:220px">
        <select id="pCat" style="padding:10px 14px;border:1px solid var(--border);border-radius:8px">
          <option value="">Все категории</option>
          ${state.categories.map(c => `<option value="${c.id}" ${cat === c.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}
        </select>
        <button class="btn btn--primary btn--sm" id="pAdd">+ Добавить товар</button>
        <button class="btn btn--outline btn--sm" id="pExport">Экспорт CSV</button>
      </div>

      <div class="table-wrap">
        <table>
          <thead><tr><th>ID</th><th>Название</th><th>Категория</th><th>Цена</th><th>Остаток</th><th>Действия</th></tr></thead>
          <tbody>
            ${items.map(p => `
              <tr>
                <td>${p.id}</td>
                <td>${esc(p.name)}</td>
                <td>${esc((state.categories.find(c => c.id === p.category) || {}).name || p.category)}</td>
                <td>${formatPrice(p.price)}</td>
                <td>${p.stock}</td>
                <td>
                  <button class="btn btn--sm btn--outline" data-edit="${p.id}">✎</button>
                  <button class="btn btn--sm btn--danger" data-del="${p.id}">✕</button>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `);
    bindAdminLayout();

    $('#pQ').addEventListener('input', S.debounce(e => {
      const p = new URLSearchParams(location.hash.split('?')[1] || '');
      if (e.target.value) p.set('q', e.target.value); else p.delete('q');
      location.hash = '#/admin/products?' + p.toString();
    }, 350));
    $('#pCat').addEventListener('change', e => {
      const p = new URLSearchParams(location.hash.split('?')[1] || '');
      if (e.target.value) p.set('cat', e.target.value); else p.delete('cat');
      location.hash = '#/admin/products?' + p.toString();
    });
    $('#pExport').addEventListener('click', () => exportCSV(items, 'sportx_products'));

    $('#pAdd').addEventListener('click', () => openProductForm(null, app));
    app.querySelectorAll('[data-edit]').forEach(b => b.addEventListener('click', () => {
      openProductForm(state.products.find(x => x.id === b.dataset.edit), app);
    }));
    app.querySelectorAll('[data-del]').forEach(b => b.addEventListener('click', () => {
      confirmModal('Удалить товар?', () => {
        state.products = state.products.filter(p => p.id !== b.dataset.del);
        write('sportx_products', state.products);
        toast('Товар удалён', 'info');
        S.navigate();
      });
    }));
  });

  function openProductForm(p, root) {
    const isNew = !p;
    p = p || {
      id: uid('p'), name: '', category: state.categories[0].id, brand: state.brands[0],
      price: 0, oldPrice: null, rating: 4.5, reviewsCount: 0,
      sizes: [], colors: [], images: ['assets/images/placeholder.jpg'],
      description: '', specs: {}, stock: 0, isNew: false, isHit: false, discount: 0
    };

    modal(`
      <h3>${isNew ? 'Новый товар' : 'Редактирование товара'}</h3>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:12px">
        <div class="field" style="grid-column:1/-1"><label>Название</label><input id="fName" value="${esc(p.name)}"></div>
        <div class="field"><label>Категория</label>
          <select id="fCat">${state.categories.map(c => `<option value="${c.id}" ${p.category === c.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select>
        </div>
        <div class="field"><label>Бренд</label>
          <select id="fBrand">${state.brands.map(b => `<option ${p.brand === b ? 'selected' : ''}>${esc(b)}</option>`).join('')}</select>
        </div>
        <div class="field"><label>Цена, ₽</label><input type="number" id="fPrice" value="${p.price}"></div>
        <div class="field"><label>Старая цена</label><input type="number" id="fOldPrice" value="${p.oldPrice || ''}"></div>
        <div class="field"><label>Остаток, шт</label><input type="number" id="fStock" value="${p.stock}"></div>
        <div class="field"><label>Скидка, %</label><input type="number" id="fDisc" value="${p.discount || 0}"></div>
        <div class="field" style="grid-column:1/-1"><label>Размеры (через запятую)</label><input id="fSizes" value="${(p.sizes || []).join(', ')}"></div>
        <div class="field" style="grid-column:1/-1"><label>Цвета (через запятую)</label><input id="fColors" value="${(p.colors || []).join(', ')}"></div>
        <div class="field" style="grid-column:1/-1"><label>Описание</label><textarea id="fDesc">${esc(p.description)}</textarea></div>
        <label style="grid-column:1/-1;font-size:14px"><input type="checkbox" id="fHit" ${p.isHit ? 'checked' : ''}> Хит продаж</label>
        <label style="grid-column:1/-1;font-size:14px"><input type="checkbox" id="fNew" ${p.isNew ? 'checked' : ''}> Новинка</label>
      </div>
      <div style="display:flex;gap:10px;margin-top:16px">
        <button class="btn btn--primary" id="pSave">Сохранить</button>
        <button class="btn btn--outline" data-close>Отмена</button>
      </div>
    `, {
      onOpen(root) {
        root.querySelector('#pSave').addEventListener('click', () => {
          p.name = root.querySelector('#fName').value.trim();
          p.category = root.querySelector('#fCat').value;
          p.brand = root.querySelector('#fBrand').value;
          p.price = +root.querySelector('#fPrice').value || 0;
          p.oldPrice = +root.querySelector('#fOldPrice').value || null;
          p.stock = +root.querySelector('#fStock').value || 0;
          p.discount = +root.querySelector('#fDisc').value || 0;
          p.sizes = root.querySelector('#fSizes').value.split(',').map(s => s.trim()).filter(Boolean);
          p.colors = root.querySelector('#fColors').value.split(',').map(s => s.trim()).filter(Boolean);
          p.description = root.querySelector('#fDesc').value.trim();
          p.isHit = root.querySelector('#fHit').checked;
          p.isNew = root.querySelector('#fNew').checked;
          if (!p.name) { toast('Введите название', 'error'); return; }
          if (isNew) state.products.push(p);
          write('sportx_products', state.products);
          closeModal();
          toast('Товар сохранён', 'success');
          S.navigate();
        });
      }
    });
  }

  /* ============================================================
     КАТЕГОРИИ
     ============================================================ */
  route('/admin/categories', (app) => {
    if (!requireAdmin()) return;
    app.innerHTML = adminLayout('categories', `
      <button class="btn btn--primary btn--sm" id="cAdd" style="margin-bottom:14px">+ Категория</button>
      <div class="table-wrap">
        <table>
          <thead><tr><th>ID</th><th>Название</th><th>Slug</th><th>Иконка</th><th></th></tr></thead>
          <tbody>
            ${state.categories.map(c => `
              <tr>
                <td>${c.id}</td><td>${esc(c.name)}</td><td>${esc(c.slug)}</td><td>${c.icon}</td>
                <td>
                  <button class="btn btn--sm btn--outline" data-edit="${c.id}">✎</button>
                  <button class="btn btn--sm btn--danger" data-del="${c.id}">✕</button>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `);
    bindAdminLayout();

    $('#cAdd').addEventListener('click', () => openCatForm(null));
    app.querySelectorAll('[data-edit]').forEach(b => b.addEventListener('click', () => {
      openCatForm(state.categories.find(x => x.id === b.dataset.edit));
    }));
    app.querySelectorAll('[data-del]').forEach(b => b.addEventListener('click', () => {
      confirmModal('Удалить категорию?', () => {
        state.categories = state.categories.filter(c => c.id !== b.dataset.del);
        S.navigate();
      });
    }));
  });

  function openCatForm(c) {
    const isNew = !c;
    c = c || { id: '', name: '', slug: '', icon: '🏷️' };
    modal(`
      <h3>${isNew ? 'Новая категория' : 'Категория'}</h3>
      <div class="field"><label>ID (латиница)</label><input id="cfId" value="${esc(c.id)}" ${!isNew ? 'disabled' : ''}></div>
      <div class="field" style="margin-top:10px"><label>Название</label><input id="cfName" value="${esc(c.name)}"></div>
      <div class="field" style="margin-top:10px"><label>Slug</label><input id="cfSlug" value="${esc(c.slug)}"></div>
      <div class="field" style="margin-top:10px"><label>Иконка (эмодзи)</label><input id="cfIcon" value="${esc(c.icon)}"></div>
      <div style="display:flex;gap:10px;margin-top:16px">
        <button class="btn btn--primary" id="cfSave">Сохранить</button>
        <button class="btn btn--outline" data-close>Отмена</button>
      </div>
    `, {
      onOpen(root) {
        root.querySelector('#cfSave').addEventListener('click', () => {
          const obj = {
            id: root.querySelector('#cfId').value.trim() || c.id,
            name: root.querySelector('#cfName').value.trim(),
            slug: root.querySelector('#cfSlug').value.trim(),
            icon: root.querySelector('#cfIcon').value.trim() || '🏷️'
          };
          if (!obj.name) { toast('Введите название', 'error'); return; }
          if (isNew) state.categories.push(obj);
          else Object.assign(c, obj);
          closeModal();
          toast('Сохранено', 'success');
          S.navigate();
        });
      }
    });
  }

  /* ============================================================
     БРЕНДЫ
     ============================================================ */
  route('/admin/brands', (app) => {
    if (!requireAdmin()) return;
    app.innerHTML = adminLayout('brands', `
      <button class="btn btn--primary btn--sm" id="bAdd" style="margin-bottom:14px">+ Бренд</button>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Название</th><th>Товаров</th><th></th></tr></thead>
          <tbody>
            ${state.brands.map(b => `
              <tr>
                <td>${esc(b)}</td>
                <td>${state.products.filter(p => p.brand === b).length}</td>
                <td><button class="btn btn--sm btn--danger" data-del="${esc(b)}">✕</button></td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `);
    bindAdminLayout();

    $('#bAdd').addEventListener('click', () => {
      modal(`
        <h3>Новый бренд</h3>
        <div class="field"><label>Название</label><input id="bName"></div>
        <button class="btn btn--primary btn--block" id="bSave" style="margin-top:16px">Добавить</button>
      `, {
        onOpen(root) {
          root.querySelector('#bSave').addEventListener('click', () => {
            const n = root.querySelector('#bName').value.trim();
            if (!n) return;
            if (!state.brands.includes(n)) state.brands.push(n);
            closeModal();
            toast('Бренд добавлен', 'success');
            S.navigate();
          });
        }
      });
    });
    app.querySelectorAll('[data-del]').forEach(b => b.addEventListener('click', () => {
      confirmModal('Удалить бренд?', () => {
        state.brands = state.brands.filter(x => x !== b.dataset.del);
        S.navigate();
      });
    }));
  });

  /* ============================================================
     ПРОМОКОДЫ
     ============================================================ */
  route('/admin/promos', (app) => {
    if (!requireAdmin()) return;
    const promos = state.promos;
    app.innerHTML = adminLayout('promos', `
      <button class="btn btn--primary btn--sm" id="prAdd" style="margin-bottom:14px">+ Промокод</button>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Код</th><th>Тип</th><th>Значение</th><th>Мин. сумма</th><th>Активен</th><th></th></tr></thead>
          <tbody>
            ${Object.entries(promos).map(([code, p]) => `
              <tr>
                <td><b>${esc(code)}</b></td>
                <td>${p.type === 'percent' ? 'Скидка %' : p.type === 'delivery' ? 'Бесплатная доставка' : p.type}</td>
                <td>${p.type === 'percent' ? p.value + '%' : '—'}</td>
                <td>${p.min ? formatPrice(p.min) : '—'}</td>
                <td>${p.active ? '✅' : '❌'}</td>
                <td>
                  <button class="btn btn--sm btn--outline" data-edit="${esc(code)}">✎</button>
                  <button class="btn btn--sm btn--danger" data-del="${esc(code)}">✕</button>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `);
    bindAdminLayout();

    $('#prAdd').addEventListener('click', () => openPromoForm(null));
    app.querySelectorAll('[data-edit]').forEach(b => b.addEventListener('click', () => openPromoForm(b.dataset.edit)));
    app.querySelectorAll('[data-del]').forEach(b => b.addEventListener('click', () => {
      confirmModal('Удалить промокод?', () => {
        delete state.promos[b.dataset.del];
        write('sportx_promos', state.promos);
        S.navigate();
      });
    }));
  });

  function openPromoForm(code) {
    const isNew = !code;
    const p = isNew ? { type: 'percent', value: 10, min: 0, active: true } : state.promos[code];
    modal(`
      <h3>${isNew ? 'Новый промокод' : 'Промокод ' + code}</h3>
      <div class="field"><label>Код</label><input id="pcCode" value="${esc(code || '')}" ${!isNew ? 'disabled' : ''}></div>
      <div class="field" style="margin-top:10px"><label>Тип</label>
        <select id="pcType">
          <option value="percent" ${p.type === 'percent' ? 'selected' : ''}>Скидка %</option>
          <option value="delivery" ${p.type === 'delivery' ? 'selected' : ''}>Бесплатная доставка</option>
        </select>
      </div>
      <div class="field" style="margin-top:10px"><label>Значение</label><input type="number" id="pcVal" value="${p.value}"></div>
      <div class="field" style="margin-top:10px"><label>Мин. сумма заказа</label><input type="number" id="pcMin" value="${p.min}"></div>
      <label style="font-size:14px;margin-top:10px"><input type="checkbox" id="pcActive" ${p.active ? 'checked' : ''}> Активен</label>
      <div style="display:flex;gap:10px;margin-top:16px">
        <button class="btn btn--primary" id="pcSave">Сохранить</button>
        <button class="btn btn--outline" data-close>Отмена</button>
      </div>
    `, {
      onOpen(root) {
        root.querySelector('#pcSave').addEventListener('click', () => {
          const newCode = (root.querySelector('#pcCode').value || code).toUpperCase().trim();
          if (!newCode) { toast('Введите код', 'error'); return; }
          state.promos[newCode] = {
            type: root.querySelector('#pcType').value,
            value: +root.querySelector('#pcVal').value || 0,
            min: +root.querySelector('#pcMin').value || 0,
            active: root.querySelector('#pcActive').checked
          };
          write('sportx_promos', state.promos);
          closeModal();
          toast('Промокод сохранён', 'success');
          S.navigate();
        });
      }
    });
  }

  /* ============================================================
     ПОЛЬЗОВАТЕЛИ
     ============================================================ */
  route('/admin/users', (app) => {
    if (!requireAdmin()) return;
    const users = read('sportx_users', []);
    app.innerHTML = adminLayout('users', `
      <div class="table-wrap">
        <table>
          <thead><tr><th>Имя</th><th>Email</th><th>Телефон</th><th>Роль</th><th>Заказов</th><th>Действия</th></tr></thead>
          <tbody>
            ${users.map(u => {
              const cnt = state.orders.filter(o => o.userId === u.id).length;
              return `
                <tr>
                  <td>${esc(u.name)}</td>
                  <td>${esc(u.email)}</td>
                  <td>${esc(u.phone || '')}</td>
                  <td>${u.role === 'admin' ? 'Администратор' : 'Покупатель'}</td>
                  <td>${cnt}</td>
                  <td>
                    <button class="btn btn--sm btn--outline" data-role="${u.id}">Роль</button>
                    <button class="btn btn--sm ${u.blocked ? 'btn--primary' : 'btn--danger'}" data-block="${u.id}">
                      ${u.blocked ? 'Разблокировать' : 'Заблокировать'}
                    </button>
                  </td>
                </tr>`;
            }).join('')}
          </tbody>
        </table>
      </div>
    `);
    bindAdminLayout();

    app.querySelectorAll('[data-role]').forEach(b => b.addEventListener('click', () => {
      const u = users.find(x => x.id === b.dataset.role);
      u.role = u.role === 'admin' ? 'customer' : 'admin';
      write('sportx_users', users);
      toast('Роль обновлена', 'success');
      S.navigate();
    }));
    app.querySelectorAll('[data-block]').forEach(b => b.addEventListener('click', () => {
      const u = users.find(x => x.id === b.dataset.block);
      u.blocked = !u.blocked;
      write('sportx_users', users);
      toast(u.blocked ? 'Пользователь заблокирован' : 'Разблокирован', 'info');
      S.navigate();
    }));
  });

  /* ============================================================
     ОТЗЫВЫ
     ============================================================ */
  route('/admin/reviews', (app) => {
    if (!requireAdmin()) return;
    const reviews = state.reviews.slice().sort((a, b) => b.date - a.date);
    app.innerHTML = adminLayout('reviews', `
      <div class="table-wrap">
        <table>
          <thead><tr><th>Товар</th><th>Автор</th><th>Оценка</th><th>Текст</th><th>Дата</th><th></th></tr></thead>
          <tbody>
            ${reviews.map(r => {
              const p = state.products.find(x => x.id === r.productId);
              return `
                <tr>
                  <td>${esc(p ? p.name : '—')}</td>
                  <td>${esc(r.author)}</td>
                  <td>${'★'.repeat(r.rating)}</td>
                  <td style="max-width:300px">${esc(r.text)}</td>
                  <td>${new Date(r.date).toLocaleDateString('ru-RU')}</td>
                  <td>
                    <button class="btn btn--sm btn--outline" data-reply="${r.id}">Ответить</button>
                    <button class="btn btn--sm btn--danger" data-del="${r.id}">✕</button>
                  </td>
                </tr>`;
            }).join('')}
          </tbody>
        </table>
      </div>
    `);
    bindAdminLayout();

    app.querySelectorAll('[data-del]').forEach(b => b.addEventListener('click', () => {
      confirmModal('Удалить отзыв?', () => {
        state.reviews = state.reviews.filter(r => r.id !== b.dataset.del);
        write('sportx_reviews', state.reviews);
        S.navigate();
      });
    }));
    app.querySelectorAll('[data-reply]').forEach(b => b.addEventListener('click', () => {
      modal(`
        <h3>Ответ на отзыв</h3>
        <div class="field"><label>Текст ответа</label><textarea id="rReply" placeholder="Спасибо за отзыв!"></textarea></div>
        <button class="btn btn--primary btn--block" id="rSend" style="margin-top:14px">Отправить</button>
      `, {
        onOpen(root) {
          root.querySelector('#rSend').addEventListener('click', () => {
            const txt = root.querySelector('#rReply').value.trim();
            if (!txt) return;
            const r = state.reviews.find(x => x.id === b.dataset.reply);
            r.reply = { text: txt, date: Date.now() };
            write('sportx_reviews', state.reviews);
            closeModal();
            toast('Ответ отправлен', 'success');
          });
        }
      });
    }));
  });

})(window.SportX);