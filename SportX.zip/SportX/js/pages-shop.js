/* ============================================================
   SportX — страницы магазина
   Главная, каталог, товар, корзина, оформление, избранное, сравнение
   ============================================================ */
(function (S) {
  'use strict';
  const { $, $$, esc, formatPrice, toast, modal, closeModal, confirmModal,
          cart, fav, cmp, auth, route, go, breadcrumbs, calcDelivery, DELIVERY,
          state, validatePromo } = S;

  /* ---------- Хелперы ---------- */
  function productCard(p) {
    const inFav = fav.has(p.id);
    const inCmp = cmp.has(p.id);
    const cat = state.categories.find(c => c.id === p.category);
    return `
      <article class="product-card" data-id="${p.id}">
        <div class="product-card__img">
          <a href="#/product/${p.id}">
            <img src="${p.images[0]}" alt="${esc(p.name)}" loading="lazy">
          </a>
          <div class="product-card__badges">
            ${p.isHit ? '<span class="tag tag--hit">ХИТ</span>' : ''}
            ${p.isNew ? '<span class="tag tag--new">NEW</span>' : ''}
            ${p.discount ? `<span class="tag tag--sale">−${p.discount}%</span>` : ''}
          </div>
          <button class="product-card__fav ${inFav ? 'active' : ''}" data-fav="${p.id}" aria-label="В избранное">♡</button>
        </div>
        <div class="product-card__body">
          <div class="product-card__cat">${cat ? esc(cat.name) : ''} · ${esc(p.brand)}</div>
          <a class="product-card__name" href="#/product/${p.id}">${esc(p.name)}</a>
          <div class="product-card__rating"><b>★</b> ${p.rating} <span>(${p.reviewsCount})</span></div>
          <div class="product-card__price">
            <span class="price-now ${p.discount ? 'price-sale' : ''}">${formatPrice(p.price)}</span>
            ${p.oldPrice ? `<span class="price-old">${formatPrice(p.oldPrice)}</span>` : ''}
          </div>
          <div class="product-card__actions">
            <button class="btn btn--primary" data-add="${p.id}">В корзину</button>
            <button class="product-card__compare ${inCmp ? 'active' : ''}" data-cmp="${p.id}" title="Сравнить">⇄</button>
          </div>
        </div>
      </article>`;
  }

  function bindProductCards(root) {
    root.querySelectorAll('[data-fav]').forEach(b => {
      b.addEventListener('click', e => {
        e.preventDefault();
        fav.toggle(b.dataset.fav);
        b.classList.toggle('active');
      });
    });
    root.querySelectorAll('[data-cmp]').forEach(b => {
      b.addEventListener('click', e => {
        e.preventDefault();
        cmp.toggle(b.dataset.cmp);
        b.classList.toggle('active');
      });
    });
    root.querySelectorAll('[data-add]').forEach(b => {
      b.addEventListener('click', e => {
        e.preventDefault();
        cart.add(b.dataset.add, 1);
      });
    });
  }

  /* ============================================================
     ГЛАВНАЯ
     ============================================================ */
  route('/', (app) => {
    const hits = state.products.filter(p => p.isHit).slice(0, 8);
    const news = state.products.filter(p => p.isNew).slice(0, 8);

    app.innerHTML = `
      <div class="container">
        <section class="hero">
          <div class="hero__in">
            <h1>Спорт начинается <span>здесь</span></h1>
            <p>Более 12 000 товаров для тренировок, активного отдыха и здорового образа жизни. Доставка по Великому Новгороду и всей России.</p>
            <div class="hero__btns">
              <a href="#/catalog" class="btn btn--primary btn--lg">В каталог</a>
              <a href="#/delivery" class="btn btn--outline btn--lg" style="border-color:#fff;color:#fff">Доставка и оплата</a>
            </div>
            <div class="hero__stats">
              <div class="hero__stat"><b>12 000+</b><span>товаров</span></div>
              <div class="hero__stat"><b>6</b><span>пунктов выдачи</span></div>
              <div class="hero__stat"><b>1–2 дня</b><span>доставка по городу</span></div>
              <div class="hero__stat"><b>0 ₽</b><span>от 5 000 ₽</span></div>
            </div>
          </div>
        </section>

        <section class="section">
          <div class="section__head">
            <h2>Категории</h2>
          </div>
          <div class="cats">
            ${state.categories.map(c => `
              <a class="cat" href="#/catalog?cat=${c.id}">
                <span class="cat__ico">${c.icon}</span>
                <span>${esc(c.name)}</span>
              </a>`).join('')}
          </div>
        </section>

        <section class="section">
          <div class="section__head">
            <h2>Хиты продаж</h2>
            <a href="#/catalog?sort=popular">Все хиты →</a>
          </div>
          <div class="products" id="hitsGrid">
            ${hits.map(productCard).join('')}
          </div>
        </section>

        <section class="section">
          <div class="section__head">
            <h2>Новинки</h2>
            <a href="#/catalog?sort=new">Все новинки →</a>
          </div>
          <div class="products" id="newsGrid">
            ${news.map(productCard).join('')}
          </div>
        </section>

        <section class="section">
          <div class="hero" style="background:linear-gradient(135deg,#FF6B00,#FF8B3D);padding:44px 40px">
            <div class="hero__in" style="max-width:720px">
              <h2 style="color:#fff">Бонусная программа SportX</h2>
              <p style="color:#fff;opacity:.95">1 балл за каждые 100 ₽ покупки. Уровни Bronze, Silver и Gold. Копите баллы и оплачивайте до 30% заказа!</p>
              <a href="#/delivery#loyalty" class="btn btn--dark btn--lg">Подробнее</a>
            </div>
          </div>
        </section>
      </div>
    `;
    bindProductCards(app);
  });

  /* ============================================================
     КАТАЛОГ
     ============================================================ */
  route('/catalog', (app, params) => {
    // Читаем параметры из URL
    const q = params.q || '';
    const cat = params.cat || '';
    const brand = params.brand || '';
    const sort = params.sort || 'popular';
    const minPrice = +params.min || 0;
    const maxPrice = +params.max || 999999;
    const inStock = params.stock === '1';
    const sizes = params.sizes ? params.sizes.split(',') : [];
    const colors = params.colors ? params.colors.split(',') : [];

    let items = state.products.slice();

    // Фильтры
    if (q) items = items.filter(p => (p.name + ' ' + p.brand).toLowerCase().includes(q.toLowerCase()));
    if (cat) items = items.filter(p => p.category === cat);
    if (brand) items = items.filter(p => p.brand === brand);
    items = items.filter(p => p.price >= minPrice && p.price <= maxPrice);
    if (inStock) items = items.filter(p => p.stock > 0);
    if (sizes.length) items = items.filter(p => (p.sizes || []).some(s => sizes.includes(s)));
    if (colors.length) items = items.filter(p => (p.colors || []).some(c => colors.includes(c)));

    // Сортировка
    if (sort === 'price-asc') items.sort((a, b) => a.price - b.price);
    else if (sort === 'price-desc') items.sort((a, b) => b.price - a.price);
    else if (sort === 'new') items.sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0));
    else if (sort === 'rating') items.sort((a, b) => b.rating - a.rating);
    else items.sort((a, b) => (b.isHit ? 1 : 0) - (a.isHit ? 1 : 0));

    // Доступные размеры/цвета
    const allSizes = [...new Set(state.products.flatMap(p => p.sizes || []))].sort();
    const allColors = [...new Set(state.products.flatMap(p => p.colors || []))].sort();

    const title = cat
      ? (state.categories.find(c => c.id === cat)?.name || 'Каталог')
      : (q ? `Поиск: ${q}` : 'Каталог товаров');

    app.innerHTML = `
      <div class="container">
        ${breadcrumbs([
          { label: 'Главная', href: '#/' },
          { label: 'Каталог', href: '#/catalog' },
          ...(cat ? [{ label: state.categories.find(c => c.id === cat)?.name || '', href: '' }] : [])
        ])}
        <h1 style="margin-bottom:20px">${esc(title)}</h1>
        <div class="catalog">
          <aside class="filters" id="filters">
            <h3>Фильтры</h3>
            <div class="filter-group">
              <h4>Категория</h4>
              <div class="filter-list">
                <label><input type="radio" name="fcat" value="" ${!cat ? 'checked' : ''}> Все категории</label>
                ${state.categories.map(c => `
                  <label><input type="radio" name="fcat" value="${c.id}" ${cat === c.id ? 'checked' : ''}> ${c.icon} ${esc(c.name)}</label>
                `).join('')}
              </div>
            </div>
            <div class="filter-group">
              <h4>Бренд</h4>
              <div class="filter-list">
                ${state.brands.map(b => `
                  <label><input type="radio" name="fbrand" value="${esc(b)}" ${brand === b ? 'checked' : ''}> ${esc(b)}</label>
                `).join('')}
              </div>
            </div>
            <div class="filter-group">
              <h4>Цена, ₽</h4>
              <div class="price-row">
                <input type="number" id="fmin" placeholder="от" value="${minPrice || ''}">
                <input type="number" id="fmax" placeholder="до" value="${maxPrice !== 999999 ? maxPrice : ''}">
              </div>
            </div>
            <div class="filter-group">
              <h4>Размер</h4>
              <div class="filter-list">
                ${allSizes.map(s => `
                  <label><input type="checkbox" name="fsize" value="${esc(s)}" ${sizes.includes(s) ? 'checked' : ''}> ${esc(s)}</label>
                `).join('')}
              </div>
            </div>
            <div class="filter-group">
              <h4>Цвет</h4>
              <div class="filter-list">
                ${allColors.map(c => `
                  <label><input type="checkbox" name="fcolor" value="${esc(c)}" ${colors.includes(c) ? 'checked' : ''}> ${esc(c)}</label>
                `).join('')}
              </div>
            </div>
            <div class="filter-group">
              <h4>Наличие</h4>
              <label><input type="checkbox" id="fstock" ${inStock ? 'checked' : ''}> Только в наличии</label>
            </div>
            <div class="filters__actions">
              <button class="btn btn--primary btn--block" id="applyFilters">Применить</button>
              <button class="btn btn--outline btn--block" id="resetFilters">Сбросить</button>
            </div>
          </aside>

          <div>
            <div class="toolbar">
              <div class="toolbar__count">Найдено: <b>${items.length}</b></div>
              <select id="sortSelect">
                <option value="popular" ${sort === 'popular' ? 'selected' : ''}>По популярности</option>
                <option value="price-asc" ${sort === 'price-asc' ? 'selected' : ''}>Сначала дешёвые</option>
                <option value="price-desc" ${sort === 'price-desc' ? 'selected' : ''}>Сначала дорогие</option>
                <option value="new" ${sort === 'new' ? 'selected' : ''}>Новинки</option>
                <option value="rating" ${sort === 'rating' ? 'selected' : ''}>По рейтингу</option>
              </select>
            </div>
            ${items.length
              ? `<div class="products" id="catGrid">${items.map(productCard).join('')}</div>`
              : `<div class="empty"><div class="empty__ico">🔍</div><h3>Ничего не найдено</h3><p>Попробуйте изменить фильтры или поискать другой товар.</p></div>`}
          </div>
        </div>
      </div>
    `;
    bindProductCards(app);

    // Применение фильтров
    app.querySelector('#applyFilters').addEventListener('click', () => {
      const p = new URLSearchParams();
      const catV = app.querySelector('input[name="fcat"]:checked').value;
      const brandV = app.querySelector('input[name="fbrand"]:checked')?.value || '';
      const min = app.querySelector('#fmin').value;
      const max = app.querySelector('#fmax').value;
      const sz = $$('input[name="fsize"]:checked', app).map(x => x.value);
      const cl = $$('input[name="fcolor"]:checked', app).map(x => x.value);
      const st = app.querySelector('#fstock').checked;
      if (q) p.set('q', q);
      if (catV) p.set('cat', catV);
      if (brandV) p.set('brand', brandV);
      if (min) p.set('min', min);
      if (max) p.set('max', max);
      if (sz.length) p.set('sizes', sz.join(','));
      if (cl.length) p.set('colors', cl.join(','));
      if (st) p.set('stock', '1');
      p.set('sort', sort);
      location.hash = '#/catalog?' + p.toString();
    });

    app.querySelector('#resetFilters').addEventListener('click', () => {
      location.hash = '#/catalog';
    });

    app.querySelector('#sortSelect').addEventListener('change', e => {
      const p = new URLSearchParams(location.hash.split('?')[1] || '');
      p.set('sort', e.target.value);
      location.hash = '#/catalog?' + p.toString();
    });
  });

  /* ============================================================
     КАРТОЧКА ТОВАРА
     ============================================================ */
  route('/product/:id', (app, params) => {
    const id = params._dyn.id;
    const p = state.products.find(x => x.id === id);
    if (!p) {
      app.innerHTML = '<div class="container"><div class="empty"><div class="empty__ico">📦</div><h3>Товар не найден</h3><p><a href="#/catalog">Вернуться в каталог</a></p></div></div>';
      return;
    }
    const cat = state.categories.find(c => c.id === p.category);
    const reviews = state.reviews.filter(r => r.productId === p.id);
    const inFav = fav.has(p.id);

    app.innerHTML = `
      <div class="container">
        ${breadcrumbs([
          { label: 'Главная', href: '#/' },
          { label: 'Каталог', href: '#/catalog' },
          ...(cat ? [{ label: cat.name, href: '#/catalog?cat=' + cat.id }] : []),
          { label: p.name, href: '' }
        ])}
        <div class="product-page">
          <div class="product-gallery">
            <div class="product-gallery__main">
              <img src="${p.images[0]}" alt="${esc(p.name)}" id="mainImg">
            </div>
            ${p.images.length > 1 ? `
              <div class="product-gallery__thumbs">
                ${p.images.map((img, i) => `<img src="${img}" class="${i === 0 ? 'active' : ''}" data-src="${img}">`).join('')}
              </div>` : ''}
          </div>
          <div class="product-info">
            <h1>${esc(p.name)}</h1>
            <div class="product-info__meta">
              <span>Бренд: <b>${esc(p.brand)}</b></span>
              <span>★ ${p.rating} (${p.reviewsCount} отзывов)</span>
              ${p.stock > 0
                ? `<span class="in-stock">✓ В наличии (${p.stock} шт.)</span>`
                : '<span class="out-stock">Нет в наличии</span>'}
            </div>
            <div class="product-info__price">
              <span class="price-now ${p.discount ? 'price-sale' : ''}">${formatPrice(p.price)}</span>
              ${p.oldPrice ? `<span class="price-old">${formatPrice(p.oldPrice)}</span>` : ''}
              ${p.discount ? `<span class="tag tag--sale">−${p.discount}%</span>` : ''}
            </div>

            ${p.sizes && p.sizes.length ? `
              <div class="options">
                <div><b>Размер:</b></div>
                <div class="options__row" id="sizesRow">
                  ${p.sizes.map((s, i) => `<button class="opt ${i === 0 ? 'active' : ''}" data-opt="size" data-val="${esc(s)}">${esc(s)}</button>`).join('')}
                </div>
              </div>` : ''}

            ${p.colors && p.colors.length ? `
              <div class="options">
                <div><b>Цвет:</b></div>
                <div class="options__row" id="colorsRow">
                  ${p.colors.map((c, i) => `<button class="opt ${i === 0 ? 'active' : ''}" data-opt="color" data-val="${esc(c)}">${esc(c)}</button>`).join('')}
                </div>
              </div>` : ''}

            <div class="product-info__buy">
              <div class="qty">
                <button id="qtyMinus">−</button>
                <input type="text" id="qtyInput" value="1" readonly>
                <button id="qtyPlus">+</button>
              </div>
              <button class="btn btn--primary btn--lg" id="addToCart" ${p.stock === 0 ? 'disabled' : ''}>В корзину</button>
              <button class="btn btn--outline btn--lg" id="favBtn">${inFav ? '♥ В избранном' : '♡ В избранное'}</button>
              <button class="btn btn--outline btn--lg" id="cmpBtn">⇄ Сравнить</button>
            </div>

            <div class="specs">
              ${Object.entries(p.specs || {}).map(([k, v]) =>
                `<div class="spec-row"><span>${esc(k)}</span><span>${esc(v)}</span></div>`
              ).join('')}
            </div>
          </div>
        </div>

        <div class="tabs">
          <button class="tab active" data-tab="desc">Описание</button>
          <button class="tab" data-tab="specs">Характеристики</button>
          <button class="tab" data-tab="reviews">Отзывы (${reviews.length})</button>
        </div>

        <div class="tab-content" id="tab-desc">
          <p>${esc(p.description)}</p>
        </div>
        <div class="tab-content" id="tab-specs" hidden>
          <div class="specs">
            ${Object.entries(p.specs || {}).map(([k, v]) =>
              `<div class="spec-row"><span>${esc(k)}</span><span>${esc(v)}</span></div>`
            ).join('')}
          </div>
        </div>
        <div class="tab-content" id="tab-reviews" hidden>
          ${reviews.length
            ? reviews.map(r => `
              <div class="review">
                <div class="review__head">
                  <span class="review__author">${esc(r.author)}</span>
                  <span class="review__date">${new Date(r.date).toLocaleDateString('ru-RU')}</span>
                </div>
                <div class="review__stars">${'★'.repeat(r.rating)}${'☆'.repeat(5 - r.rating)}</div>
                <p style="margin:8px 0 0">${esc(r.text)}</p>
              </div>`).join('')
            : '<p>Пока нет отзывов. Будьте первым!</p>'}
          <button class="btn btn--primary" id="addReviewBtn" style="margin-top:14px">Оставить отзыв</button>
        </div>
      </div>
    `;

    // Галерея
    $$('.product-gallery__thumbs img', app).forEach(t => {
      t.addEventListener('click', () => {
        $$('.product-gallery__thumbs img', app).forEach(x => x.classList.remove('active'));
        t.classList.add('active');
        $('#mainImg').src = t.dataset.src;
      });
    });

    // Опции
    let selSize = p.sizes?.[0] || null;
    let selColor = p.colors?.[0] || null;
    $$('.opt', app).forEach(b => {
      b.addEventListener('click', () => {
        const type = b.dataset.opt;
        $$(`.opt[data-opt="${type}"]`, app).forEach(x => x.classList.remove('active'));
        b.classList.add('active');
        if (type === 'size') selSize = b.dataset.val;
        else selColor = b.dataset.val;
      });
    });

    // Кол-во
    let qty = 1;
    $('#qtyMinus').addEventListener('click', () => { qty = Math.max(1, qty - 1); $('#qtyInput').value = qty; });
    $('#qtyPlus').addEventListener('click', () => { qty = Math.min(99, qty + 1); $('#qtyInput').value = qty; });

    // В корзину
    $('#addToCart').addEventListener('click', () => {
      cart.add(p.id, qty, { size: selSize, color: selColor });
    });

    // Избранное
    $('#favBtn').addEventListener('click', () => {
      fav.toggle(p.id);
      $('#favBtn').textContent = fav.has(p.id) ? '♥ В избранном' : '♡ В избранное';
    });

    // Сравнение
    $('#cmpBtn').addEventListener('click', () => {
      cmp.toggle(p.id);
      toast(cmp.has(p.id) ? 'Добавлено к сравнению' : 'Удалено из сравнения', 'info');
    });

    // Табы
    $$('.tab', app).forEach(t => {
      t.addEventListener('click', () => {
        $$('.tab', app).forEach(x => x.classList.remove('active'));
        t.classList.add('active');
        $$('.tab-content', app).forEach(c => c.hidden = true);
        $('#tab-' + t.dataset.tab).hidden = false;
      });
    });

    // Отзыв
    $('#addReviewBtn').addEventListener('click', () => {
      if (!auth.requireRole()) return;
      modal(`
        <h3>Оставить отзыв</h3>
        <div class="field">
          <label>Оценка</label>
          <select id="revRating">
            <option value="5">★★★★★ Отлично</option>
            <option value="4">★★★★ Хорошо</option>
            <option value="3">★★★ Нормально</option>
            <option value="2">★★ Плохо</option>
            <option value="1">★ Ужасно</option>
          </select>
        </div>
        <div class="field" style="margin-top:12px">
          <label>Комментарий</label>
          <textarea id="revText" placeholder="Поделитесь впечатлениями..."></textarea>
        </div>
        <button class="btn btn--primary btn--block" id="revSubmit" style="margin-top:16px">Отправить</button>
      `, {
        onOpen(root) {
          root.querySelector('#revSubmit').addEventListener('click', () => {
            const rating = +root.querySelector('#revRating').value;
            const text = root.querySelector('#revText').value.trim();
            if (!text) { toast('Напишите комментарий', 'error'); return; }
            state.reviews.push({
              id: S.uid('r'), productId: p.id, userId: state.user.id,
              author: state.user.name, rating, text, date: Date.now()
            });
            S.write('sportx_reviews', state.reviews);
            closeModal();
            toast('Спасибо за отзыв!', 'success');
            S.navigate();
          });
        }
      });
    });
  });

  /* ============================================================
     КОРЗИНА
     ============================================================ */
  route('/cart', (app) => {
    if (!state.cart.length) {
      app.innerHTML = `
        <div class="container">
          ${breadcrumbs([{ label: 'Главная', href: '#/' }, { label: 'Корзина', href: '' }])}
          <div class="empty">
            <div class="empty__ico">🛒</div>
            <h3>Корзина пуста</h3>
            <p>Добавьте товары из каталога, чтобы оформить заказ.</p>
            <a href="#/catalog" class="btn btn--primary">Перейти в каталог</a>
          </div>
        </div>`;
      return;
    }

    const promo = S.read('sportx_promo', null);
    const subtotal = cart.subtotal();
    let discount = 0;
    let deliveryFree = false;
    if (promo) {
      if (promo.type === 'percent') discount = Math.round(subtotal * promo.value / 100);
      else if (promo.type === 'delivery') deliveryFree = true;
    }
    const total = subtotal - discount;

    app.innerHTML = `
      <div class="container">
        ${breadcrumbs([{ label: 'Главная', href: '#/' }, { label: 'Корзина', href: '' }])}
        <h1>Корзина</h1>
        <div class="cart">
          <div class="cart__list" id="cartList">
            ${state.cart.map(it => `
              <div class="cart-item" data-key="${esc(it.key)}">
                <img src="${it.image}" alt="${esc(it.name)}">
                <div>
                  <a class="cart-item__name" href="#/product/${it.productId}">${esc(it.name)}</a>
                  <div style="font-size:13px;color:var(--text-2)">
                    ${it.size ? 'Размер: ' + esc(it.size) : ''}
                    ${it.color ? ' · Цвет: ' + esc(it.color) : ''}
                  </div>
                  <button class="cart-item__remove" data-remove="${esc(it.key)}">Удалить</button>
                </div>
                <div class="qty">
                  <button data-dec="${esc(it.key)}">−</button>
                  <input type="text" value="${it.qty}" readonly>
                  <button data-inc="${esc(it.key)}">+</button>
                </div>
                <div class="cart-item__price">${formatPrice(it.price * it.qty)}</div>
              </div>
            `).join('')}
          </div>
          <aside class="summary">
            <h3>Итого</h3>
            <div class="summary__row"><span>Товары (${state.cart.reduce((s,i)=>s+i.qty,0)} шт.)</span><span>${formatPrice(subtotal)}</span></div>
            ${discount ? `<div class="summary__row" style="color:var(--success)"><span>Скидка по промокоду</span><span>−${formatPrice(discount)}</span></div>` : ''}
            <div class="promo">
              <input type="text" id="promoInput" placeholder="Промокод" value="${promo ? promo.code : ''}">
              <button class="btn btn--outline" id="promoBtn">${promo ? 'Сбросить' : 'Применить'}</button>
            </div>
            <div class="summary__row total"><span>К оплате</span><span>${formatPrice(total)}</span></div>
            <a href="#/checkout" class="btn btn--primary btn--block btn--lg" style="margin-top:16px">Оформить заказ</a>
            <button class="btn btn--outline btn--block" id="clearCart" style="margin-top:8px">Очистить корзину</button>
          </aside>
        </div>
      </div>
    `;

    app.querySelectorAll('[data-remove]').forEach(b => {
      b.addEventListener('click', () => {
        cart.remove(b.dataset.remove);
        S.navigate();
      });
    });
    app.querySelectorAll('[data-inc]').forEach(b => {
      b.addEventListener('click', () => {
        const it = state.cart.find(x => x.key === b.dataset.inc);
        cart.setQty(b.dataset.inc, it.qty + 1);
        S.navigate();
      });
    });
    app.querySelectorAll('[data-dec]').forEach(b => {
      b.addEventListener('click', () => {
        const it = state.cart.find(x => x.key === b.dataset.dec);
        if (it.qty <= 1) return;
        cart.setQty(b.dataset.dec, it.qty - 1);
        S.navigate();
      });
    });
    $('#clearCart').addEventListener('click', () => {
      confirmModal('Очистить корзину?', () => { cart.clear(); S.navigate(); });
    });
    $('#promoBtn').addEventListener('click', () => {
      const input = $('#promoInput');
      const code = input.value.trim().toUpperCase();
      if (!code) {
        S.write('sportx_promo', null);
        S.navigate();
        return;
      }
      try {
        const p = validatePromo(code);
        S.write('sportx_promo', { ...p, code });
        toast('Промокод применён', 'success');
        S.navigate();
      } catch (e) {
        toast(e.message, 'error');
      }
    });
  });

  /* ============================================================
     ОФОРМЛЕНИЕ ЗАКАЗА
     ============================================================ */
  route('/checkout', (app) => {
    if (!state.cart.length) { go('/cart'); return; }
    if (!state.user) { go('/login'); return; }

    const subtotal = cart.subtotal();
    const promo = S.read('sportx_promo', null);
    let discount = 0;
    if (promo && promo.type === 'percent') discount = Math.round(subtotal * promo.value / 100);

    app.innerHTML = `
      <div class="container">
        ${breadcrumbs([
          { label: 'Главная', href: '#/' },
          { label: 'Корзина', href: '#/cart' },
          { label: 'Оформление', href: '' }
        ])}
        <h1>Оформление заказа</h1>
        <div class="cart">
          <form class="form form--wide" id="checkoutForm">
            <h3>Контактные данные</h3>
            <div class="field">
              <label>Имя и фамилия *</label>
              <input type="text" name="name" required value="${esc(state.user.name)}">
            </div>
            <div class="field">
              <label>Телефон *</label>
              <input type="tel" name="phone" required value="${esc(state.user.phone)}">
            </div>
            <div class="field">
              <label>Email *</label>
              <input type="email" name="email" required value="${esc(state.user.email)}">
            </div>

            <h3 style="margin-top:20px">Доставка</h3>
            <div class="field">
              <label>Способ доставки *</label>
              <select name="delivery" id="deliverySelect">
                ${Object.entries(DELIVERY).map(([k, d]) =>
                  `<option value="${k}">${esc(d.label)} — ${d.freeFrom ? 'бесплатно от ' + formatPrice(d.freeFrom) : 'бесплатно'}</option>`
                ).join('')}
              </select>
            </div>
            <div class="field" id="addressField">
              <label>Адрес доставки *</label>
              <input type="text" name="address" placeholder="Город, улица, дом, квартира" value="Великий Новгород, ">
            </div>
            <div class="field">
              <label>Комментарий к заказу</label>
              <textarea name="comment" placeholder="Например: позвонить за час до доставки"></textarea>
            </div>

            <h3 style="margin-top:20px">Оплата</h3>
            <div class="field">
              <label>Способ оплаты *</label>
              <select name="payment">
                <option value="card">Банковская карта</option>
                <option value="sbp">СБП</option>
                <option value="cash">Наличные при получении</option>
                <option value="installment">Рассрочка 0-0-6</option>
              </select>
            </div>
            <div class="field">
              <label><input type="checkbox" required> Согласен с условиями обработки персональных данных</label>
            </div>
          </form>

          <aside class="summary">
            <h3>Ваш заказ</h3>
            ${state.cart.map(it => `
              <div class="summary__row">
                <span>${esc(it.name)} × ${it.qty}</span>
                <span>${formatPrice(it.price * it.qty)}</span>
              </div>
            `).join('')}
            <div class="summary__row"><span>Товары</span><span>${formatPrice(subtotal)}</span></div>
            ${discount ? `<div class="summary__row" style="color:var(--success)"><span>Скидка</span><span>−${formatPrice(discount)}</span></div>` : ''}
            <div class="summary__row" id="deliveryRow"><span>Доставка</span><span>300 ₽</span></div>
            <div class="summary__row total"><span>Итого</span><span id="totalVal">${formatPrice(subtotal - discount + 300)}</span></div>
            <button class="btn btn--primary btn--block btn--lg" id="submitOrder" style="margin-top:16px">Подтвердить заказ</button>
            <p style="font-size:12px;color:var(--text-2);margin-top:12px">
              Нажимая кнопку, вы подтверждаете заказ и соглашаетесь с условиями.
            </p>
          </aside>
        </div>
      </div>
    `;

    const deliverySelect = $('#deliverySelect');
    const addressField = $('#addressField');
    const deliveryRow = $('#deliveryRow');
    const totalVal = $('#totalVal');

    function recalc() {
      const method = deliverySelect.value;
      const d = DELIVERY[method];
      const weight = state.cart.reduce((s, i) => s + i.qty, 0);
      const cost = calcDelivery(method, weight, subtotal);
      deliveryRow.innerHTML = `<span>Доставка</span><span>${cost === 0 ? 'Бесплатно' : formatPrice(cost)}</span>`;
      totalVal.textContent = formatPrice(subtotal - discount + cost);
      addressField.style.display = method === 'pickup' ? 'none' : '';
    }
    deliverySelect.addEventListener('change', recalc);
    recalc();

    $('#submitOrder').addEventListener('click', () => {
      const form = $('#checkoutForm');
      if (!form.reportValidity()) return;
      const data = Object.fromEntries(new FormData(form));
      const method = data.delivery;
      const weight = state.cart.reduce((s, i) => s + i.qty, 0);
      const deliveryCost = calcDelivery(method, weight, subtotal);
      const total = subtotal - discount + deliveryCost;

      const order = {
        id: 'SX-' + new Date().getFullYear() + '-' + String(state.orders.length + 1).padStart(4, '0'),
        userId: state.user.id,
        date: Date.now(),
        status: 'new',
        total,
        deliveryCost,
        discount,
        payment: data.payment,
        delivery: method,
        address: method === 'pickup' ? 'Самовывоз' : data.address,
        comment: data.comment,
        customer: { name: data.name, phone: data.phone, email: data.email },
        items: state.cart.map(i => ({ ...i }))
      };
      state.orders.push(order);
      S.write('sportx_orders', state.orders);

      // бонусы
      const earned = Math.floor(total / 100);
      state.bonus.points += earned;
      state.bonus.history.push({ date: Date.now(), points: earned, reason: 'Заказ ' + order.id });
      if (state.bonus.points >= 3000) state.bonus.level = 'Gold';
      else if (state.bonus.points >= 1000) state.bonus.level = 'Silver';
      S.write('sportx_bonus', state.bonus);

      cart.clear();
      S.write('sportx_promo', null);

      modal(`
        <div style="text-align:center;padding:10px 0">
          <div style="font-size:56px">✅</div>
          <h3>Заказ ${order.id} оформлен!</h3>
          <p>Мы отправили детали на ${esc(data.email)}. Менеджер свяжется с вами для подтверждения.</p>
          <p style="color:var(--accent);font-weight:700">Начислено бонусов: +${earned}</p>
          <a href="#/account" class="btn btn--primary btn--block" style="margin-top:16px">Перейти в личный кабинет</a>
        </div>
      `);
      setTimeout(() => { closeModal(); go('/account'); }, 4000);
    });
  });

  /* ============================================================
     ИЗБРАННОЕ
     ============================================================ */
  route('/favorites', (app) => {
    const items = state.products.filter(p => fav.has(p.id));
    app.innerHTML = `
      <div class="container">
        ${breadcrumbs([{ label: 'Главная', href: '#/' }, { label: 'Избранное', href: '' }])}
        <h1>Избранное</h1>
        ${items.length
          ? `<div class="products">${items.map(productCard).join('')}</div>`
          : `<div class="empty"><div class="empty__ico">♡</div><h3>В избранном пусто</h3><p>Добавляйте товары, чтобы не потерять их.</p><a href="#/catalog" class="btn btn--primary">В каталог</a></div>`}
      </div>`;
    bindProductCards(app);
  });

  /* ============================================================
     СРАВНЕНИЕ
     ============================================================ */
  route('/compare', (app) => {
    const items = state.products.filter(p => cmp.has(p.id));
    if (!items.length) {
      app.innerHTML = `
        <div class="container">
          ${breadcrumbs([{ label: 'Главная', href: '#/' }, { label: 'Сравнение', href: '' }])}
          <h1>Сравнение</h1>
          <div class="empty"><div class="empty__ico">⇄</div><h3>Нет товаров для сравнения</h3><p>Добавьте до 4 товаров из каталога.</p><a href="#/catalog" class="btn btn--primary">В каталог</a></div>
        </div>`;
      return;
    }
    const specKeys = [...new Set(items.flatMap(p => Object.keys(p.specs || {})))];

    app.innerHTML = `
      <div class="container">
        ${breadcrumbs([{ label: 'Главная', href: '#/' }, { label: 'Сравнение', href: '' }])}
        <h1>Сравнение товаров</h1>
        <div class="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Параметр</th>
                ${items.map(p => `
                  <th>
                    <img src="${p.images[0]}" style="width:80px;height:80px;object-fit:cover;border-radius:8px;margin-bottom:8px">
                    <div>${esc(p.name)}</div>
                    <div style="color:var(--accent);font-weight:700;margin-top:6px">${formatPrice(p.price)}</div>
                    <button class="btn btn--sm btn--primary" data-add="${p.id}" style="margin-top:6px">В корзину</button>
                    <button class="btn btn--sm btn--outline" data-rmcmp="${p.id}" style="margin-top:4px">Убрать</button>
                  </th>
                `).join('')}
              </tr>
            </thead>
            <tbody>
              <tr><td><b>Бренд</b></td>${items.map(p => `<td>${esc(p.brand)}</td>`).join('')}</tr>
              <tr><td><b>Рейтинг</b></td>${items.map(p => `<td>★ ${p.rating}</td>`).join('')}</tr>
              <tr><td><b>Наличие</b></td>${items.map(p => `<td>${p.stock > 0 ? 'В наличии' : 'Нет'}</td>`).join('')}</tr>
              ${specKeys.map(k => `
                <tr><td><b>${esc(k)}</b></td>${items.map(p => `<td>${esc((p.specs || {})[k] || '—')}</td>`).join('')}</tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;

    app.querySelectorAll('[data-add]').forEach(b => {
      b.addEventListener('click', () => cart.add(b.dataset.add, 1));
    });
    app.querySelectorAll('[data-rmcmp]').forEach(b => {
      b.addEventListener('click', () => { cmp.toggle(b.dataset.rmcmp); S.navigate(); });
    });
  });

  /* ============================================================
     404
     ============================================================ */
  route('/404', (app) => {
    app.innerHTML = `
      <div class="container">
        <div class="empty">
          <div class="empty__ico">🧭</div>
          <h3>Страница не найдена</h3>
          <p>Возможно, она была удалена или перемещена.</p>
          <a href="#/" class="btn btn--primary">На главную</a>
        </div>
      </div>`;
  });

})(window.SportX);