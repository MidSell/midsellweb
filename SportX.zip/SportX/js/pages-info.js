/* ============================================================
   SportX — информационные страницы
   Доставка, карта пунктов выдачи, о компании
   ============================================================ */
(function (S) {
  'use strict';
  const { $, $$, esc, formatPrice, toast, route, breadcrumbs, state } = S;

  /* ============================================================
     ДОСТАВКА И ОПЛАТА
     ============================================================ */
  route('/delivery', (app) => {
    app.innerHTML = `
      <div class="container">
        ${breadcrumbs([{ label: 'Главная', href: '#/' }, { label: 'Доставка и оплата', href: '' }])}
        <h1>Доставка и оплата</h1>

        <section class="section">
          <h2>Способы доставки</h2>
          <div class="table-wrap">
            <table>
              <thead>
                <tr><th>Способ</th><th>Сроки</th><th>Стоимость</th><th>Бесплатно от</th></tr>
              </thead>
              <tbody>
                <tr><td>Курьер по Великому Новгороду</td><td>1–2 дня</td><td>от 300 ₽</td><td>5 000 ₽</td></tr>
                <tr><td>СДЭК (по России)</td><td>3–7 дней</td><td>от 400 ₽</td><td>8 000 ₽</td></tr>
                <tr><td>Почта России</td><td>5–14 дней</td><td>от 250 ₽</td><td>10 000 ₽</td></tr>
                <tr><td>Самовывоз из магазина</td><td>сегодня</td><td>бесплатно</td><td>—</td></tr>
              </tbody>
            </table>
          </div>
          <p style="margin-top:14px;color:var(--text-2)">
            Точная стоимость зависит от веса заказа и региона. Расчёт производится автоматически при оформлении.
          </p>
        </section>

        <section class="section">
          <h2>Стоимость доставки по регионам</h2>
          <div class="table-wrap">
            <table>
              <thead><tr><th>Регион</th><th>Курьер</th><th>СДЭК</th><th>Почта</th></tr></thead>
              <tbody>
                <tr><td>Великий Новгород</td><td>300 ₽</td><td>350 ₽</td><td>250 ₽</td></tr>
                <tr><td>Новгородская область</td><td>450 ₽</td><td>400 ₽</td><td>300 ₽</td></tr>
                <tr><td>Санкт-Петербург и ЛО</td><td>—</td><td>450 ₽</td><td>350 ₽</td></tr>
                <tr><td>Москва и МО</td><td>—</td><td>500 ₽</td><td>400 ₽</td></tr>
                <tr><td>Другие регионы РФ</td><td>—</td><td>от 550 ₽</td><td>от 400 ₽</td></tr>
              </tbody>
            </table>
          </div>
        </section>

        <section class="section">
          <h2>Способы оплаты</h2>
          <div class="products">
            <div class="stat"><div class="stat__lbl">Банковская карта</div><div class="stat__val" style="font-size:16px">Visa, MasterCard, МИР</div></div>
            <div class="stat"><div class="stat__lbl">СБП</div><div class="stat__val" style="font-size:16px">По QR-коду</div></div>
            <div class="stat"><div class="stat__lbl">Наличные</div><div class="stat__val" style="font-size:16px">При получении</div></div>
            <div class="stat"><div class="stat__lbl">Рассрочка</div><div class="stat__val" style="font-size:16px">0-0-6</div></div>
          </div>
        </section>

        <section class="section" id="return">
          <h2>Гарантия, возврат и обмен</h2>
          <p>Вы можете вернуть или обменять товар надлежащего качества в течение <b>14 дней</b> с момента покупки, а при обнаружении брака — в течение <b>30 дней</b>.</p>
          <ul style="line-height:1.9">
            <li>Товар не должен быть в употреблении, сохранены ярлыки и упаковка.</li>
            <li>Возврат средств — на карту или наличными в течение 5–10 рабочих дней.</li>
            <li>Обмен размера/цвета — бесплатно в магазине.</li>
          </ul>
        </section>

        <section class="section" id="loyalty">
          <h2>Программа лояльности</h2>
          <div class="loyalty-card" style="max-width:640px">
            <h3>Копите баллы — платите ими</h3>
            <p style="color:#C9CED8">1 балл за каждые 100 ₽. До 30% от заказа можно оплатить баллами.</p>
            <div style="display:flex;gap:20px;flex-wrap:wrap;margin-top:14px">
              <div><b style="color:var(--accent)">Bronze</b><br><span style="font-size:13px;color:#C9CED8">от 0 баллов</span></div>
              <div><b style="color:#C0C7D3">Silver</b><br><span style="font-size:13px;color:#C9CED8">от 1 000 баллов</span></div>
              <div><b style="color:#FFB800">Gold</b><br><span style="font-size:13px;color:#C9CED8">от 3 000 баллов</span></div>
            </div>
          </div>
          <ul style="line-height:1.9;margin-top:16px">
            <li>+200 баллов за регистрацию</li>
            <li>+50 баллов за отзыв с фото</li>
            <li>×2 балла в день рождения</li>
            <li>Бесплатная доставка для уровня Gold</li>
          </ul>
        </section>

        <section class="section">
          <h2>Дополнительные услуги</h2>
          <div class="products">
            <div class="stat"><div class="stat__lbl">Сборка тренажёров</div><div class="stat__val">от 1 500 ₽</div></div>
            <div class="stat"><div class="stat__lbl">Установка велосипедов</div><div class="stat__val">от 800 ₽</div></div>
            <div class="stat"><div class="stat__lbl">Подарочная упаковка</div><div class="stat__val">300 ₽</div></div>
          </div>
        </section>
      </div>`;
  });

  /* ============================================================
     КАРТА ПУНКТОВ ВЫДАЧИ
     ============================================================ */
  route('/map', (app) => {
    app.innerHTML = `
      <div class="container">
        ${breadcrumbs([{ label: 'Главная', href: '#/' }, { label: 'Пункты выдачи', href: '' }])}
        <h1>Пункты выдачи и магазины</h1>
        <p style="color:var(--text-2);margin-bottom:16px">
          6 точек в Великом Новгороде. Выберите ближайшую — и заберите заказ в удобное время.
        </p>
        <div style="margin-bottom:16px;display:flex;gap:10px;flex-wrap:wrap">
          <button class="btn btn--primary" id="geoBtn">📍 Найти ближайший</button>
          <a href="#/delivery" class="btn btn--outline">Условия доставки</a>
        </div>
        <div id="map"></div>

        <h2 style="margin-top:32px">Все пункты</h2>
        <div class="products" style="margin-top:16px">
          ${state.stores.map(s => `
            <div class="stat">
              <div class="stat__lbl">${s.type === 'store' ? 'Магазин' : 'Пункт выдачи'}</div>
              <div class="stat__val" style="font-size:16px;margin-bottom:8px">${esc(s.name)}</div>
              <p style="font-size:13px;color:var(--text-2);margin:4px 0">${esc(s.address)}</p>
              <p style="font-size:13px;color:var(--text-2);margin:4px 0">🕒 ${esc(s.hours)}</p>
              <p style="font-size:13px;color:var(--text-2);margin:4px 0">📞 ${esc(s.phone)}</p>
              <button class="btn btn--sm btn--primary" data-pick="${s.id}" style="margin-top:10px">Забрать здесь</button>
            </div>
          `).join('')}
        </div>
      </div>`;

    // Инициализация Leaflet
    if (typeof L === 'undefined') {
      setTimeout(() => S.navigate(), 500);
      return;
    }
    const map = L.map('map').setView([58.5215, 31.2755], 13);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap',
      maxZoom: 19
    }).addTo(map);

    const markers = L.markerClusterGroup();
    state.stores.forEach(s => {
      const marker = L.marker(s.coords);
      marker.bindPopup(`
        <h4>${esc(s.name)}</h4>
        <p>${esc(s.address)}</p>
        <p>🕒 ${esc(s.hours)}</p>
        <p>📞 ${esc(s.phone)}</p>
        <button class="btn btn--primary" onclick="document.querySelector('[data-pick=\\'${s.id}\\']').click()">Забрать здесь</button>
      `);
      markers.addLayer(marker);
    });
    map.addLayer(markers);

    // Зона доставки (круг)
    L.circle([58.5215, 31.2755], {
      radius: 6000, color: '#FF6B00', fillColor: '#FF6B00',
      fillOpacity: .08, weight: 2, dashArray: '6 6'
    }).addTo(map).bindPopup('Зона курьерской доставки по Великому Новгороду');

    // Кнопка «Забрать здесь»
    app.querySelectorAll('[data-pick]').forEach(b => {
      b.addEventListener('click', () => {
        const s = state.stores.find(x => x.id === b.dataset.pick);
        toast('Выбран пункт: ' + s.name, 'success');
        sessionStorage.setItem('sportx_pickup', s.id);
      });
    });

    // Геолокация
    $('#geoBtn').addEventListener('click', () => {
      if (!navigator.geolocation) { toast('Геолокация недоступна', 'error'); return; }
      toast('Определяем местоположение…', 'info');
      navigator.geolocation.getCurrentPosition(
        pos => {
          const { latitude, longitude } = pos.coords;
          map.setView([latitude, longitude], 14);
          L.marker([latitude, longitude]).addTo(map).bindPopup('Вы здесь').openPopup();
          // ближайший
          let best = null, min = Infinity;
          state.stores.forEach(s => {
            const d = Math.hypot(s.coords[0] - latitude, s.coords[1] - longitude);
            if (d < min) { min = d; best = s; }
          });
          if (best) toast('Ближайший пункт: ' + best.name, 'success');
        },
        () => toast('Не удалось определить местоположение', 'error')
      );
    });
  });

  /* ============================================================
     О КОМПАНИИ
     ============================================================ */
  route('/about', (app) => {
    app.innerHTML = `
      <div class="container">
        ${breadcrumbs([{ label: 'Главная', href: '#/' }, { label: 'О компании', href: '' }])}
        <h1>О SportX</h1>
        <p style="font-size:17px;max-width:760px">
          SportX — спортивный магазин в Великом Новгороде. Мы помогаем людям заниматься спортом с 2015 года:
          от первых кроссовок до серьёзных тренировок и походов. Более 12 000 товаров, 6 точек в городе
          и доставка по всей России.
        </p>
        <div class="stats" style="margin-top:32px">
          <div class="stat"><div class="stat__lbl">Год основания</div><div class="stat__val">2015</div></div>
          <div class="stat"><div class="stat__lbl">Товаров</div><div class="stat__val">12 000+</div></div>
          <div class="stat"><div class="stat__lbl">Клиентов</div><div class="stat__val">48 000</div></div>
          <div class="stat"><div class="stat__lbl">Точек в городе</div><div class="stat__val">6</div></div>
        </div>

        <h2 style="margin-top:32px">Наши принципы</h2>
        <div class="products">
          <div class="stat"><div class="stat__lbl">Качество</div><p>Только проверенные бренды и товары, которые мы тестируем сами.</p></div>
          <div class="stat"><div class="stat__lbl">Скорость</div><p>Доставка по городу за 1–2 дня, самовывоз в день заказа.</p></div>
          <div class="stat"><div class="stat__lbl">Сервис</div><p>Поможем подобрать, соберём тренажёр, настроим велосипед.</p></div>
        </div>

        <h2 style="margin-top:32px">Контакты</h2>
        <p>
          Телефон: <a href="tel:+78162000000">+7 (8162) 00-00-00</a><br>
          Email: <a href="mailto:shop@sportx.ru">shop@sportx.ru</a><br>
          Адрес: г. Великий Новгород, ул. Большая Московская, 44<br>
          Режим работы: ежедневно 10:00–21:00
        </p>
      </div>`;
  });

})(window.SportX);