/* ============================================================
   SportX — личный кабинет
   Профиль, заказы, адреса, бонусы, отзывы, авторизация
   ============================================================ */
(function (S) {
  'use strict';
  const { $, $$, esc, formatPrice, toast, modal, closeModal, confirmModal,
          cart, auth, route, go, breadcrumbs, state, read, write } = S;

  /* ============================================================
     ЛОГИН
     ============================================================ */
  route('/login', (app) => {
    if (state.user) { go('/account'); return; }
    app.innerHTML = `
      <div class="container">
        <div class="auth">
          <h1>Вход в SportX</h1>
          <p class="sub">Войдите, чтобы оформлять заказы и копить бонусы</p>
          <form class="form" id="loginForm" novalidate>
            <div class="field">
              <label>Email или телефон</label>
              <input type="text" name="login" required placeholder="user@sportx.ru">
            </div>
            <div class="field">
              <label>Пароль</label>
              <input type="password" name="password" required placeholder="••••••••">
            </div>
            <button class="btn btn--primary btn--block btn--lg" type="submit">Войти</button>
          </form>
          <p class="auth__switch">Нет аккаунта? <a href="#/register">Зарегистрироваться</a></p>
          <div class="alert alert--info" style="margin-top:20px;font-size:13px">
            <b>Демо-доступы:</b><br>
            Покупатель: user@sportx.ru / user123<br>
            Администратор: admin@sportx.ru / admin123
          </div>
        </div>
      </div>
    `;
    $('#loginForm').addEventListener('submit', e => {
      e.preventDefault();
      const fd = new FormData(e.target);
      try {
        auth.login(fd.get('login').trim(), fd.get('password'));
        go('/account');
      } catch (err) {
        toast(err.message, 'error');
      }
    });
  });

  /* ============================================================
     РЕГИСТРАЦИЯ
     ============================================================ */
  route('/register', (app) => {
    if (state.user) { go('/account'); return; }
    app.innerHTML = `
      <div class="container">
        <div class="auth">
          <h1>Регистрация</h1>
          <p class="sub">Создайте аккаунт и получите 200 приветственных бонусов</p>
          <form class="form" id="regForm" novalidate>
            <div class="field">
              <label>Имя и фамилия *</label>
              <input type="text" name="name" required minlength="2" placeholder="Иван Петров">
            </div>
            <div class="field">
              <label>Email *</label>
              <input type="email" name="email" required placeholder="ivan@mail.ru">
            </div>
            <div class="field">
              <label>Телефон *</label>
              <input type="tel" name="phone" required placeholder="+7 (900) 000-00-00">
            </div>
            <div class="field">
              <label>Пароль * (минимум 6 символов)</label>
              <input type="password" name="password" required minlength="6">
            </div>
            <div class="field">
              <label>Повторите пароль *</label>
              <input type="password" name="password2" required minlength="6">
            </div>
            <label style="font-size:13px;display:flex;gap:8px;align-items:flex-start">
              <input type="checkbox" required style="margin-top:3px">
              <span>Согласен с условиями обработки персональных данных и правилами магазина</span>
            </label>
            <button class="btn btn--primary btn--block btn--lg" type="submit">Создать аккаунт</button>
          </form>
          <p class="auth__switch">Уже есть аккаунт? <a href="#/login">Войти</a></p>
        </div>
      </div>
    `;
    $('#regForm').addEventListener('submit', e => {
      e.preventDefault();
      const fd = new FormData(e.target);
      const data = Object.fromEntries(fd);
      if (data.password !== data.password2) { toast('Пароли не совпадают', 'error'); return; }
      try {
        auth.register({
          name: data.name.trim(),
          email: data.email.trim().toLowerCase(),
          phone: data.phone.trim(),
          password: data.password
        });
        // бонусы за регистрацию
        state.bonus.points += 200;
        state.bonus.history.push({ date: Date.now(), points: 200, reason: 'Регистрация' });
        write('sportx_bonus', state.bonus);
        go('/account');
      } catch (err) {
        toast(err.message, 'error');
      }
    });
  });

  /* ============================================================
     ЛИЧНЫЙ КАБИНЕТ
     ============================================================ */
  function renderAccountMenu(active) {
    return `
      <nav class="account__menu">
        <a href="#/account" class="${active === 'profile' ? 'active' : ''}">👤 Профиль</a>
        <a href="#/account/orders" class="${active === 'orders' ? 'active' : ''}">📦 Мои заказы</a>
        <a href="#/account/addresses" class="${active === 'addresses' ? 'active' : ''}">📍 Адреса</a>
        <a href="#/account/bonus" class="${active === 'bonus' ? 'active' : ''}">🎁 Бонусы</a>
        <a href="#/account/reviews" class="${active === 'reviews' ? 'active' : ''}">⭐ Мои отзывы</a>
        <a href="#/favorites">♡ Избранное</a>
        <a href="#" id="logoutBtn" style="color:var(--danger)">🚪 Выйти</a>
      </nav>`;
  }

  function bindAccountLayout(app) {
    const out = app.querySelector('#logoutBtn');
    if (out) out.addEventListener('click', e => { e.preventDefault(); auth.logout(); });
  }

  route('/account', (app) => {
    if (!auth.requireRole()) return;
    const u = state.user;
    const orders = state.orders.filter(o => o.userId === u.id);
    const totalSpent = orders.reduce((s, o) => s + (o.status !== 'cancelled' ? o.total : 0), 0);

    app.innerHTML = `
      <div class="container">
        ${breadcrumbs([{ label: 'Главная', href: '#/' }, { label: 'Личный кабинет', href: '' }])}
        <h1>Здравствуйте, ${esc(u.name.split(' ')[0])}!</h1>
        <div class="account">
          ${renderAccountMenu('profile')}
          <div class="account__content">
            <div class="stats">
              <div class="stat">
                <div class="stat__lbl">Всего заказов</div>
                <div class="stat__val">${orders.length}</div>
              </div>
              <div class="stat">
                <div class="stat__lbl">Сумма покупок</div>
                <div class="stat__val">${formatPrice(totalSpent)}</div>
              </div>
              <div class="stat">
                <div class="stat__lbl">Бонусных баллов</div>
                <div class="stat__val" style="color:var(--accent)">${state.bonus.points}</div>
              </div>
              <div class="stat">
                <div class="stat__lbl">Уровень</div>
                <div class="stat__val">${esc(state.bonus.level)}</div>
              </div>
            </div>

            <h3>Личные данные</h3>
            <form class="form form--wide" id="profileForm" style="margin-top:14px">
              <div class="field">
                <label>Имя и фамилия</label>
                <input type="text" name="name" value="${esc(u.name)}" required>
              </div>
              <div class="field">
                <label>Email</label>
                <input type="email" name="email" value="${esc(u.email)}" required>
              </div>
              <div class="field">
                <label>Телефон</label>
                <input type="tel" name="phone" value="${esc(u.phone || '')}">
              </div>
              <div style="display:flex;gap:10px">
                <button class="btn btn--primary" type="submit">Сохранить</button>
                <button class="btn btn--outline" type="button" id="changePassBtn">Сменить пароль</button>
              </div>
            </form>
          </div>
        </div>
      </div>`;
    bindAccountLayout(app);

    $('#profileForm').addEventListener('submit', e => {
      e.preventDefault();
      const fd = new FormData(e.target);
      const users = read('sportx_users', []);
      const idx = users.findIndex(x => x.id === state.user.id);
      if (idx >= 0) {
        users[idx].name = fd.get('name').trim();
        users[idx].email = fd.get('email').trim().toLowerCase();
        users[idx].phone = fd.get('phone').trim();
        write('sportx_users', users);
        state.user.name = users[idx].name;
        state.user.email = users[idx].email;
        state.user.phone = users[idx].phone;
        write('sportx_user', state.user);
        auth.renderHeader();
        toast('Данные сохранены', 'success');
      }
    });

    $('#changePassBtn').addEventListener('click', () => {
      modal(`
        <h3>Смена пароля</h3>
        <div class="field"><label>Текущий пароль</label><input type="password" id="oldPass"></div>
        <div class="field" style="margin-top:10px"><label>Новый пароль</label><input type="password" id="newPass"></div>
        <div class="field" style="margin-top:10px"><label>Повторите новый пароль</label><input type="password" id="newPass2"></div>
        <button class="btn btn--primary btn--block" id="savePass" style="margin-top:16px">Сохранить</button>
      `, {
        onOpen(root) {
          root.querySelector('#savePass').addEventListener('click', () => {
            const users = read('sportx_users', []);
            const idx = users.findIndex(x => x.id === state.user.id);
            const oldP = root.querySelector('#oldPass').value;
            const np = root.querySelector('#newPass').value;
            const np2 = root.querySelector('#newPass2').value;
            if (users[idx].pass !== auth.hash(oldP)) { toast('Текущий пароль неверен', 'error'); return; }
            if (np.length < 6) { toast('Минимум 6 символов', 'error'); return; }
            if (np !== np2) { toast('Пароли не совпадают', 'error'); return; }
            users[idx].pass = auth.hash(np);
            write('sportx_users', users);
            closeModal();
            toast('Пароль изменён', 'success');
          });
        }
      });
    });
  });

  /* ============================================================
     МОИ ЗАКАЗЫ
     ============================================================ */
  route('/account/orders', (app) => {
    if (!auth.requireRole()) return;
    const orders = state.orders.filter(o => o.userId === state.user.id).sort((a, b) => b.date - a.date);

    const statusMap = {
      new: { label: 'Новый', cls: 'status--new' },
      packing: { label: 'Собирается', cls: 'status--packing' },
      shipped: { label: 'Отправлен', cls: 'status--shipped' },
      delivered: { label: 'Доставлен', cls: 'status--delivered' },
      cancelled: { label: 'Отменён', cls: 'status--cancelled' },
      returned: { label: 'Возврат', cls: 'status--returned' }
    };

    app.innerHTML = `
      <div class="container">
        ${breadcrumbs([
          { label: 'Главная', href: '#/' },
          { label: 'Личный кабинет', href: '#/account' },
          { label: 'Мои заказы', href: '' }
        ])}
        <h1>Мои заказы</h1>
        <div class="account">
          ${renderAccountMenu('orders')}
          <div class="account__content">
            ${orders.length ? orders.map(o => `
              <div class="order-card">
                <div class="order-card__head">
                  <div>
                    <div class="order-card__num">Заказ ${o.id}</div>
                    <div style="font-size:13px;color:var(--text-2)">
                      от ${new Date(o.date).toLocaleDateString('ru-RU')} · 
                      ${(S.DELIVERY[o.delivery] || {}).label || o.delivery}
                    </div>
                  </div>
                  <span class="status ${statusMap[o.status].cls}">${statusMap[o.status].label}</span>
                </div>
                <div style="font-size:14px;margin-bottom:10px">
                  ${o.items.map(it => `• ${esc(it.name)} × ${it.qty}`).join('<br>')}
                </div>
                <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px">
                  <b>Итого: ${formatPrice(o.total)}</b>
                  <div style="display:flex;gap:8px;flex-wrap:wrap">
                    ${o.status === 'new' ? `<button class="btn btn--sm btn--danger" data-cancel="${o.id}">Отменить</button>` : ''}
                    ${o.status === 'delivered' ? `<button class="btn btn--sm btn--outline" data-return="${o.id}">Оформить возврат</button>` : ''}
                    <button class="btn btn--sm btn--outline" data-details="${o.id}">Детали</button>
                  </div>
                </div>
              </div>
            `).join('') : `
              <div class="empty"><div class="empty__ico">📦</div><h3>Заказов пока нет</h3><p>Самое время что-нибудь заказать!</p><a href="#/catalog" class="btn btn--primary">В каталог</a></div>`}
          </div>
        </div>
      </div>`;
    bindAccountLayout(app);

    app.querySelectorAll('[data-cancel]').forEach(b => {
      b.addEventListener('click', () => {
        confirmModal('Отменить заказ?', () => {
          const o = state.orders.find(x => x.id === b.dataset.cancel);
          o.status = 'cancelled';
          write('sportx_orders', state.orders);
          toast('Заказ отменён', 'info');
          S.navigate();
        });
      });
    });

    app.querySelectorAll('[data-return]').forEach(b => {
      b.addEventListener('click', () => {
        confirmModal('Оформить возврат? Средства вернутся на карту в течение 5–10 дней.', () => {
          const o = state.orders.find(x => x.id === b.dataset.return);
          o.status = 'returned';
          write('sportx_orders', state.orders);
          toast('Заявка на возврат принята', 'success');
          S.navigate();
        });
      });
    });

    app.querySelectorAll('[data-details]').forEach(b => {
      b.addEventListener('click', () => {
        const o = state.orders.find(x => x.id === b.dataset.details);
        modal(`
          <h3>Заказ ${o.id}</h3>
          <p style="color:var(--text-2);font-size:13px">
            ${new Date(o.date).toLocaleString('ru-RU')} · Статус: ${statusMap[o.status].label}
          </p>
          <h4 style="margin-top:16px">Состав</h4>
          ${o.items.map(it => `
            <div class="summary__row">
              <span>${esc(it.name)} ${it.size ? '· ' + it.size : ''} × ${it.qty}</span>
              <span>${formatPrice(it.price * it.qty)}</span>
            </div>
          `).join('')}
          <div class="summary__row"><span>Доставка</span><span>${o.deliveryCost === 0 ? 'Бесплатно' : formatPrice(o.deliveryCost)}</span></div>
          ${o.discount ? `<div class="summary__row"><span>Скидка</span><span>−${formatPrice(o.discount)}</span></div>` : ''}
          <div class="summary__row total"><span>Итого</span><span>${formatPrice(o.total)}</span></div>
          <h4 style="margin-top:16px">Доставка</h4>
          <p>${esc(o.address || 'Самовывоз')}</p>
          <h4 style="margin-top:16px">Оплата</h4>
          <p>${esc(o.payment)}</p>
        `);
      });
    });
  });

  /* ============================================================
     АДРЕСА
     ============================================================ */
  route('/account/addresses', (app) => {
    if (!auth.requireRole()) return;
    const list = read('sportx_addresses', []);

    app.innerHTML = `
      <div class="container">
        ${breadcrumbs([
          { label: 'Главная', href: '#/' },
          { label: 'Личный кабинет', href: '#/account' },
          { label: 'Адреса', href: '' }
        ])}
        <h1>Мои адреса</h1>
        <div class="account">
          ${renderAccountMenu('addresses')}
          <div class="account__content">
            <button class="btn btn--primary" id="addAddrBtn" style="margin-bottom:16px">+ Добавить адрес</button>
            <div id="addrList">
              ${list.length ? list.map((a, i) => `
                <div class="order-card">
                  <div class="order-card__head">
                    <b>${esc(a.title)}</b>
                    <div style="display:flex;gap:6px">
                      ${a.primary ? '<span class="tag tag--hit">Основной</span>' : ''}
                      <button class="btn btn--sm btn--outline" data-edit="${i}">Изменить</button>
                      <button class="btn btn--sm btn--danger" data-del="${i}">Удалить</button>
                    </div>
                  </div>
                  <p style="margin:0">${esc(a.address)}</p>
                  <p style="margin:4px 0 0;color:var(--text-2);font-size:13px">${esc(a.phone || '')}</p>
                  ${!a.primary ? `<button class="btn btn--sm btn--ghost" data-primary="${i}" style="margin-top:10px">Сделать основным</button>` : ''}
                </div>
              `).join('') : '<div class="empty"><div class="empty__ico">📍</div><h3>Адресов пока нет</h3></div>'}
            </div>
          </div>
        </div>
      </div>`;
    bindAccountLayout(app);

    function openForm(editIdx) {
      const a = editIdx != null ? list[editIdx] : { title: '', address: '', phone: '', primary: false };
      modal(`
        <h3>${editIdx != null ? 'Редактирование адреса' : 'Новый адрес'}</h3>
        <div class="field"><label>Название</label><input type="text" id="aTitle" value="${esc(a.title)}" placeholder="Дом, Работа"></div>
        <div class="field" style="margin-top:10px"><label>Адрес</label><input type="text" id="aAddress" value="${esc(a.address)}" placeholder="Великий Новгород, ул. ..."></div>
        <div class="field" style="margin-top:10px"><label>Телефон</label><input type="tel" id="aPhone" value="${esc(a.phone)}"></div>
        <label style="font-size:13px;display:flex;gap:8px;margin-top:10px">
          <input type="checkbox" id="aPrimary" ${a.primary ? 'checked' : ''}> Сделать основным
        </label>
        <button class="btn btn--primary btn--block" id="saveAddr" style="margin-top:16px">Сохранить</button>
      `, {
        onOpen(root) {
          root.querySelector('#saveAddr').addEventListener('click', () => {
            const obj = {
              title: root.querySelector('#aTitle').value.trim() || 'Адрес',
              address: root.querySelector('#aAddress').value.trim(),
              phone: root.querySelector('#aPhone').value.trim(),
              primary: root.querySelector('#aPrimary').checked
            };
            if (!obj.address) { toast('Укажите адрес', 'error'); return; }
            if (obj.primary) list.forEach(x => x.primary = false);
            if (editIdx != null) list[editIdx] = obj; else list.push(obj);
            if (!list.some(x => x.primary) && list.length) list[0].primary = true;
            write('sportx_addresses', list);
            closeModal();
            toast('Адрес сохранён', 'success');
            S.navigate();
          });
        }
      });
    }

    $('#addAddrBtn').addEventListener('click', () => openForm());
    app.querySelectorAll('[data-edit]').forEach(b => b.addEventListener('click', () => openForm(+b.dataset.edit)));
    app.querySelectorAll('[data-del]').forEach(b => b.addEventListener('click', () => {
      confirmModal('Удалить адрес?', () => {
        list.splice(+b.dataset.del, 1);
        write('sportx_addresses', list);
        S.navigate();
      });
    }));
    app.querySelectorAll('[data-primary]').forEach(b => b.addEventListener('click', () => {
      list.forEach(x => x.primary = false);
      list[+b.dataset.primary].primary = true;
      write('sportx_addresses', list);
      S.navigate();
    }));
  });

  /* ============================================================
     БОНУСЫ
     ============================================================ */
  route('/account/bonus', (app) => {
    if (!auth.requireRole()) return;
    const b = state.bonus;
    const nextLevel = b.points < 1000 ? 1000 : b.points < 3000 ? 3000 : null;
    const progress = nextLevel ? Math.min(100, Math.round(b.points / nextLevel * 100)) : 100;

    app.innerHTML = `
      <div class="container">
        ${breadcrumbs([
          { label: 'Главная', href: '#/' },
          { label: 'Личный кабинет', href: '#/account' },
          { label: 'Бонусы', href: '' }
        ])}
        <h1>Бонусная программа</h1>
        <div class="account">
          ${renderAccountMenu('bonus')}
          <div class="account__content">
            <div class="loyalty-card">
              <h3>Ваш баланс</h3>
              <div class="points">${b.points} <span style="font-size:18px;color:#C9CED8">баллов</span></div>
              <span class="level">Уровень: ${esc(b.level)}</span>
              ${nextLevel ? `
                <div style="margin-top:16px">
                  <div style="font-size:13px;margin-bottom:6px">До следующего уровня: ${nextLevel - b.points} баллов</div>
                  <div style="height:8px;background:rgba(255,255,255,.15);border-radius:4px;overflow:hidden">
                    <div style="height:100%;width:${progress}%;background:var(--accent);border-radius:4px"></div>
                  </div>
                </div>
              ` : '<div style="margin-top:16px;color:var(--accent);font-weight:700">🏆 Максимальный уровень достигнут!</div>'}
            </div>

            <h3>Как копить баллы</h3>
            <ul style="line-height:1.9">
              <li>1 балл за каждые 100 ₽ в заказе</li>
              <li>+200 баллов за регистрацию</li>
              <li>+50 баллов за отзыв с фото</li>
              <li>×2 балла в день рождения</li>
            </ul>
            <h3 style="margin-top:20px">Как тратить</h3>
            <p>До 30% от суммы заказа можно оплатить баллами. 1 балл = 1 ₽.</p>

            <h3 style="margin-top:20px">История начислений</h3>
            ${b.history.length ? `
              <div class="table-wrap" style="margin-top:12px">
                <table>
                  <thead><tr><th>Дата</th><th>Операция</th><th>Баллы</th></tr></thead>
                  <tbody>
                    ${b.history.slice().reverse().map(h => `
                      <tr>
                        <td>${new Date(h.date).toLocaleDateString('ru-RU')}</td>
                        <td>${esc(h.reason)}</td>
                        <td style="color:var(--success);font-weight:700">+${h.points}</td>
                      </tr>
                    `).join('')}
                  </tbody>
                </table>
              </div>` : '<p style="color:var(--text-2)">Пока нет операций</p>'}
          </div>
        </div>
      </div>`;
    bindAccountLayout(app);
  });

  /* ============================================================
     МОИ ОТЗЫВЫ
     ============================================================ */
  route('/account/reviews', (app) => {
    if (!auth.requireRole()) return;
    const my = state.reviews.filter(r => r.userId === state.user.id);

    app.innerHTML = `
      <div class="container">
        ${breadcrumbs([
          { label: 'Главная', href: '#/' },
          { label: 'Личный кабинет', href: '#/account' },
          { label: 'Мои отзывы', href: '' }
        ])}
        <h1>Мои отзывы</h1>
        <div class="account">
          ${renderAccountMenu('reviews')}
          <div class="account__content">
            ${my.length ? my.map(r => {
              const p = state.products.find(x => x.id === r.productId);
              return `
                <div class="review">
                  <div class="review__head">
                    <div>
                      <a href="#/product/${r.productId}" style="font-weight:600">${esc(p ? p.name : 'Товар')}</a>
                      <div class="review__date">${new Date(r.date).toLocaleDateString('ru-RU')}</div>
                    </div>
                    <div class="review__stars">${'★'.repeat(r.rating)}${'☆'.repeat(5 - r.rating)}</div>
                  </div>
                  <p style="margin:8px 0 0">${esc(r.text)}</p>
                  <button class="btn btn--sm btn--danger" data-delrev="${r.id}" style="margin-top:10px">Удалить</button>
                </div>`;
            }).join('') : '<div class="empty"><div class="empty__ico">⭐</div><h3>Отзывов пока нет</h3><p>Оставьте отзыв на купленный товар и получите 50 бонусов.</p></div>'}
          </div>
        </div>
      </div>`;
    bindAccountLayout(app);

    app.querySelectorAll('[data-delrev]').forEach(b => {
      b.addEventListener('click', () => {
        confirmModal('Удалить отзыв?', () => {
          state.reviews = state.reviews.filter(r => r.id !== b.dataset.delrev);
          write('sportx_reviews', state.reviews);
          toast('Отзыв удалён', 'info');
          S.navigate();
        });
      });
    });
  });

})(window.SportX);