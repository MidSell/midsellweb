/* ============================================================
   SportX — ядро приложения
   Роутинг, состояние, корзина, авторизация, утилиты
   ============================================================ */
(function (global) {
  'use strict';

  /* ---------- Константы ---------- */
  const STORAGE = {
    cart: 'sportx_cart',
    fav: 'sportx_fav',
    cmp: 'sportx_cmp',
    user: 'sportx_user',
    users: 'sportx_users',
    orders: 'sportx_orders',
    reviews: 'sportx_reviews',
    promos: 'sportx_promos',
    bonus: 'sportx_bonus',
    addresses: 'sportx_addresses',
    products: 'sportx_products'
  };

  const DEFAULT_PROMOS = {
    SPORT10: { type: 'percent', value: 10, min: 0, active: true },
    NEW2025: { type: 'percent', value: 15, min: 3000, active: true },
    DELIVERY: { type: 'delivery', value: 0, min: 0, active: true }
  };

  const state = {
    products: [],
    categories: [],
    brands: [],
    stores: [],
    cart: [],
    fav: [],
    cmp: [],
    user: null,
    users: [],
    orders: [],
    reviews: [],
    promos: {},
    bonus: {},
    addresses: [],
    page: 'home',
    filters: {}
  };

  /* ---------- Утилиты ---------- */
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

  function esc(s) {
    if (s == null) return '';
    return String(s).replace(/[&<>"']/g, c => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[c]));
  }

  function formatPrice(n) {
    return Number(n || 0).toLocaleString('ru-RU') + ' ₽';
  }

  function uid(prefix = 'id') {
    return prefix + '_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  }

  function read(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (e) { return fallback; }
  }

  function write(key, val) {
    try { localStorage.setItem(key, JSON.stringify(val)); } catch (e) {}
  }

  async function fetchJSON(url) {
    const r = await fetch(url);
    if (!r.ok) throw new Error('Не удалось загрузить ' + url);
    return r.json();
  }

  function debounce(fn, ms = 250) {
    let t;
    return function (...args) {
      clearTimeout(t);
      t = setTimeout(() => fn.apply(this, args), ms);
    };
  }

  /* ---------- Toast ---------- */
  function toast(msg, type = 'info', ttl = 3500) {
    const root = $('#toasts');
    if (!root) return;
    const el = document.createElement('div');
    el.className = 'toast toast--' + type;
    el.textContent = msg;
    root.appendChild(el);
    setTimeout(() => {
      el.style.opacity = '0';
      el.style.transform = 'translateX(30px)';
      setTimeout(() => el.remove(), 300);
    }, ttl);
  }

  /* ---------- Modal ---------- */
  function modal(contentHTML, opts = {}) {
    const root = $('#modalRoot');
    if (!root) return;
    root.innerHTML = `
      <div class="modal-backdrop" data-close></div>
      <div class="modal" role="dialog" aria-modal="true">
        <button class="modal__close" data-close aria-label="Закрыть">×</button>
        ${contentHTML}
      </div>`;
    root.classList.add('open');
    root.onclick = (e) => {
      if (e.target.hasAttribute('data-close')) closeModal();
    };
    if (opts.onOpen) opts.onOpen(root);
  }

  function closeModal() {
    const root = $('#modalRoot');
    if (!root) return;
    root.classList.remove('open');
    root.innerHTML = '';
  }

  function confirmModal(message, onConfirm, opts = {}) {
    modal(`
      <h3>${esc(opts.title || 'Подтвердите действие')}</h3>
      <p>${esc(message)}</p>
      <div style="display:flex;gap:10px;margin-top:20px">
        <button class="btn btn--primary" id="mConfirm">${esc(opts.okText || 'Подтвердить')}</button>
        <button class="btn btn--outline" data-close>Отмена</button>
      </div>
    `, {
      onOpen(root) {
        const btn = root.querySelector('#mConfirm');
        btn.addEventListener('click', () => { closeModal(); onConfirm(); });
      }
    });
  }

  /* ---------- Корзина ---------- */
  const cart = {
    add(productId, qty = 1, opts = {}) {
      const p = state.products.find(x => x.id === productId);
      if (!p) return;
      const size = opts.size || (p.sizes && p.sizes[0]) || null;
      const color = opts.color || (p.colors && p.colors[0]) || null;
      const key = [productId, size, color].filter(Boolean).join('|');
      const item = state.cart.find(x => x.key === key);
      if (item) {
        item.qty += qty;
      } else {
        state.cart.push({
          key, productId, size, color, qty,
          price: p.price,
          name: p.name,
          image: p.images[0]
        });
      }
      cart.save();
      cart.updateBadge();
      toast('Товар добавлен в корзину', 'success');
    },
    remove(key) {
      state.cart = state.cart.filter(x => x.key !== key);
      cart.save();
      cart.updateBadge();
    },
    setQty(key, qty) {
      const item = state.cart.find(x => x.key === key);
      if (!item) return;
      item.qty = Math.max(1, Math.min(99, qty));
      cart.save();
      cart.updateBadge();
    },
    clear() { state.cart = []; cart.save(); cart.updateBadge(); },
    save() { write(STORAGE.cart, state.cart); },
    updateBadge() {
      const total = state.cart.reduce((s, i) => s + i.qty, 0);
      document.querySelectorAll('[data-count="cart"]').forEach(b => {
        b.textContent = total;
        b.hidden = total === 0;
      });
    },
    subtotal() { return state.cart.reduce((s, i) => s + i.price * i.qty, 0); },
    applyPromo(code) {
      const promo = state.promos[code.toUpperCase()];
      if (!promo || !promo.active) throw new Error('Промокод не найден');
      if (promo.min && cart.subtotal() < promo.min)
        throw new Error('Минимальная сумма: ' + formatPrice(promo.min));
      return promo;
    }
  };

  /* ---------- Избранное ---------- */
  const fav = {
    toggle(id) {
      const i = state.fav.indexOf(id);
      if (i >= 0) { state.fav.splice(i, 1); toast('Удалено из избранного', 'info'); }
      else { state.fav.push(id); toast('Добавлено в избранное', 'success'); }
      write(STORAGE.fav, state.fav);
      fav.updateBadge();
      document.dispatchEvent(new CustomEvent('fav:changed'));
    },
    has(id) { return state.fav.includes(id); },
    updateBadge() {
      document.querySelectorAll('[data-count="fav"]').forEach(b => {
        b.textContent = state.fav.length;
        b.hidden = state.fav.length === 0;
      });
    }
  };

  /* ---------- Сравнение ---------- */
  const cmp = {
    toggle(id) {
      const i = state.cmp.indexOf(id);
      if (i >= 0) state.cmp.splice(i, 1);
      else {
        if (state.cmp.length >= 4) { toast('Максимум 4 товара для сравнения', 'error'); return; }
        state.cmp.push(id);
      }
      write(STORAGE.cmp, state.cmp);
      cmp.updateBadge();
      document.dispatchEvent(new CustomEvent('cmp:changed'));
    },
    has(id) { return state.cmp.includes(id); },
    updateBadge() {
      document.querySelectorAll('[data-count="cmp"]').forEach(b => {
        b.textContent = state.cmp.length;
        b.hidden = state.cmp.length === 0;
      });
    }
  };

  /* ---------- Auth ---------- */
  const auth = {
    hash(str) {
      // Простой хэш для демо (в production использовать bcrypt/argon2 на сервере)
      let h = 0;
      for (let i = 0; i < str.length; i++) {
        h = ((h << 5) - h) + str.charCodeAt(i);
        h |= 0;
      }
      return 'h' + Math.abs(h).toString(36) + str.length;
    },
    seed() {
      const users = read(STORAGE.users, null);
      if (users && users.length) return users;
      const demo = [
        {
          id: 'u_admin', email: 'admin@sportx.ru', phone: '+78162000001',
          name: 'Администратор', role: 'admin',
          pass: auth.hash('admin123'), createdAt: Date.now()
        },
        {
          id: 'u_user', email: 'user@sportx.ru', phone: '+78162000002',
          name: 'Иван Петров', role: 'customer',
          pass: auth.hash('user123'), createdAt: Date.now()
        }
      ];
      write(STORAGE.users, demo);
      return demo;
    },
    login(login, password) {
      const users = read(STORAGE.users, []);
      const pass = auth.hash(password);
      const u = users.find(x =>
        (x.email === login || x.phone === login) && x.pass === pass
      );
      if (!u) throw new Error('Неверный email/телефон или пароль');
      if (u.blocked) throw new Error('Аккаунт заблокирован');
      state.user = { id: u.id, email: u.email, phone: u.phone, name: u.name, role: u.role };
      write(STORAGE.user, state.user);
      auth.renderHeader();
      document.dispatchEvent(new CustomEvent('auth:changed'));
      toast('Добро пожаловать, ' + u.name + '!', 'success');
      return state.user;
    },
    register(data) {
      const users = read(STORAGE.users, []);
      if (users.some(u => u.email === data.email || u.phone === data.phone))
        throw new Error('Пользователь с таким email или телефоном уже существует');
      const u = {
        id: uid('u'),
        email: data.email, phone: data.phone, name: data.name,
        role: 'customer', pass: auth.hash(data.password),
        createdAt: Date.now()
      };
      users.push(u);
      write(STORAGE.users, users);
      state.user = { id: u.id, email: u.email, phone: u.phone, name: u.name, role: u.role };
      write(STORAGE.user, state.user);
      auth.renderHeader();
      document.dispatchEvent(new CustomEvent('auth:changed'));
      toast('Регистрация успешна!', 'success');
      return state.user;
    },
    logout() {
      state.user = null;
      localStorage.removeItem(STORAGE.user);
      auth.renderHeader();
      document.dispatchEvent(new CustomEvent('auth:changed'));
      toast('Вы вышли из аккаунта', 'info');
      location.hash = '#/';
    },
    requireRole(role) {
      if (!state.user) { location.hash = '#/login'; return false; }
      if (role && state.user.role !== role) {
        toast('Доступ запрещён', 'error');
        location.hash = '#/';
        return false;
      }
      return true;
    },
    renderHeader() {
      const lbl = document.getElementById('accountLbl');
      const link = document.getElementById('accountLink');
      if (!lbl || !link) return;
      if (state.user) {
        lbl.textContent = state.user.name.split(' ')[0];
        link.href = state.user.role === 'admin' ? '#/admin' : '#/account';
      } else {
        lbl.textContent = 'Войти';
        link.href = '#/login';
      }
    }
  };

  /* ---------- Роутинг ---------- */
  const routes = {};

  function route(path, handler) {
    routes[path] = handler;
  }

  function parseHash() {
    const h = location.hash.replace(/^#/, '') || '/';
    const [path, query] = h.split('?');
    const params = {};
    if (query) {
      query.split('&').forEach(kv => {
        const [k, v] = kv.split('=');
        params[decodeURIComponent(k)] = decodeURIComponent(v || '');
      });
    }
    return { path: path || '/', params };
  }

  function navigate() {
    const { path, params } = parseHash();
    let handler = routes[path];
    if (!handler) {
      // попробуем найти динамический роут: /product/:id
      for (const r in routes) {
        if (r.includes(':')) {
          const parts = r.split('/').filter(Boolean);
          const ppath = path.split('/').filter(Boolean);
          if (parts.length !== ppath.length) continue;
          const dyn = {};
          let ok = true;
          for (let i = 0; i < parts.length; i++) {
            if (parts[i].startsWith(':')) dyn[parts[i].slice(1)] = ppath[i];
            else if (parts[i] !== ppath[i]) { ok = false; break; }
          }
          if (ok) { handler = routes[r]; params._dyn = dyn; break; }
        }
      }
    }
    if (!handler) handler = routes['/404'] || (() => {
      const app = document.getElementById('app');
      if (app) app.innerHTML = '<div class="container"><div class="empty"><div class="empty__ico">🧭</div><h3>Страница не найдена</h3><p>Проверьте адрес или вернитесь на <a href="#/">главную</a>.</p></div></div>';
    });

    const app = document.getElementById('app');
    // skeleton
    app.innerHTML = '<div class="container"><div class="skeleton-page"><div class="sk sk-h"></div><div class="sk-grid"><div class="sk sk-c"></div><div class="sk sk-c"></div><div class="sk sk-c"></div><div class="sk sk-c"></div></div></div></div>';

    setTimeout(() => {
      try {
        handler(app, params);
      } catch (e) {
        console.error(e);
        app.innerHTML = '<div class="container"><div class="empty"><div class="empty__ico">⚠️</div><h3>Ошибка</h3><p>' + esc(e.message) + '</p></div></div>';
      }
      window.scrollTo({ top: 0, behavior: 'instant' });
    }, 120);
  }

  function go(path) { location.hash = '#' + path; }

  /* ---------- Инициализация данных ---------- */
  async function loadData() {
    try {
      const [products, categories, brands, stores] = await Promise.all([
        fetchJSON('data/products.json').catch(() => []),
        fetchJSON('data/categories.json').catch(() => []),
        fetchJSON('data/brands.json').catch(() => []),
        fetchJSON('data/stores.json').catch(() => [])
      ]);
      state.products = read(STORAGE.products, products);
      state.categories = categories;
      state.brands = brands;
      state.stores = stores;
    } catch (e) {
      console.error('Ошибка загрузки данных', e);
    }
    state.cart = read(STORAGE.cart, []);
    state.fav = read(STORAGE.fav, []);
    state.cmp = read(STORAGE.cmp, []);
    state.users = auth.seed();
    state.user = read(STORAGE.user, null);
    state.orders = read(STORAGE.orders, seedOrders());
    state.reviews = read(STORAGE.reviews, seedReviews());
    state.promos = read(STORAGE.promos, DEFAULT_PROMOS);
    state.bonus = read(STORAGE.bonus, { points: 0, level: 'Bronze', history: [] });
    state.addresses = read(STORAGE.addresses, []);
    write(STORAGE.orders, state.orders);
    write(STORAGE.reviews, state.reviews);
  }

  function seedOrders() {
    return [
      {
        id: 'SX-2025-0001', userId: 'u_user', date: Date.now() - 86400000 * 5,
        status: 'delivered', total: 7990, payment: 'card', delivery: 'courier',
        address: 'Великий Новгород, ул. Большая Московская, 44',
        items: [
          { productId: 'p001', name: 'Кроссовки Nike Revolution 7', price: 5490, qty: 1, size: '42', color: 'чёрный' },
          { productId: 'p015', name: 'Бутылка для воды 750 мл', price: 690, qty: 1, size: null, color: 'оранжевый' }
        ]
      },
      {
        id: 'SX-2025-0002', userId: 'u_user', date: Date.now() - 86400000 * 2,
        status: 'shipped', total: 18990, payment: 'sbp', delivery: 'cdek',
        address: 'Великий Новгород, ул. Псковская, 15',
        items: [
          { productId: 'p002', name: 'Велосипед горный SportX MTB 27.5', price: 24990, qty: 1, size: 'M', color: 'чёрный' }
        ]
      }
    ];
  }

  function seedReviews() {
    return [
      { id: 'r1', productId: 'p001', userId: 'u_user', author: 'Иван П.', rating: 5, text: 'Отличные кроссовки, бегаю каждый день, очень доволен!', date: Date.now() - 86400000 * 10 },
      { id: 'r2', productId: 'p001', userId: 'u_admin', author: 'Алексей С.', rating: 4, text: 'Хорошая амортизация, но немного узкие.', date: Date.now() - 86400000 * 8 },
      { id: 'r3', productId: 'p002', userId: 'u_user', author: 'Мария К.', rating: 5, text: 'Велосипед супер, катаюсь по набережной!', date: Date.now() - 86400000 * 5 },
      { id: 'r4', productId: 'p004', userId: 'u_user', author: 'Дмитрий Л.', rating: 5, text: 'Гантели удобные, обрезинка не пахнет.', date: Date.now() - 86400000 * 3 }
    ];
  }

  /* ---------- Хедер / навбар ---------- */
  function renderNav() {
    const nav = document.getElementById('navCats');
    const foot = document.getElementById('footCats');
    if (nav) {
      nav.innerHTML =
        '<a class="nav-link" href="#/catalog">Все товары</a>' +
        state.categories.map(c =>
          `<a class="nav-link" href="#/catalog?cat=${c.id}">${c.icon} ${esc(c.name)}</a>`
        ).join('') +
        '<a class="nav-link" href="#/map">📍 Пункты выдачи</a>' +
        '<a class="nav-link" href="#/delivery">🚚 Доставка</a>';
    }
    if (foot) {
      foot.innerHTML = state.categories.map(c =>
        `<li><a href="#/catalog?cat=${c.id}">${esc(c.name)}</a></li>`
      ).join('');
    }
  }

  /* ---------- Подсчёт хедера при скролле ---------- */
  function bindScroll() {
    const header = document.getElementById('header');
    const onScroll = () => {
      if (window.scrollY > 20) header.classList.add('is-scrolled');
      else header.classList.remove('is-scrolled');
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  /* ---------- Мобильное меню ---------- */
  function bindBurger() {
    const b = document.getElementById('burger');
    const nav = document.getElementById('navbar');
    if (!b || !nav) return;
    b.addEventListener('click', () => nav.classList.toggle('open'));
  }

  /* ---------- Поиск с автодополнением ---------- */
  function bindSearch() {
    const form = document.getElementById('searchForm');
    const input = document.getElementById('searchInput');
    const box = document.getElementById('suggest');
    if (!form || !input || !box) return;

    form.addEventListener('submit', e => {
      e.preventDefault();
      const q = input.value.trim();
      if (!q) return;
      box.hidden = true;
      location.hash = '#/catalog?q=' + encodeURIComponent(q);
    });

    const update = debounce(() => {
      const q = input.value.trim().toLowerCase();
      if (q.length < 2) { box.hidden = true; return; }
      const found = state.products.filter(p =>
        p.name.toLowerCase().includes(q) ||
        p.brand.toLowerCase().includes(q)
      ).slice(0, 6);
      if (!found.length) { box.hidden = true; return; }
      box.innerHTML = found.map(p => `
        <div class="suggest__item" data-id="${p.id}">
          <img src="${p.images[0]}" alt="${esc(p.name)}">
          <div>
            <div class="s-name">${esc(p.name)}</div>
            <div class="s-price">${formatPrice(p.price)}</div>
          </div>
        </div>
      `).join('');
      box.hidden = false;
      box.querySelectorAll('.suggest__item').forEach(el => {
        el.addEventListener('click', () => {
          box.hidden = true;
          input.value = '';
          location.hash = '#/product/' + el.dataset.id;
        });
      });
    }, 200);

    input.addEventListener('input', update);
    input.addEventListener('blur', () => setTimeout(() => box.hidden = true, 180));
    input.addEventListener('focus', update);
  }

  /* ---------- Хлебные крошки ---------- */
  function breadcrumbs(items) {
    return '<nav class="breadcrumbs" aria-label="Хлебные крошки">' +
      items.map((it, i) => {
        if (i === items.length - 1) return '<span>' + esc(it.label) + '</span>';
        return `<a href="${it.href}">${esc(it.label)}</a>`;
      }).join('<span>/</span>') +
      '</nav>';
  }

  /* ---------- Промо-код ---------- */
  function validatePromo(code) {
    const p = state.promos[code.toUpperCase()];
    if (!p || !p.active) throw new Error('Промокод не найден');
    if (p.min && cart.subtotal() < p.min)
      throw new Error('Минимальная сумма заказа: ' + formatPrice(p.min));
    return p;
  }

  /* ---------- Расчёт доставки ---------- */
  const DELIVERY = {
    courier: { label: 'Курьер по Великому Новгороду', base: 300, perKg: 30, days: '1–2 дня', freeFrom: 5000 },
    cdek:    { label: 'СДЭК',                          base: 400, perKg: 50, days: '3–7 дней', freeFrom: 8000 },
    post:    { label: 'Почта России',                  base: 250, perKg: 40, days: '5–14 дней', freeFrom: 10000 },
    pickup:  { label: 'Самовывоз',                     base: 0,   perKg: 0,  days: 'сегодня', freeFrom: 0 }
  };

  function calcDelivery(method, weightKg, subtotal) {
    const d = DELIVERY[method] || DELIVERY.courier;
    if (d.freeFrom && subtotal >= d.freeFrom) return 0;
    return d.base + (d.perKg * (weightKg || 1));
  }

  /* ---------- Экспорт ---------- */
  global.SportX = {
    state, $, $$, esc, formatPrice, uid, read, write, fetchJSON, debounce,
    toast, modal, closeModal, confirmModal,
    cart, fav, cmp, auth,
    route, navigate, go, routes,
    breadcrumbs, validatePromo, calcDelivery, DELIVERY,
    renderNav, loadData
  };

  /* ---------- Boot ---------- */
  global.SportX.boot = async function boot() {
    document.getElementById('year').textContent = new Date().getFullYear();
    await loadData();
    renderNav();
    auth.renderHeader();
    cart.updateBadge();
    fav.updateBadge();
    cmp.updateBadge();
    bindScroll();
    bindBurger();
    bindSearch();
    window.addEventListener('hashchange', navigate);
    if (!location.hash) location.hash = '#/';
    navigate();
  };

})(window);