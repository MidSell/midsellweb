import os
import threading
import vk_api
from vk_api.bot_longpoll import VkBotLongPoll, VkBotEventType
from vk_api.keyboard import VkKeyboard, VkKeyboardColor
from vk_api.utils import get_random_id


# =====================================================================
#                            НАСТРОЙКИ
# =====================================================================

TOKEN = "vk1.a.lRALODBA9nt7qAFxO2eWn000MAWR2IeqgOY6--gZQeHosyZ08OjY6e7lZPtQRSQVdH-sjaRjI00EmWn9Y4aqfp3OtmrQOWLvgosLG-sNKNnSFZsTo4WSEYNQNEmyDdZ0De6CmoZziDwVmKbbPXWzxp43hU3Va2NVUa6AKjGvIs-DZT--T8BqzT_JAoKwb2vjbdO9Y3SR9zN-gsfB96fFtA"
GROUP_ID = 241540305  # ID вашей группы

# Путь к приветственной картинке (положите файл рядом с bot.py)
WELCOME_IMAGE = "welcome.jpg"

# --- ВАШИ ССЫЛКИ ---
LINKS = {
    "telegram": "https://t.me/@MidSell",
    "github":   "https://github.com/MidSell/midsellweb",
    "drive":    "https://drive.google.com/drive/my-drive?hl=ru",
    "vk":       "https://vk.ru/id298430488",
}


# =====================================================================
#                          ИНИЦИАЛИЗАЦИЯ
# =====================================================================

vk_session = vk_api.VkApi(token=TOKEN)
vk = vk_session.get_api()
longpoll = VkBotLongPoll(vk_session, GROUP_ID)

# Глобальная переменная для ID загруженного фото
WELCOME_ATTACHMENT = None


# =====================================================================
#                    ЗАГРУЗКА ПРИВЕТСТВЕННОЙ КАРТИНКИ
# =====================================================================

def upload_welcome_image():
    """Загружает картинку в сообщения сообщества и возвращает attachment."""
    global WELCOME_ATTACHMENT

    if not os.path.exists(WELCOME_IMAGE):
        print(f"⚠️  Файл {WELCOME_IMAGE} не найден — приветствие будет без картинки.")
        return None

    try:
        upload = vk_api.VkUpload(vk_session)
        photo = upload.photo_messages(WELCOME_IMAGE)[0]
        attachment = f"photo{photo['owner_id']}_{photo['id']}"
        WELCOME_ATTACHMENT = attachment
        print(f"✅ Картинка загружена: {attachment}")
        return attachment
    except Exception as e:
        print(f"⚠️  Не удалось загрузить картинку: {e}")
        return None


# =====================================================================
#                          КЛАВИАТУРА
# =====================================================================

def links_keyboard():
    """Красивая клавиатура с 4 кнопками-ссылками."""
    kb = VkKeyboard(inline=True)

    kb.add_openlink_button("📢 Telegram",     link=LINKS["telegram"])
    kb.add_openlink_button("📁 GitHub",       link=LINKS["github"])

    kb.add_line()

    kb.add_openlink_button("☁️ Google Drive", link=LINKS["drive"])
    kb.add_openlink_button("🅥 ВКонтакте",     link=LINKS["vk"])

    return kb


# =====================================================================
#                          ТЕКСТ ПРИВЕТСТВИЯ
# =====================================================================

WELCOME_TEXT = (
    "✨ Добро пожаловать! ✨\n"
    "━━━━━━━━━━━━━━━━━━━━\n\n"
    "Рад видеть вас здесь 👋\n"
    "Ниже — все мои полезные ссылки.\n\n"
    "📍 Telegram · GitHub · Google Drive · VK\n\n"
    "Нажмите на нужную кнопку 👇"
)


# =====================================================================
#                          ОТПРАВКА
# =====================================================================

def send(user_id, text, keyboard=None, attachment=None):
    params = {
        "user_id": user_id,
        "message": text,
        "random_id": get_random_id(),
    }
    if keyboard is not None:
        params["keyboard"] = keyboard.get_keyboard()
    if attachment:
        params["attachment"] = attachment
    vk.messages.send(**params)


def answer_callback_async(event_id, user_id, peer_id):
    """Мгновенно убирает «часики» на кнопке — в фоновом потоке."""
    def _run():
        try:
            vk.messages.sendMessageEventAnswer(
                event_id=event_id,
                user_id=user_id,
                peer_id=peer_id,
                event_data=""
            )
        except Exception:
            pass
    threading.Thread(target=_run, daemon=True).start()


# =====================================================================
#                          ОСНОВНОЙ ЦИКЛ
# =====================================================================

# Загружаем картинку один раз при старте
upload_welcome_image()

print("🤖 Бот запущен. Ожидание сообщений...")

for event in longpoll.listen():

    # ------------------ Входящие сообщения ------------------
    if event.type == VkBotEventType.MESSAGE_NEW:
        msg = event.object.message
        user_id = msg["from_id"]
        text = msg["text"].lower().strip()

        # На любую команду показываем приветствие с картинкой и кнопками
        if text in ("start", "начать", "меню", "menu", "привет",
                    "hi", "hello", "ссылки", "links", ""):
            send(
                user_id,
                WELCOME_TEXT,
                keyboard=links_keyboard(),
                attachment=WELCOME_ATTACHMENT
            )
        else:
            send(
                user_id,
                "✨ Нажмите на кнопку ниже, чтобы открыть нужную ссылку 👇",
                keyboard=links_keyboard(),
                attachment=WELCOME_ATTACHMENT
            )

    # ------------------ Callback-кнопки (на будущее) ------------------
    elif event.type == VkBotEventType.MESSAGE_EVENT:
        answer_callback_async(
            event.object.event_id,
            event.object.user_id,
            event.object.peer_id
        )