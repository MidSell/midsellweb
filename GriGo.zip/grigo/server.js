const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'grigo-dev-secret-change-me';

app.use(express.json({ limit: '1mb' }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

/* ============================================================
   ИН-МЕМОРИ ХРАНИЛИЩЕ (для демо; заменить на SQLite/PG в prod)
   ============================================================ */
const db = {
  users: [], cars: [], bookings: [], tariffs: [], options: [],
  ids: { user: 1, car: 1, booking: 1, tariff: 1 },
};

/* ============================================================
   СИДЫ — реалистичные данные Великого Новгорода
   ============================================================ */
function seed() {
  db.users.push({
    id: db.ids.user++,
    email: 'admin@grigo.ru',
    password: bcrypt.hashSync('admin123', 10),
    name: 'Администратор GriGO',
    phone: '+7 (900) 000-00-01',
    license: '53 АА 000001',
    role: 'admin',
    balance: 0,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 60,
  });
  db.users.push({
    id: db.ids.user++,
    email: 'user@grigo.ru',
    password: bcrypt.hashSync('user123', 10),
    name: 'Иван Петров',
    phone: '+7 (900) 000-00-02',
    license: '53 АА 123456',
    role: 'user',
    balance: 1500,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 30,
  });

  [
    { key: 'minute', name: 'Поминутный', price: 9, unit: '₽/мин', desc: 'Оплата за каждую минуту аренды. Идеально для коротких поездок по городу.', conditions: 'Минимальная стоимость — 90 ₽. Первые 5 минут бесплатно для новых пользователей.', highlight: false },
    { key: 'hour', name: 'Почасовой', price: 349, unit: '₽/час', desc: 'Фиксированная цена за час аренды. Удобно для деловых встреч и поездок на несколько часов.', conditions: 'Минимальная аренда — 2 часа. Включено 30 км пробега за каждый час.', highlight: true },
    { key: 'day', name: 'Суточный', price: 2490, unit: '₽/сутки', desc: 'Аренда на целые сутки. Отличный выбор для загородных поездок.', conditions: 'Включено 200 км пробега. Перепробег — 12 ₽/км.', highlight: false },
    { key: 'weekend', name: 'Выходные', price: 4490, unit: '₽/выходные', desc: 'Аренда с 18:00 пятницы до 23:59 воскресенья.', conditions: 'Включено 400 км. Бронирование не позднее 12:00 пятницы.', highlight: false },
    { key: 'deposit', name: 'Депозит', price: 5000, unit: '₽', desc: 'Возвратный страховой депозит для новых водителей.', conditions: 'Возврат в течение 3 рабочих дней. Не требуется при рейтинге 4.8+.', highlight: false },
    { key: 'insurance', name: 'Страховка КАСКО+', price: 149, unit: '₽/поездка', desc: 'Полное покрытие с франшизой 0 ₽.', conditions: 'Обязательна для водителей со стажем менее 2 лет.', highlight: false },
  ].forEach(x => db.tariffs.push({ id: db.ids.tariff++, ...x }));

  db.options = [
    { id: 1, name: 'Детское кресло', price: 250, unit: '₽/сутки' },
    { id: 2, name: 'Парковка в центре', price: 150, unit: '₽/час' },
    { id: 3, name: 'Мойка автомобиля', price: 500, unit: '₽' },
    { id: 4, name: 'Заправка/зарядка', price: 300, unit: '₽ + топливо' },
  ];

  const cars = [
    { model: 'Kia Rio', plate: 'А123ВС53', type: 'Эконом', transmission: 'Автомат', fuel: 'Бензин', fuelLevel: 78, pricePerMin: 9, lat: 58.5215, lng: 31.2755, status: 'available', year: 2022, color: 'Белый' },
    { model: 'Hyundai Solaris', plate: 'В456ЕК53', type: 'Эконом', transmission: 'Автомат', fuel: 'Бензин', fuelLevel: 62, pricePerMin: 9, lat: 58.5290, lng: 31.2710, status: 'available', year: 2021, color: 'Серебристый' },
    { model: 'Lada Vesta', plate: 'Е789КМ53', type: 'Эконом', transmission: 'Механика', fuel: 'Бензин', fuelLevel: 45, pricePerMin: 8, lat: 58.5150, lng: 31.2830, status: 'available', year: 2023, color: 'Синий' },
    { model: 'Volkswagen Polo', plate: 'К321МН53', type: 'Комфорт', transmission: 'Автомат', fuel: 'Бензин', fuelLevel: 88, pricePerMin: 11, lat: 58.5250, lng: 31.2600, status: 'available', year: 2022, color: 'Красный' },
    { model: 'Skoda Octavia', plate: 'М654ОР53', type: 'Комфорт', transmission: 'Автомат', fuel: 'Бензин', fuelLevel: 71, pricePerMin: 13, lat: 58.5180, lng: 31.2900, status: 'available', year: 2023, color: 'Чёрный' },
    { model: 'Toyota Camry', plate: 'Н987РС53', type: 'Бизнес', transmission: 'Автомат', fuel: 'Бензин', fuelLevel: 93, pricePerMin: 19, lat: 58.5320, lng: 31.2450, status: 'available', year: 2023, color: 'Чёрный' },
    { model: 'BMW 3 серии', plate: 'О147ТУ53', type: 'Бизнес', transmission: 'Автомат', fuel: 'Бензин', fuelLevel: 55, pricePerMin: 22, lat: 58.5100, lng: 31.2680, status: 'available', year: 2022, color: 'Синий' },
    { model: 'Nissan X-Trail', plate: 'Р258ФХ53', type: 'Внедорожник', transmission: 'Автомат', fuel: 'Дизель', fuelLevel: 67, pricePerMin: 17, lat: 58.5400, lng: 31.2800, status: 'available', year: 2021, color: 'Серый' },
    { model: 'Tesla Model 3', plate: 'С369ЦЧ53', type: 'Электро', transmission: 'Автомат', fuel: 'Электро', fuelLevel: 84, pricePerMin: 24, lat: 58.5230, lng: 31.2520, status: 'available', year: 2023, color: 'Белый' },
    { model: 'Nissan Leaf', plate: 'Т470ШЩ53', type: 'Электро', transmission: 'Автомат', fuel: 'Электро', fuelLevel: 71, pricePerMin: 14, lat: 58.5170, lng: 31.2790, status: 'available', year: 2020, color: 'Голубой' },
    { model: 'Kia K5', plate: 'У581ЭЮ53', type: 'Комфорт', transmission: 'Автомат', fuel: 'Бензин', fuelLevel: 90, pricePerMin: 15, lat: 58.5260, lng: 31.2900, status: 'maintenance', year: 2022, color: 'Белый' },
    { model: 'Hyundai Creta', plate: 'Ф692ЯА53', type: 'Внедорожник', transmission: 'Автомат', fuel: 'Бензин', fuelLevel: 59, pricePerMin: 14, lat: 58.5120, lng: 31.2560, status: 'available', year: 2023, color: 'Коричневый' },
  ];
  cars.forEach(c => db.cars.push({
    id: db.ids.car++, rating: +(4.6 + Math.random() * 0.4).toFixed(1),
    trips: Math.floor(Math.random() * 200) + 20, ...c,
  }));

  const now = Date.now();
  db.bookings.push({
    id: db.ids.booking++, userId: 2, carId: 1,
    start: now - 1000 * 60 * 60 * 24 * 3,
    end: now - 1000 * 60 * 60 * 24 * 3 + 1000 * 60 * 60 * 2,
    status: 'completed', total: 1300, tariffKey: 'hour',
    route: { start: { lat: 58.5215, lng: 31.2755, name: 'Новгородский кремль' }, end: { lat: 58.5290, lng: 31.2710, name: 'ТЦ «Волна»' }, distance: 3200, duration: 12 },
    createdAt: now - 1000 * 60 * 60 * 24 * 3,
  });
  db.bookings.push({
    id: db.ids.booking++, userId: 2, carId: 4,
    start: now - 1000 * 60 * 60 * 24 * 10,
    end: now - 1000 * 60 * 60 * 24 * 10 + 1000 * 60 * 60 * 5,
    status: 'completed', total: 2100, tariffKey: 'day',
    route: { start: { lat: 58.5250, lng: 31.2600, name: 'ТЦ «Феникс»' }, end: { lat: 58.5400, lng: 31.2800, name: 'Юрьев монастырь' }, distance: 8700, duration: 22 },
    createdAt: now - 1000 * 60 * 60 * 24 * 10,
  });
}
seed();

/* ============================================================
   AUTH middleware
   ============================================================ */
function auth(req, res, next) {
  let token = req.cookies?.token;
  if (!token && req.headers.authorization?.startsWith('Bearer ')) token = req.headers.authorization.slice(7);
  if (!token) return res.status(401).json({ error: 'Требуется авторизация' });
  try {
    const p = jwt.verify(token, JWT_SECRET);
    const user = db.users.find(u => u.id === p.id);
    if (!user) return res.status(401).json({ error: 'Пользователь не найден' });
    req.user = user;
    next();
  } catch {
    return res.status(401).json({ error: 'Сессия истекла, войдите снова' });
  }
}
const adminOnly = (req, res, next) =>
  req.user?.role === 'admin' ? next() : res.status(403).json({ error: 'Доступ только для администратора' });

const publicUser = u => { const { password, ...rest } = u; return rest; };

/* ============================================================
   AUTH ROUTES
   ============================================================ */
app.post('/api/auth/register', async (req, res) => {
  const { email, password, name, phone, license } = req.body || {};
  if (!email || !password || !name) return res.status(400).json({ error: 'Заполните обязательные поля' });
  if (password.length < 6) return res.status(400).json({ error: 'Пароль должен быть не короче 6 символов' });
  if (!/^\S+@\S+\.\S+$/.test(email)) return res.status(400).json({ error: 'Некорректный email' });
  if (db.users.some(u => u.email.toLowerCase() === email.toLowerCase()))
    return res.status(409).json({ error: 'Пользователь с таким email уже существует' });

  const user = {
    id: db.ids.user++, email: email.toLowerCase(),
    password: await bcrypt.hash(password, 10),
    name, phone: phone || '', license: license || '',
    role: 'user', balance: 0, createdAt: Date.now(),
  };
  db.users.push(user);
  const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
  res.cookie('token', token, { httpOnly: true, sameSite: 'lax', maxAge: 7 * 86400e3 });
  res.json({ token, user: publicUser(user) });
});

app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body || {};
  const user = db.users.find(u => u.email.toLowerCase() === (email || '').toLowerCase());
  if (!user || !(await bcrypt.compare(password || '', user.password)))
    return res.status(401).json({ error: 'Неверный email или пароль' });
  const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
  res.cookie('token', token, { httpOnly: true, sameSite: 'lax', maxAge: 7 * 86400e3 });
  res.json({ token, user: publicUser(user) });
});

app.post('/api/auth/logout', (req, res) => { res.clearCookie('token'); res.json({ ok: true }); });
app.get('/api/auth/me', auth, (req, res) => res.json(publicUser(req.user)));

app.put('/api/auth/profile', auth, async (req, res) => {
  const { name, phone, license, password } = req.body || {};
  if (name) req.user.name = name;
  if (phone !== undefined) req.user.phone = phone;
  if (license !== undefined) req.user.license = license;
  if (password) {
    if (password.length < 6) return res.status(400).json({ error: 'Пароль слишком короткий' });
    req.user.password = await bcrypt.hash(password, 10);
  }
  res.json(publicUser(req.user));
});

/* ============================================================
   CARS
   ============================================================ */
app.get('/api/cars', (req, res) => {
  const { type, transmission, fuel, maxPrice, status, q } = req.query;
  let list = db.cars.slice();
  if (type) list = list.filter(c => c.type === type);
  if (transmission) list = list.filter(c => c.transmission === transmission);
  if (fuel) list = list.filter(c => c.fuel === fuel);
  if (maxPrice) list = list.filter(c => c.pricePerMin <= +maxPrice);
  if (status) list = list.filter(c => c.status === status);
  if (q) list = list.filter(c => (c.model + c.plate).toLowerCase().includes(q.toLowerCase()));
  res.json(list);
});
app.get('/api/cars/:id', (req, res) => {
  const c = db.cars.find(x => x.id === +req.params.id);
  return c ? res.json(c) : res.status(404).json({ error: 'Автомобиль не найден' });
});
app.post('/api/cars', auth, adminOnly, (req, res) => {
  const d = req.body || {};
  if (!d.model || !d.plate) return res.status(400).json({ error: 'Укажите модель и номер' });
  const car = {
    id: db.ids.car++, model: d.model, plate: d.plate,
    type: d.type || 'Эконом', transmission: d.transmission || 'Автомат',
    fuel: d.fuel || 'Бензин', fuelLevel: d.fuelLevel ?? 100,
    pricePerMin: d.pricePerMin || 9, lat: d.lat ?? 58.5215, lng: d.lng ?? 31.2755,
    status: d.status || 'available', year: d.year || 2023, color: d.color || 'Белый',
    rating: 5, trips: 0,
  };
  db.cars.push(car);
  res.json(car);
});
app.put('/api/cars/:id', auth, adminOnly, (req, res) => {
  const c = db.cars.find(x => x.id === +req.params.id);
  if (!c) return res.status(404).json({ error: 'Автомобиль не найден' });
  Object.assign(c, req.body || {});
  res.json(c);
});
app.delete('/api/cars/:id', auth, adminOnly, (req, res) => {
  const i = db.cars.findIndex(c => c.id === +req.params.id);
  if (i === -1) return res.status(404).json({ error: 'Автомобиль не найден' });
  db.cars.splice(i, 1);
  res.json({ ok: true });
});

/* ============================================================
   TARIFFS / OPTIONS
   ============================================================ */
app.get('/api/tariffs', (req, res) => res.json(db.tariffs));
app.get('/api/options', (req, res) => res.json(db.options));
app.post('/api/tariffs', auth, adminOnly, (req, res) => {
  const t = { id: db.ids.tariff++, ...req.body };
  db.tariffs.push(t);
  res.json(t);
});
app.put('/api/tariffs/:id', auth, adminOnly, (req, res) => {
  const t = db.tariffs.find(x => x.id === +req.params.id);
  if (!t) return res.status(404).json({ error: 'Тариф не найден' });
  Object.assign(t, req.body);
  res.json(t);
});
app.delete('/api/tariffs/:id', auth, adminOnly, (req, res) => {
  const i = db.tariffs.findIndex(x => x.id === +req.params.id);
  if (i === -1) return res.status(404).json({ error: 'Тариф не найден' });
  db.tariffs.splice(i, 1);
  res.json({ ok: true });
});

/* ============================================================
   BOOKINGS
   ============================================================ */
function hasConflict(carId, start, end, excludeId = null) {
  return db.bookings.some(b =>
    b.carId === carId && b.id !== excludeId &&
    !['cancelled', 'completed'].includes(b.status) &&
    start < b.end && end > b.start
  );
}
function calcPrice(car, start, end, tariffKey = 'minute', options = {}) {
  const minutes = Math.max(1, Math.round((end - start) / 60000));
  const hours = minutes / 60;
  const days = Math.max(1, Math.ceil(hours / 24));
  let total;
  if (tariffKey === 'minute') total = Math.max(90, minutes * car.pricePerMin);
  else if (tariffKey === 'hour') total = Math.max(2 * 349, Math.ceil(hours) * 349);
  else if (tariffKey === 'day') total = days * 2490;
  else if (tariffKey === 'weekend') total = 4490;
  else total = Math.max(90, minutes * car.pricePerMin);
  if (options.insurance) total += 149;
  if (options.childSeat) total += 250 * days;
  return Math.round(total);
}

app.get('/api/bookings', auth, (req, res) => {
  const list = req.user.role === 'admin'
    ? db.bookings.slice()
    : db.bookings.filter(b => b.userId === req.user.id);
  res.json(list.map(b => ({
    ...b,
    car: db.cars.find(c => c.id === b.carId) || null,
    user: (() => { const u = db.users.find(u => u.id === b.userId); return u ? publicUser(u) : null; })(),
  })).sort((a, b) => b.createdAt - a.createdAt));
});

app.get('/api/bookings/:id', auth, (req, res) => {
  const b = db.bookings.find(x => x.id === +req.params.id);
  if (!b) return res.status(404).json({ error: 'Аренда не найдена' });
  if (req.user.role !== 'admin' && b.userId !== req.user.id)
    return res.status(403).json({ error: 'Нет доступа' });
  const u = db.users.find(x => x.id === b.userId);
  res.json({ ...b, car: db.cars.find(c => c.id === b.carId), user: u ? publicUser(u) : null });
});

app.post('/api/bookings', auth, (req, res) => {
  const { carId, start, end, tariffKey, options } = req.body || {};
  const car = db.cars.find(c => c.id === +carId);
  if (!car) return res.status(404).json({ error: 'Автомобиль не найден' });
  if (car.status !== 'available') return res.status(400).json({ error: 'Автомобиль недоступен' });
  const s = new Date(start).getTime(), e = new Date(end).getTime();
  if (!s || !e || e <= s) return res.status(400).json({ error: 'Некорректные даты' });
  if (s < Date.now() - 60_000) return res.status(400).json({ error: 'Дата начала в прошлом' });
  if (hasConflict(car.id, s, e)) return res.status(409).json({ error: 'Автомобиль уже занят на выбранный интервал' });
  const total = calcPrice(car, s, e, tariffKey || 'minute', options || {});
  const booking = {
    id: db.ids.booking++, userId: req.user.id, carId: car.id,
    start: s, end: e, status: 'confirmed', total,
    tariffKey: tariffKey || 'minute', options: options || {},
    route: null, createdAt: Date.now(),
  };
  db.bookings.push(booking);
  res.json(booking);
});

app.put('/api/bookings/:id', auth, (req, res) => {
  const b = db.bookings.find(x => x.id === +req.params.id);
  if (!b) return res.status(404).json({ error: 'Аренда не найдена' });
  if (req.user.role !== 'admin' && b.userId !== req.user.id)
    return res.status(403).json({ error: 'Нет доступа' });
  const d = req.body || {};
  if (req.user.role !== 'admin') {
    if (d.status === 'cancelled') b.status = 'cancelled';
    if (d.route) b.route = d.route;
    return res.json(b);
  }
  if (d.carId) b.carId = +d.carId;
  if (d.userId) b.userId = +d.userId;
  if (d.start) b.start = new Date(d.start).getTime();
  if (d.end) b.end = new Date(d.end).getTime();
  if (d.status) b.status = d.status;
  if (d.total !== undefined) b.total = +d.total;
  if (d.route !== undefined) b.route = d.route;
  res.json(b);
});

app.delete('/api/bookings/:id', auth, (req, res) => {
  const i = db.bookings.findIndex(x => x.id === +req.params.id);
  if (i === -1) return res.status(404).json({ error: 'Аренда не найдена' });
  if (req.user.role !== 'admin' && db.bookings[i].userId !== req.user.id)
    return res.status(403).json({ error: 'Нет доступа' });
  db.bookings.splice(i, 1);
  res.json({ ok: true });
});

/* ============================================================
   ADMIN
   ============================================================ */
app.get('/api/admin/stats', auth, adminOnly, (req, res) => {
  const all = db.bookings;
  const revenue = all.filter(b => b.status !== 'cancelled').reduce((s, b) => s + (b.total || 0), 0);
  const active = all.filter(b => ['confirmed', 'active'].includes(b.status)).length;
  const pop = {};
  all.forEach(b => pop[b.carId] = (pop[b.carId] || 0) + 1);
  const popular = Object.entries(pop).sort((a, b) => b[1] - a[1]).slice(0, 5)
    .map(([id, count]) => ({ car: db.cars.find(c => c.id === +id) || null, count }));
  res.json({
    totalBookings: all.length, revenue, active,
    cars: db.cars.length, users: db.users.length,
    popular,
    utilization: db.cars.length ? Math.round(active / db.cars.length * 100) : 0,
  });
});

app.get('/api/admin/users', auth, adminOnly, (req, res) => res.json(db.users.map(publicUser)));

app.put('/api/admin/users/:id', auth, adminOnly, (req, res) => {
  const u = db.users.find(x => x.id === +req.params.id);
  if (!u) return res.status(404).json({ error: 'Пользователь не найден' });
  const { name, phone, role, license, balance } = req.body || {};
  if (name) u.name = name;
  if (phone !== undefined) u.phone = phone;
  if (role) u.role = role;
  if (license !== undefined) u.license = license;
  if (balance !== undefined) u.balance = +balance;
  res.json(publicUser(u));
});

app.delete('/api/admin/users/:id', auth, adminOnly, (req, res) => {
  const i = db.users.findIndex(x => x.id === +req.params.id);
  if (i === -1) return res.status(404).json({ error: 'Пользователь не найден' });
  if (db.users[i].role === 'admin') return res.status(400).json({ error: 'Нельзя удалить администратора' });
  db.users.splice(i, 1);
  res.json({ ok: true });
});

/* ============================================================
   SPA FALLBACK
   ============================================================ */
app.get('*', (req, res) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ error: 'Не найдено' });
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`\n  ⚡ GriGO запущен: http://localhost:${PORT}`);
  console.log(`  Админ: admin@grigo.ru / admin123`);
  console.log(`  Юзер:  user@grigo.ru  / user123\n`);
});