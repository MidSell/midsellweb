/* ============================================================
   GriGO — SPA
   ============================================================ */
const state = {
  user: null,
  token: localStorage.getItem('grigo_token') || null,
  map: null,
  carsLayer: null,
  markers: new Map(),
  cars: [],
  filteredCars: [],
  bookings: [],
  tariffs: [],
  options: [],
  routeLine: null,
  routeMarkers: [],
  userLocationMarker: null,
  mapInitialized: false,
  adminPage: { bookings: 1, users: 1, cars: 1 },
  adminSearch: '',
  adminFilter: { bookingStatus: '', carStatus: '' },
};

const NOVGOROD = { lat: 58.5215, lng: 31.2755 };
const WORK_ZONE = [
  [58.560, 31.210], [58.565, 31.350], [58.495, 31.360],
  [58.488, 31.215], [58.505, 31.190], [58.545, 31.190],
];

/* ============================================================
   API helper
   ============================================================ */
const api = {
  async request(method, url, body) {
    const headers = { 'Content-Type': 'application/json' };
    if (state.token) headers['Authorization'] = 'Bearer ' + state.token;
    const res = await fetch(url, { method, headers, body: body ? JSON.stringify(body) : undefined });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || `Ошибка ${res.status}`);
    return data;
  },
  get: (u) => api.request('GET', u),
  post: (u, b) => api.request('POST', u, b),
  put: (u, b) => api.request('PUT', u, b),
  del: (u) => api.request('DELETE', u),
};

/* ============================================================
   UI helpers
   ============================================================ */
function $(sel, root = document) { return root.querySelector(sel); }
function $$(sel, root = document) { return [...root.querySelectorAll(sel)]; }
function el(tag, attrs = {}, ...children) {
  const node = document.createElement(tag);
  for (const k in attrs) {
    if (k === 'class') node.className = attrs[k];
    else if (k === 'html') node.innerHTML = attrs[k];
    else if (k.startsWith('on') && typeof attrs[k] === 'function') node.addEventListener(k.slice(2), attrs[k]);
    else if (attrs[k] != null) node.setAttribute(k, attrs[k]);
  }
  children.forEach(c => node.append(c?.nodeType ? c : document.createTextNode(c ?? '')));
  return node;
}
function escapeHtml(s) {
  return String(s ?? '').replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));
}
function fmtMoney(n) { return Math.round(n).toLocaleString('ru-RU') + ' ₽'; }
function fmtDateTime(ts) {
  return new Date(ts).toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
}
function toLocalInput(ts) {
  const d = new Date(ts - new Date().getTimezoneOffset() * 60000);
  return d.toISOString().slice(0, 16);
}

function toast(message, type = 'info') {
  const icons = { info: 'ℹ️', success: '✅', error: '⚠️' };
  const node = el('div', { class: `toast ${type}` },
    el('span', { class: 'icon' }, icons[type] || 'ℹ️'),
    el('span', {}, message),
    el('button', { class: 'close', onclick: () => node.remove() }, '×'),
  );
  $('#toasts').append(node);
  setTimeout(() => node.remove(), 4200);
}

function openModal(content, { wide } = {}) {
  const root = $('#modal-root');
  const backdrop = el('div', { class: 'modal-backdrop', onclick: e => { if (e.target === backdrop) closeModal(); } });
  const modal = el('div', { class: `modal ${wide ? 'wide' : ''}` });
  modal.append(el('button', { class: 'modal-close', onclick: closeModal }, '×'));
  if (typeof content === 'string') modal.insertAdjacentHTML('beforeend', content);
  else modal.append(content);
  backdrop.append(modal);
  root.append(backdrop);
  document.body.style.overflow = 'hidden';
  return modal;
}
function closeModal() {
  $('#modal-root').innerHTML = '';
  document.body.style.overflow = '';
}
window.closeModal = closeModal;

/* ============================================================
   Router
   ============================================================ */
const VIEWS = ['landing', 'map', 'pricing', 'auth', 'dashboard', 'admin'];

function currentRoute() {
  const hash = location.hash.replace(/^#\/?/, '') || 'landing';
  return hash.split('/')[0];
}

function navigate(view) {
  if (location.hash !== `#/${view}`) location.hash = `#/${view}`;
  else renderRoute();
}

async function renderRoute() {
  let view = currentRoute();
  if (!VIEWS.includes(view)) view = 'landing';

  if (view === 'dashboard' && !state.user) { toast('Войдите в аккаунт', 'error'); return navigate('auth'); }
  if (view === 'admin' && state.user?.role !== 'admin') { toast('Доступ запрещён', 'error'); return navigate('landing'); }

  $$('.view').forEach(v => v.classList.toggle('active', v.id === `view-${view}`));
  $$('.nav a').forEach(a => a.classList.toggle('active', a.dataset.nav === view));

  window.scrollTo({ top: 0, behavior: 'instant' });

  if (view === 'map') await initMap();
  if (view === 'pricing') await renderPricing();
  if (view === 'dashboard') await renderDashboard();
  if (view === 'admin') await renderAdmin();
  if (view === 'auth') setTimeout(() => $('.auth-form:not(.hidden) input')?.focus(), 100);

  $('#main-nav')?.classList.remove('open');
  $('#burger')?.classList.remove('open');
}

window.addEventListener('hashchange', renderRoute);

/* ============================================================
   Header user area
   ============================================================ */
function renderHeaderUser() {
  const box = $('#header-actions');
  box.innerHTML = '';
  document.body.classList.toggle('logged-in', !!state.user);
  document.body.classList.toggle('is-admin', state.user?.role === 'admin');

  if (state.user) {
    const initials = (state.user.name || 'U').split(' ').map(s => s[0]).join('').slice(0, 2).toUpperCase();
    const chip = el('button', {
      class: 'user-chip',
      onclick: () => navigate(state.user.role === 'admin' ? 'admin' : 'dashboard'),
      title: state.user.email,
    },
      el('span', { class: 'user-avatar' }, initials),
      el('span', {}, state.user.name.split(' ')[0]),
    );
    const logout = el('button', { class: 'btn btn-ghost btn-sm', onclick: doLogout }, 'Выйти');
    box.append(chip, logout);
  } else {
    box.append(
      el('a', { href: '#/auth', class: 'btn btn-ghost btn-sm' }, 'Войти'),
      el('a', { href: '#/auth', class: 'btn btn-primary btn-sm' }, 'Регистрация'),
    );
  }
}

async function doLogout() {
  try { await api.post('/api/auth/logout'); } catch {}
  state.user = null;
  state.token = null;
  localStorage.removeItem('grigo_token');
  renderHeaderUser();
  toast('Вы вышли из аккаунта', 'success');
  navigate('landing');
}

/* ============================================================
   Auth
   ============================================================ */
async function loadMe() {
  if (!state.token) return;
  try {
    state.user = await api.get('/api/auth/me');
  } catch {
    state.token = null; localStorage.removeItem('grigo_token');
  }
}

function initAuthForms() {
  $$('.auth-tab').forEach(btn => btn.addEventListener('click', () => {
    $$('.auth-tab').forEach(b => b.classList.toggle('active', b === btn));
    $('#form-login').classList.toggle('hidden', btn.dataset.tab !== 'login');
    $('#form-register').classList.toggle('hidden', btn.dataset.tab !== 'register');
  }));

  $('#form-login').addEventListener('submit', async e => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const btn = e.target.querySelector('button[type="submit"]');
    btn.disabled = true; btn.textContent = 'Вход...';
    try {
      const { token, user } = await api.post('/api/auth/login', {
        email: fd.get('email'), password: fd.get('password'),
      });
      state.token = token; state.user = user;
      localStorage.setItem('grigo_token', token);
      renderHeaderUser();
      toast(`Добро пожаловать, ${user.name}!`, 'success');
      navigate(user.role === 'admin' ? 'admin' : 'dashboard');
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      btn.disabled = false; btn.textContent = 'Войти';
    }
  });

  $('#form-register').addEventListener('submit', async e => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const payload = Object.fromEntries(fd);
    const btn = e.target.querySelector('button[type="submit"]');
    btn.disabled = true; btn.textContent = 'Создаём аккаунт...';
    try {
      const { token, user } = await api.post('/api/auth/register', payload);
      state.token = token; state.user = user;
      localStorage.setItem('grigo_token', token);
      renderHeaderUser();
      toast('Аккаунт создан! Добро пожаловать в GriGO', 'success');
      navigate('dashboard');
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      btn.disabled = false; btn.textContent = 'Зарегистрироваться';
    }
  });
}

/* ============================================================
   MAP
   ============================================================ */
async function initMap() {
  if (!state.mapInitialized) {
    state.map = L.map('map', { zoomControl: true, attributionControl: false })
      .setView([NOVGOROD.lat, NOVGOROD.lng], 13);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '© OpenStreetMap',
    }).addTo(state.map);

    L.polygon(WORK_ZONE, {
      color: '#39FF14', weight: 1.5, opacity: 0.7,
      fillColor: '#39FF14', fillOpacity: 0.05, dashArray: '6 6',
    }).addTo(state.map).bindPopup('Зона работы GriGO — центр Великого Новгорода');

    state.carsLayer = L.markerClusterGroup({
      showCoverageOnHover: false, maxClusterRadius: 60,
      iconCreateFunction: (cluster) => L.divIcon({
        html: `<div style="width:36px;height:36px;border-radius:50%;background:#39FF14;color:#000;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:13px;box-shadow:0 0 20px rgba(57,255,20,.55)">${cluster.getChildCount()}</div>`,
        className: '', iconSize: [36, 36],
      }),
    });
    state.map.addLayer(state.carsLayer);

    state.mapInitialized = true;
  }

  setTimeout(() => state.map.invalidateSize(), 60);
  await loadCars();
  initMapFilters();
}

function carIcon(car) {
  const color = car.status === 'available' ? '#39FF14' : car.status === 'maintenance' ? '#FFC107' : '#FF3B3B';
  return L.divIcon({
    className: '',
    html: `<div style="width:38px;height:38px;border-radius:12px;background:linear-gradient(160deg,#1A1A1A,#0A0A0A);border:1.5px solid ${color};display:flex;align-items:center;justify-content:center;font-size:16px;box-shadow:0 0 14px ${color}66">🚗</div>`,
    iconSize: [38, 38], iconAnchor: [19, 19], popupAnchor: [0, -20],
  });
}

async function loadCars() {
  try {
    state.cars = await api.get('/api/cars');
    applyMapFilters();
    renderCarsList();
  } catch (err) { toast(err.message, 'error'); }
}

function applyMapFilters() {
  const type = $('#f-type')?.value || '';
  const trans = $('#f-transmission')?.value || '';
  const fuel = $('#f-fuel')?.value || '';
  const price = parseFloat($('#f-price')?.value) || 0;
  state.filteredCars = state.cars.filter(c =>
    (!type || c.type === type) &&
    (!trans || c.transmission === trans) &&
    (!fuel || c.fuel === fuel) &&
    (!price || c.pricePerMin <= price)
  );
  drawMarkers();
  renderCarsList();
}

function drawMarkers() {
  if (!state.carsLayer) return;
  state.carsLayer.clearLayers();
  state.markers.clear();
  state.filteredCars.forEach(car => {
    const m = L.marker([car.lat, car.lng], { icon: carIcon(car) });
    m.bindPopup(buildCarPopup(car));
    m.on('popupopen', () => {
      setTimeout(() => {
        const popup = m.getPopup()?.getElement();
        if (!popup) return;
        popup.querySelectorAll('[data-action="book"]').forEach(b =>
          b.addEventListener('click', () => openBookingModal(car)));
        popup.querySelectorAll('[data-action="route"]').forEach(b =>
          b.addEventListener('click', () => buildRouteToCar(car)));
      }, 0);
    });
    state.carsLayer.addLayer(m);
    state.markers.set(car.id, m);
  });
}

function buildCarPopup(car) {
  const statusText = car.status === 'available' ? 'Доступна' : car.status === 'maintenance' ? 'Обслуживание' : 'Занята';
  return `
    <div class="popup-title">${escapeHtml(car.model)}<span class="popup-price">${car.pricePerMin} ₽/мин</span></div>
    <div class="popup-row"><span>Номер</span><b>${escapeHtml(car.plate)}</b></div>
    <div class="popup-row"><span>Тип</span><span>${car.type} · ${car.transmission}</span></div>
    <div class="popup-row"><span>Топливо</span><span>${car.fuel} · ${car.fuelLevel}%</span></div>
    <div class="popup-row"><span>Статус</span><span class="status-pill status-${car.status === 'available' ? 'available' : car.status === 'maintenance' ? 'maintenance' : 'busy'}">${statusText}</span></div>
    <div class="popup-actions">
      <button class="btn btn-ghost btn-sm" data-action="route">Маршрут</button>
      <button class="btn btn-primary btn-sm" data-action="book" ${car.status !== 'available' ? 'disabled' : ''}>Забронировать</button>
    </div>
  `;
}

function renderCarsList() {
  const list = $('#cars-list');
  if (!list) return;
  if (!state.filteredCars.length) {
    list.innerHTML = `<div class="empty-state"><div class="icon">🚗</div><div>Автомобили не найдены</div></div>`;
    return;
  }
  list.innerHTML = state.filteredCars.map(car => `
    <div class="car-item" data-car="${car.id}">
      <div class="car-item-title">
        <b>${escapeHtml(car.model)}</b>
        <span class="price">${car.pricePerMin} ₽/мин</span>
      </div>
      <div class="car-item-meta">
        <span>${car.type}</span><span>${car.transmission}</span><span>${car.plate}</span>
        <span>${car.fuel === 'Электро' ? '⚡' : '⛽'} ${car.fuelLevel}%</span>
      </div>
      <div class="car-item-actions">
        <button class="btn btn-ghost btn-sm" data-act="route">Маршрут</button>
        <button class="btn btn-primary btn-sm" data-act="book" ${car.status !== 'available' ? 'disabled' : ''}>Забронировать</button>
      </div>
    </div>
  `).join('');

  list.querySelectorAll('.car-item').forEach(item => {
    const id = +item.dataset.car;
    const car = state.filteredCars.find(c => c.id === id);
    item.addEventListener('click', e => {
      if (e.target.closest('button')) return;
      const marker = state.markers.get(id);
      if (marker) {
        state.map.setView([car.lat, car.lng], 15);
        marker.openPopup();
      }
    });
    item.querySelector('[data-act="book"]')?.addEventListener('click', () => openBookingModal(car));
    item.querySelector('[data-act="route"]')?.addEventListener('click', () => buildRouteToCar(car));
  });
}

function initMapFilters() {
  ['f-type', 'f-transmission', 'f-fuel', 'f-price'].forEach(id => {
    const node = $('#' + id);
    if (!node || node.dataset.bound) return;
    node.dataset.bound = '1';
    node.addEventListener('input', applyMapFilters);
    node.addEventListener('change', applyMapFilters);
  });
  const reset = $('#f-reset');
  if (reset && !reset.dataset.bound) {
    reset.dataset.bound = '1';
    reset.addEventListener('click', () => {
      ['f-type', 'f-transmission', 'f-fuel', 'f-price'].forEach(id => $('#' + id).value = '');
      applyMapFilters();
    });
  }
  const locate = $('#btn-locate');
  if (locate && !locate.dataset.bound) {
    locate.dataset.bound = '1';
    locate.addEventListener('click', locateUser);
  }
}

function locateUser() {
  if (!navigator.geolocation) return toast('Геолокация не поддерживается браузером', 'error');
  toast('Определяем ваше местоположение...');
  navigator.geolocation.getCurrentPosition(
    pos => {
      const { latitude, longitude } = pos.coords;
      if (state.userLocationMarker) state.map.removeLayer(state.userLocationMarker);
      state.userLocationMarker = L.circleMarker([latitude, longitude], {
        radius: 9, color: '#39FF14', fillColor: '#39FF14', fillOpacity: 0.4, weight: 2,
      }).addTo(state.map).bindPopup('Вы здесь');
      state.map.setView([latitude, longitude], 14);
      toast('Местоположение определено', 'success');
    },
    () => toast('Не удалось получить геолокацию', 'error'),
    { enableHighAccuracy: true, timeout: 8000 },
  );
}

/* ---------- Routing (OSRM) ---------- */
async function buildRouteToCar(car) {
  const start = state.userLocationMarker?.getLatLng() || { lat: NOVGOROD.lat, lng: NOVGOROD.lng };
  await drawRoute(start, { lat: car.lat, lng: car.lng }, car.model);
}

async function drawRoute(from, to, label = 'Автомобиль') {
  try {
    toast('Строим маршрут...');
    const url = `https://router.project-osrm.org/route/v1/driving/${from.lng},${from.lat};${to.lng},${to.lat}?overview=full&geometries=geojson`;
    const res = await fetch(url);
    const data = await res.json();
    if (!data.routes?.length) throw new Error('Маршрут не найден');
    const r = data.routes[0];
    const coords = r.geometry.coordinates.map(c => [c[1], c[0]]);

    state.routeMarkers.forEach(m => state.map.removeLayer(m));
    state.routeMarkers = [];
    if (state.routeLine) state.map.removeLayer(state.routeLine);

    state.routeLine = L.polyline(coords, { color: '#39FF14', weight: 5, opacity: 0.9, lineCap: 'round' }).addTo(state.map);
    state.routeMarkers.push(L.circleMarker([from.lat, from.lng], { radius: 8, color: '#39FF14', fillColor: '#39FF14', fillOpacity: 1 }).addTo(state.map).bindPopup('Старт'));
    state.routeMarkers.push(L.circleMarker([to.lat, to.lng], { radius: 8, color: '#FF3B3B', fillColor: '#FF3B3B', fillOpacity: 1 }).addTo(state.map).bindPopup(label));

    state.map.fitBounds(state.routeLine.getBounds(), { padding: [40, 40] });
    toast(`Маршрут: ${(r.distance / 1000).toFixed(1)} км · ${Math.round(r.duration / 60)} мин`, 'success');
  } catch (err) {
    toast('Не удалось построить маршрут: ' + err.message, 'error');
  }
}

/* ============================================================
   BOOKING MODAL
   ============================================================ */
async function openBookingModal(car) {
  if (!state.user) {
    toast('Войдите, чтобы забронировать авто', 'error');
    return navigate('auth');
  }
  if (!state.tariffs.length) state.tariffs = await api.get('/api/tariffs');
  const now = new Date();
  const start = new Date(now.getTime() + 15 * 60000);
  const end = new Date(start.getTime() + 2 * 3600 * 1000);

  const content = `
    <h2>Бронирование автомобиля</h2>
    <p class="sub">${escapeHtml(car.model)} · ${escapeHtml(car.plate)} · ${car.type}</p>
    <div class="form-grid">
      <div class="field">
        <label>Дата и время начала</label>
        <input type="datetime-local" id="b-start" value="${toLocalInput(start.getTime())}">
      </div>
      <div class="field">
        <label>Дата и время окончания</label>
        <input type="datetime-local" id="b-end" value="${toLocalInput(end.getTime())}">
      </div>
      <div class="field full">
        <label>Тариф</label>
        <select id="b-tariff">
          ${state.tariffs.filter(t => ['minute', 'hour', 'day', 'weekend'].includes(t.key)).map(t =>
            `<option value="${t.key}" ${t.key === 'minute' ? 'selected' : ''}>${t.name} — ${t.price} ${t.unit}</option>`).join('')}
        </select>
      </div>
      <div class="field full">
        <label>Дополнительно</label>
        <div style="display:grid;gap:8px">
          <label class="checkbox-row">
            <input type="checkbox" id="b-insurance">
            <span>Страховка КАСКО+ (франшиза 0 ₽)</span>
            <span class="price">149 ₽</span>
          </label>
          <label class="checkbox-row">
            <input type="checkbox" id="b-child">
            <span>Детское кресло</span>
            <span class="price">250 ₽/сутки</span>
          </label>
        </div>
      </div>
    </div>
    <div class="price-preview">
      <span>Итого к оплате:</span>
      <b id="b-total">—</b>
    </div>
    <div class="modal-actions">
      <button class="btn btn-ghost" data-act="cancel">Отмена</button>
      <button class="btn btn-primary" data-act="confirm">Подтвердить бронь</button>
    </div>
  `;
  const modal = openModal(content);

  const recalc = () => {
    const s = new Date($('#b-start').value).getTime();
    const e = new Date($('#b-end').value).getTime();
    if (!s || !e || e <= s) { $('#b-total').textContent = '—'; return; }
    const minutes = Math.round((e - s) / 60000);
    const hours = minutes / 60;
    const days = Math.max(1, Math.ceil(hours / 24));
    const tkey = $('#b-tariff').value;
    let total;
    if (tkey === 'minute') total = Math.max(90, minutes * car.pricePerMin);
    else if (tkey === 'hour') total = Math.max(2 * 349, Math.ceil(hours) * 349);
    else if (tkey === 'day') total = days * 2490;
    else if (tkey === 'weekend') total = 4490;
    if ($('#b-insurance').checked) total += 149;
    if ($('#b-child').checked) total += 250 * days;
    $('#b-total').textContent = fmtMoney(total);
  };

  modal.addEventListener('input', recalc);
  modal.addEventListener('change', recalc);
  recalc();

  modal.querySelector('[data-act="cancel"]').addEventListener('click', closeModal);
  modal.querySelector('[data-act="confirm"]').addEventListener('click', async e => {
    const btn = e.currentTarget;
    btn.disabled = true; btn.textContent = 'Бронируем...';
    try {
      const s = new Date($('#b-start').value).toISOString();
      const en = new Date($('#b-end').value).toISOString();
      const booking = await api.post('/api/bookings', {
        carId: car.id, start: s, end: en,
        tariffKey: $('#b-tariff').value,
        options: { insurance: $('#b-insurance').checked, childSeat: $('#b-child').checked },
      });
      closeModal();
      toast(`Бронь #${booking.id} подтверждена. Стоимость: ${fmtMoney(booking.total)}`, 'success');
      navigate('dashboard');
    } catch (err) {
      toast(err.message, 'error');
      btn.disabled = false; btn.textContent = 'Подтвердить бронь';
    }
  });
}

/* ============================================================
   PRICING
   ============================================================ */
async function renderPricing() {
  const grid = $('#pricing-grid');
  if (!state.tariffs.length) state.tariffs = await api.get('/api/tariffs');
  if (!state.options.length) state.options = await api.get('/api/options');

  grid.innerHTML = state.tariffs.map(t => `
    <div class="card tariff ${t.highlight ? 'highlight' : ''}">
      ${t.highlight ? '<div class="tariff-badge">Популярный</div>' : ''}
      <div class="tariff-name">${escapeHtml(t.name)}</div>
      <div class="tariff-price">${t.price} <small>${escapeHtml(t.unit)}</small></div>
      <p class="tariff-desc">${escapeHtml(t.desc)}</p>
      <div class="tariff-conditions">${escapeHtml(t.conditions)}</div>
    </div>
  `).join('');

  $('#options-grid').innerHTML = state.options.map(o => `
    <div class="card">
      <h3>${escapeHtml(o.name)}</h3>
      <div class="tariff-price" style="font-size:26px;margin-top:8px">${o.price} <small>${escapeHtml(o.unit)}</small></div>
    </div>
  `).join('');
}

/* ============================================================
   DASHBOARD
   ============================================================ */
async function renderDashboard() {
  if (!state.user) return;
  $('#dashboard-greet').textContent = `Здравствуйте, ${state.user.name}. Управляйте арендой и профилем.`;

  try {
    state.bookings = await api.get('/api/bookings');
  } catch (err) { toast(err.message, 'error'); }

  const now = Date.now();
  const active = state.bookings.filter(b => ['confirmed', 'active'].includes(b.status) && b.end > now);
  const history = state.bookings.filter(b => b.status === 'completed' || b.end < now);
  const totalSpent = state.bookings.filter(b => b.status !== 'cancelled').reduce((s, b) => s + (b.total || 0), 0);

  $('#dashboard-stats').innerHTML = `
    <div class="stat-card"><b>${active.length}</b><span>Активных аренд</span></div>
    <div class="stat-card"><b>${state.bookings.length}</b><span>Всего поездок</span></div>
    <div class="stat-card"><b>${fmtMoney(totalSpent)}</b><span>Потрачено всего</span></div>
  `;

  $('#panel-active').innerHTML = active.length
    ? active.map(b => renderBookingCard(b, true)).join('')
    : `<div class="empty-state"><div class="icon">🚗</div><div>Активных аренд нет</div><a href="#/map" class="btn btn-primary" style="margin-top:16px">Найти автомобиль</a></div>`;

  $('#panel-history').innerHTML = history.length
    ? history.map(b => renderBookingCard(b, false)).join('')
    : `<div class="empty-state"><div class="icon">📋</div><div>История пуста</div></div>`;

  bindBookingActions();
  renderCalendar(active);
  renderProfile();
  bindDashboardTabs();
}

function renderBookingCard(b, isActive) {
  const status = {
    confirmed: 'Подтверждена', active: 'Активна',
    completed: 'Завершена', cancelled: 'Отменена',
  }[b.status] || b.status;
  const statusCls = b.status === 'cancelled' ? 'busy' : b.status === 'completed' ? 'maintenance' : 'available';
  const car = b.car || {};
  return `
    <div class="booking-card" data-booking="${b.id}">
      <div class="booking-thumb">${car.fuel === 'Электро' ? '⚡' : '🚗'}</div>
      <div class="booking-info">
        <h4>${escapeHtml(car.model || 'Автомобиль')} · ${escapeHtml(car.plate || '')}</h4>
        <div class="meta">${fmtDateTime(b.start)} → ${fmtDateTime(b.end)}</div>
        <div class="meta" style="margin-top:4px">
          <span class="status-pill status-${statusCls}">${status}</span>
          ${b.route ? `· <span>${b.route.distance} м, ${b.route.duration} мин</span>` : ''}
        </div>
      </div>
      <div class="booking-price">
        <b>${fmtMoney(b.total)}</b>
        <span class="muted small">№ ${b.id}</span>
        <div class="booking-actions">
          <button class="btn btn-ghost btn-sm" data-act="details">Детали</button>
          ${isActive ? `<button class="btn btn-danger btn-sm" data-act="cancel">Отменить</button>` : ''}
        </div>
      </div>
    </div>
  `;
}

function bindBookingActions() {
  $$('[data-booking]').forEach(card => {
    const id = +card.dataset.booking;
    const b = state.bookings.find(x => x.id === id);
    card.querySelector('[data-act="details"]')?.addEventListener('click', () => showBookingDetails(b));
    card.querySelector('[data-act="cancel"]')?.addEventListener('click', () => cancelBooking(b));
  });
}

function showBookingDetails(b) {
  const car = b.car || {};
  const opts = b.options || {};
  const content = `
    <h2>Аренда № ${b.id}</h2>
    <p class="sub">${escapeHtml(car.model || '')} · ${escapeHtml(car.plate || '')}</p>
    <div class="grid" style="grid-template-columns:1fr 1fr;gap:10px">
      <div class="stat-card"><span>Начало</span><b style="font-size:16px">${fmtDateTime(b.start)}</b></div>
      <div class="stat-card"><span>Окончание</span><b style="font-size:16px">${fmtDateTime(b.end)}</b></div>
      <div class="stat-card"><span>Тариф</span><b style="font-size:16px">${escapeHtml(b.tariffKey || '—')}</b></div>
      <div class="stat-card"><span>Статус</span><b style="font-size:16px">${b.status}</b></div>
    </div>
    <div class="price-preview" style="margin-top:18px"><span>Стоимость аренды</span><b>${fmtMoney(b.total)}</b></div>
    ${opts.insurance || opts.childSeat ? `
      <h3 style="margin-top:20px;font-size:15px">Дополнительные опции</h3>
      <div class="muted small" style="margin-top:8px">
        ${opts.insurance ? '✓ Страховка КАСКО+<br>' : ''}
        ${opts.childSeat ? '✓ Детское кресло' : ''}
      </div>` : ''}
    <div class="modal-actions"><button class="btn btn-primary" onclick="closeModal()">Понятно</button></div>
  `;
  openModal(content);
}

async function cancelBooking(b) {
  if (!confirm('Отменить бронь? Действие необратимо.')) return;
  try {
    await api.put(`/api/bookings/${b.id}`, { status: 'cancelled' });
    toast('Бронь отменена', 'success');
    renderDashboard();
  } catch (err) { toast(err.message, 'error'); }
}

function bindDashboardTabs() {
  const bar = document.querySelector('[data-tabs="dashboard"]');
  if (!bar || bar.dataset.bound) return;
  bar.dataset.bound = '1';
  bar.addEventListener('click', e => {
    const btn = e.target.closest('.tab-btn');
    if (!btn) return;
    $$('.tab-btn', bar).forEach(b => b.classList.toggle('active', b === btn));
    document.querySelectorAll('#view-dashboard .tab-panel').forEach(p =>
      p.classList.toggle('hidden', p.dataset.panel !== btn.dataset.tab));
  });
}

/* ---------- Calendar ---------- */
function renderCalendar() {
  const container = $('#panel-calendar');
  const now = new Date();
  let cal = new Date(now.getFullYear(), now.getMonth(), 1);

  const draw = () => {
    const year = cal.getFullYear(), month = cal.getMonth();
    const firstDay = new Date(year, month, 1);
    const startOffset = (firstDay.getDay() + 6) % 7;
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const prevDays = new Date(year, month, 0).getDate();

    const busyDays = new Set();
    state.bookings.forEach(b => {
      if (['cancelled'].includes(b.status)) return;
      const cur = new Date(b.start);
      const last = new Date(b.end);
      while (cur <= last) {
        if (cur.getFullYear() === year && cur.getMonth() === month) busyDays.add(cur.getDate());
        cur.setDate(cur.getDate() + 1);
      }
    });

    const cells = [];
    for (let i = startOffset - 1; i >= 0; i--) {
      cells.push(`<div class="calendar-day other">${prevDays - i}</div>`);
    }
    for (let d = 1; d <= daysInMonth; d++) {
      const isToday = d === now.getDate() && month === now.getMonth() && year === now.getFullYear();
      const isBusy = busyDays.has(d);
      cells.push(`<div class="calendar-day ${isToday ? 'today' : ''} ${isBusy ? 'busy' : 'free'}" data-day="${d}">
        <span>${d}</span>${isBusy ? '<span class="badge-dot"></span>' : ''}
      </div>`);
    }
    const total = startOffset + daysInMonth;
    const trailing = (7 - (total % 7)) % 7;
    for (let d = 1; d <= trailing; d++) cells.push(`<div class="calendar-day other">${d}</div>`);

    container.innerHTML = `
      <div class="calendar-head">
        <button class="btn btn-ghost btn-sm" data-cal="prev">← Предыдущий</button>
        <h3 style="font-size:18px">${firstDay.toLocaleString('ru-RU', { month: 'long', year: 'numeric' })}</h3>
        <button class="btn btn-ghost btn-sm" data-cal="next">Следующий →</button>
      </div>
      <div class="calendar-grid">
        ${['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'].map(d => `<div class="dow">${d}</div>`).join('')}
        ${cells.join('')}
      </div>
      <p class="muted small" style="margin-top:14px">
        🔴 Красным отмечены даты, в которые у вас есть аренда.
      </p>
    `;
    container.querySelector('[data-cal="prev"]').addEventListener('click', () => {
      cal = new Date(year, month - 1, 1); draw();
    });
    container.querySelector('[data-cal="next"]').addEventListener('click', () => {
      cal = new Date(year, month + 1, 1); draw();
    });
    container.querySelectorAll('.calendar-day.free').forEach(d => d.addEventListener('click', () => {
      navigate('map');
      toast('Выберите автомобиль на карте', 'info');
    }));
  };
  draw();
}

/* ---------- Profile ---------- */
function renderProfile() {
  const u = state.user;
  $('#panel-profile').innerHTML = `
    <div class="card" style="max-width:640px">
      <h3>Профиль</h3>
      <p class="muted small" style="margin-bottom:20px">Обновите ваши данные</p>
      <form id="profile-form">
        <div class="form-grid">
          <div class="field full"><label>Имя</label><input name="name" value="${escapeHtml(u.name)}" required></div>
          <div class="field"><label>Email</label><input value="${escapeHtml(u.email)}" disabled></div>
          <div class="field"><label>Телефон</label><input name="phone" value="${escapeHtml(u.phone || '')}"></div>
          <div class="field full"><label>Водительское удостоверение</label><input name="license" value="${escapeHtml(u.license || '')}"></div>
          <div class="field full"><label>Новый пароль (если хотите сменить)</label><input type="password" name="password" minlength="6" placeholder="Оставьте пустым, чтобы не менять"></div>
        </div>
        <button type="submit" class="btn btn-primary" style="margin-top:18px">Сохранить изменения</button>
      </form>
    </div>
  `;
  $('#profile-form').addEventListener('submit', async e => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const payload = Object.fromEntries(fd);
    if (!payload.password) delete payload.password;
    try {
      state.user = await api.put('/api/auth/profile', payload);
      toast('Профиль обновлён', 'success');
      renderHeaderUser();
    } catch (err) { toast(err.message, 'error'); }
  });
}

/* ============================================================
   ADMIN
   ============================================================ */
async function renderAdmin() {
  try {
    const stats = await api.get('/api/admin/stats');
    renderAdminStats(stats);
  } catch (err) { toast(err.message, 'error'); }

  bindAdminTabs();
  const active = document.querySelector('[data-tabs="admin"] .tab-btn.active')?.dataset.tab || 'overview';
  await loadAdminTab(active);
}

function renderAdminStats(s) {
  $('#admin-stats').innerHTML = `
    <div class="stat-card"><b>${s.totalBookings}</b><span>Аренд всего</span></div>
    <div class="stat-card"><b>${fmtMoney(s.revenue)}</b><span>Доход</span></div>
    <div class="stat-card"><b>${s.active}</b><span>Активных</span></div>
    <div class="stat-card"><b>${s.utilization}%</b><span>Загруженность парка</span></div>
  `;

  const pop = s.popular.map(p => `
    <tr>
      <td>${p.car ? escapeHtml(p.car.model) : '—'}</td>
      <td>${p.car ? escapeHtml(p.car.plate) : ''}</td>
      <td>${p.count}</td>
    </tr>
  `).join('') || '<tr><td colspan="3" class="muted">Пока нет данных</td></tr>';

  $('#admin-overview').innerHTML = `
    <div class="grid grid-2" style="margin-bottom:22px">
      <div class="card">
        <h3>Популярные автомобили</h3>
        <p class="muted small" style="margin-bottom:14px">Топ-5 по количеству аренд</p>
        <div class="table-wrap">
          <table><thead><tr><th>Модель</th><th>Номер</th><th>Аренд</th></tr></thead><tbody>${pop}</tbody></table>
        </div>
      </div>
      <div class="card">
        <h3>Общая статистика</h3>
        <p class="muted small" style="margin-bottom:14px">Актуальные показатели сервиса</p>
        <div class="grid grid-2" style="gap:12px">
          <div class="stat-card"><b>${s.cars}</b><span>Автомобилей</span></div>
          <div class="stat-card"><b>${s.users}</b><span>Пользователей</span></div>
        </div>
      </div>
    </div>
  `;
}

function bindAdminTabs() {
  const bar = document.querySelector('[data-tabs="admin"]');
  if (!bar || bar.dataset.bound) return;
  bar.dataset.bound = '1';
  bar.addEventListener('click', e => {
    const btn = e.target.closest('.tab-btn');
    if (!btn) return;
    $$('.tab-btn', bar).forEach(b => b.classList.toggle('active', b === btn));
    document.querySelectorAll('#view-admin .tab-panel').forEach(p =>
      p.classList.toggle('hidden', p.dataset.panel !== btn.dataset.tab));
    loadAdminTab(btn.dataset.tab);
  });
}

async function loadAdminTab(tab) {
  if (tab === 'cars') await renderAdminCars();
  if (tab === 'bookings') await renderAdminBookings();
  if (tab === 'tariffs') await renderAdminTariffs();
  if (tab === 'users') await renderAdminUsers();
}

/* ---------- Admin: cars ---------- */
async function renderAdminCars() {
  const query = new URLSearchParams();
  if (state.adminSearch) query.set('q', state.adminSearch);
  if (state.adminFilter.carStatus) query.set('status', state.adminFilter.carStatus);
  const cars = await api.get('/api/cars?' + query.toString());

  const pageSize = 8;
  const page = state.adminPage.cars;
  const totalPages = Math.max(1, Math.ceil(cars.length / pageSize));
  const list = cars.slice((page - 1) * pageSize, page * pageSize);

  $('#admin-cars').innerHTML = `
    <div class="table-wrap">
      <div class="table-head">
        <h3>Автомобили (${cars.length})</h3>
        <div class="controls">
          <input placeholder="Поиск по модели/номеру" id="ac-search" value="${escapeHtml(state.adminSearch)}">
          <select id="ac-status">
            <option value="">Все статусы</option>
            <option value="available" ${state.adminFilter.carStatus === 'available' ? 'selected' : ''}>Доступные</option>
            <option value="busy" ${state.adminFilter.carStatus === 'busy' ? 'selected' : ''}>Занятые</option>
            <option value="maintenance" ${state.adminFilter.carStatus === 'maintenance' ? 'selected' : ''}>Обслуживание</option>
          </select>
          <button class="btn btn-primary btn-sm" id="ac-add">+ Добавить авто</button>
        </div>
      </div>
      <table>
        <thead><tr><th>ID</th><th>Модель</th><th>Номер</th><th>Тип</th><th>Цена</th><th>Статус</th><th>Топливо</th><th></th></tr></thead>
        <tbody>
          ${list.map(c => `
            <tr>
              <td>${c.id}</td>
              <td><b>${escapeHtml(c.model)}</b><div class="muted small">${c.year} · ${escapeHtml(c.color)}</div></td>
              <td><code>${escapeHtml(c.plate)}</code></td>
              <td>${c.type}<div class="muted small">${c.transmission}</div></td>
              <td><span style="color:var(--accent);font-weight:700">${c.pricePerMin} ₽</span>/мин</td>
              <td><span class="status-pill status-${c.status === 'available' ? 'available' : c.status === 'maintenance' ? 'maintenance' : 'busy'}">${c.status}</span></td>
              <td>${c.fuel} · ${c.fuelLevel}%</td>
              <td class="actions-cell">
                <button class="btn btn-ghost btn-sm" data-act="edit" data-id="${c.id}">✏</button>
                <button class="btn btn-danger btn-sm" data-act="del" data-id="${c.id}">🗑</button>
              </td>
            </tr>
          `).join('') || '<tr><td colspan="8" class="muted" style="text-align:center;padding:30px">Автомобили не найдены</td></tr>'}
        </tbody>
      </table>
      ${totalPages > 1 ? `<div class="pagination">${Array.from({ length: totalPages }, (_, i) => `<button ${i + 1 === page ? 'class="active"' : ''} data-pg="${i + 1}">${i + 1}</button>`).join('')}</div>` : ''}
    </div>
  `;

  const reload = () => renderAdminCars();
  $('#ac-search').addEventListener('input', e => { state.adminSearch = e.target.value; state.adminPage.cars = 1; reload(); });
  $('#ac-status').addEventListener('change', e => { state.adminFilter.carStatus = e.target.value; state.adminPage.cars = 1; reload(); });
  $('#ac-add').addEventListener('click', () => openCarEditor());
  $$('#admin-cars [data-pg]').forEach(b => b.addEventListener('click', () => { state.adminPage.cars = +b.dataset.pg; reload(); }));
  $$('#admin-cars [data-act="edit"]').forEach(b => b.addEventListener('click', () => openCarEditor(+b.dataset.id)));
  $$('#admin-cars [data-act="del"]').forEach(b => b.addEventListener('click', async () => {
    if (!confirm('Удалить автомобиль?')) return;
    try { await api.del('/api/cars/' + b.dataset.id); toast('Автомобиль удалён', 'success'); state.cars = await api.get('/api/cars'); reload(); }
    catch (err) { toast(err.message, 'error'); }
  }));
}

function openCarEditor(id = null) {
  const car = id ? state.cars.find(c => c.id === id) : null;
  const c = car || { model: '', plate: '', type: 'Эконом', transmission: 'Автомат', fuel: 'Бензин', fuelLevel: 100, pricePerMin: 9, lat: NOVGOROD.lat, lng: NOVGOROD.lng, status: 'available', year: 2023, color: 'Белый' };
  const modal = openModal(`
    <h2>${car ? 'Редактирование' : 'Новый'} автомобиль</h2>
    <p class="sub">Заполните характеристики</p>
    <form id="car-form">
      <div class="form-grid">
        <div class="field"><label>Модель</label><input name="model" value="${escapeHtml(c.model)}" required></div>
        <div class="field"><label>Госномер</label><input name="plate" value="${escapeHtml(c.plate)}" required></div>
        <div class="field"><label>Тип</label>
          <select name="type">${['Эконом', 'Комфорт', 'Бизнес', 'Внедорожник', 'Электро'].map(t => `<option ${t === c.type ? 'selected' : ''}>${t}</option>`).join('')}</select>
        </div>
        <div class="field"><label>Коробка</label>
          <select name="transmission">${['Автомат', 'Механика'].map(t => `<option ${t === c.transmission ? 'selected' : ''}>${t}</option>`).join('')}</select>
        </div>
        <div class="field"><label>Топливо</label>
          <select name="fuel">${['Бензин', 'Дизель', 'Электро'].map(t => `<option ${t === c.fuel ? 'selected' : ''}>${t}</option>`).join('')}</select>
        </div>
        <div class="field"><label>Уровень, %</label><input type="number" name="fuelLevel" min="0" max="100" value="${c.fuelLevel}"></div>
        <div class="field"><label>Цена, ₽/мин</label><input type="number" name="pricePerMin" min="1" value="${c.pricePerMin}"></div>
        <div class="field"><label>Год</label><input type="number" name="year" value="${c.year}"></div>
        <div class="field"><label>Цвет</label><input name="color" value="${escapeHtml(c.color)}"></div>
        <div class="field"><label>Статус</label>
          <select name="status">
            <option value="available" ${c.status === 'available' ? 'selected' : ''}>Доступен</option>
            <option value="busy" ${c.status === 'busy' ? 'selected' : ''}>Занят</option>
            <option value="maintenance" ${c.status === 'maintenance' ? 'selected' : ''}>Обслуживание</option>
          </select>
        </div>
        <div class="field"><label>Широта</label><input name="lat" value="${c.lat}"></div>
        <div class="field"><label>Долгота</label><input name="lng" value="${c.lng}"></div>
      </div>
      <div class="modal-actions">
        <button type="button" class="btn btn-ghost" data-act="cancel">Отмена</button>
        <button type="submit" class="btn btn-primary">Сохранить</button>
      </div>
    </form>
  `);
  modal.querySelector('[data-act="cancel"]').addEventListener('click', closeModal);
  modal.querySelector('#car-form').addEventListener('submit', async e => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const data = Object.fromEntries(fd);
    ['fuelLevel', 'pricePerMin', 'year', 'lat', 'lng'].forEach(k => data[k] = +data[k]);
    try {
      if (car) await api.put('/api/cars/' + car.id, data);
      else await api.post('/api/cars', data);
      closeModal();
      toast('Автомобиль сохранён', 'success');
      state.cars = await api.get('/api/cars');
      renderAdminCars();
    } catch (err) { toast(err.message, 'error'); }
  });
}

/* ---------- Admin: bookings ---------- */
async function renderAdminBookings() {
  const all = await api.get('/api/bookings');
  const statusFilter = state.adminFilter.bookingStatus;
  const search = state.adminSearch.toLowerCase();
  const bookings = all.filter(b => {
    if (statusFilter && b.status !== statusFilter) return false;
    if (search) {
      const hay = `${b.id} ${b.user?.name || ''} ${b.user?.email || ''} ${b.car?.model || ''} ${b.car?.plate || ''}`.toLowerCase();
      if (!hay.includes(search)) return false;
    }
    return true;
  });
  const pageSize = 10;
  const page = state.adminPage.bookings;
  const totalPages = Math.max(1, Math.ceil(bookings.length / pageSize));
  const list = bookings.slice((page - 1) * pageSize, page * pageSize);

  $('#admin-bookings').innerHTML = `
    <div class="table-wrap">
      <div class="table-head">
        <h3>Аренды (${bookings.length})</h3>
        <div class="controls">
          <input id="ab-search" placeholder="Поиск..." value="${escapeHtml(state.adminSearch)}">
          <select id="ab-status">
            <option value="">Все статусы</option>
            <option value="confirmed" ${statusFilter === 'confirmed' ? 'selected' : ''}>Подтверждена</option>
            <option value="active" ${statusFilter === 'active' ? 'selected' : ''}>Активна</option>
            <option value="completed" ${statusFilter === 'completed' ? 'selected' : ''}>Завершена</option>
            <option value="cancelled" ${statusFilter === 'cancelled' ? 'selected' : ''}>Отменена</option>
          </select>
        </div>
      </div>
      <table>
        <thead><tr><th>ID</th><th>Пользователь</th><th>Автомобиль</th><th>Период</th><th>Стоимость</th><th>Статус</th><th></th></tr></thead>
        <tbody>
          ${list.map(b => `
            <tr>
              <td>#${b.id}</td>
              <td>${b.user ? escapeHtml(b.user.name) : '—'}<div class="muted small">${b.user ? escapeHtml(b.user.email) : ''}</div></td>
              <td>${b.car ? escapeHtml(b.car.model) : '—'}<div class="muted small">${b.car ? escapeHtml(b.car.plate) : ''}</div></td>
              <td>${fmtDateTime(b.start)}<div class="muted small">${fmtDateTime(b.end)}</div></td>
              <td><span style="color:var(--accent);font-weight:700">${fmtMoney(b.total)}</span></td>
              <td><span class="status-pill status-${b.status === 'cancelled' ? 'busy' : b.status === 'completed' ? 'maintenance' : 'available'}">${b.status}</span></td>
              <td class="actions-cell">
                <button class="btn btn-ghost btn-sm" data-act="edit" data-id="${b.id}">✏</button>
                <button class="btn btn-danger btn-sm" data-act="del" data-id="${b.id}">🗑</button>
              </td>
            </tr>
          `).join('') || '<tr><td colspan="7" class="muted" style="text-align:center;padding:30px">Нет аренд</td></tr>'}
        </tbody>
      </table>
      ${totalPages > 1 ? `<div class="pagination">${Array.from({ length: totalPages }, (_, i) => `<button ${i + 1 === page ? 'class="active"' : ''} data-pg="${i + 1}">${i + 1}</button>`).join('')}</div>` : ''}
    </div>
  `;

  const reload = () => renderAdminBookings();
  $('#ab-search').addEventListener('input', e => { state.adminSearch = e.target.value; state.adminPage.bookings = 1; reload(); });
  $('#ab-status').addEventListener('change', e => { state.adminFilter.bookingStatus = e.target.value; state.adminPage.bookings = 1; reload(); });
  $$('#admin-bookings [data-pg]').forEach(b => b.addEventListener('click', () => { state.adminPage.bookings = +b.dataset.pg; reload(); }));
  $$('#admin-bookings [data-act="edit"]').forEach(b => b.addEventListener('click', () => openBookingEditor(all.find(x => x.id === +b.dataset.id))));
  $$('#admin-bookings [data-act="del"]').forEach(b => b.addEventListener('click', async () => {
    if (!confirm('Удалить аренду?')) return;
    try { await api.del('/api/bookings/' + b.dataset.id); toast('Аренда удалена', 'success'); reload(); }
    catch (err) { toast(err.message, 'error'); }
  }));
}

function openBookingEditor(b) {
  const modal = openModal(`
    <h2>Аренда № ${b.id}</h2>
    <p class="sub">Редактирование параметров</p>
    <form id="booking-form">
      <div class="form-grid">
        <div class="field"><label>Дата начала</label><input type="datetime-local" name="start" value="${toLocalInput(b.start)}"></div>
        <div class="field"><label>Дата окончания</label><input type="datetime-local" name="end" value="${toLocalInput(b.end)}"></div>
        <div class="field"><label>Статус</label>
          <select name="status">
            ${['confirmed', 'active', 'completed', 'cancelled'].map(s => `<option value="${s}" ${s === b.status ? 'selected' : ''}>${s}</option>`).join('')}
          </select>
        </div>
        <div class="field"><label>Стоимость, ₽</label><input type="number" name="total" value="${b.total}"></div>
      </div>
      <div class="modal-actions">
        <button type="button" class="btn btn-ghost" data-act="cancel">Отмена</button>
        <button type="submit" class="btn btn-primary">Сохранить</button>
      </div>
    </form>
  `);
  modal.querySelector('[data-act="cancel"]').addEventListener('click', closeModal);
  modal.querySelector('#booking-form').addEventListener('submit', async e => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const data = Object.fromEntries(fd);
    data.total = +data.total;
    try {
      await api.put('/api/bookings/' + b.id, data);
      closeModal();
      toast('Аренда обновлена', 'success');
      renderAdminBookings();
    } catch (err) { toast(err.message, 'error'); }
  });
}

/* ---------- Admin: tariffs ---------- */
async function renderAdminTariffs() {
  if (!state.tariffs.length) state.tariffs = await api.get('/api/tariffs');
  const tariffs = state.tariffs;
  $('#admin-tariffs').innerHTML = `
    <div class="table-wrap">
      <div class="table-head">
        <h3>Тарифы (${tariffs.length})</h3>
        <button class="btn btn-primary btn-sm" id="at-add">+ Новый тариф</button>
      </div>
      <table>
        <thead><tr><th>Название</th><th>Цена</th><th>Описание</th><th></th></tr></thead>
        <tbody>
          ${tariffs.map(t => `
            <tr>
              <td><b>${escapeHtml(t.name)}</b><div class="muted small">${t.key}</div></td>
              <td><span style="color:var(--accent);font-weight:700">${t.price} ${escapeHtml(t.unit || '')}</span></td>
              <td class="muted small">${escapeHtml((t.desc || '').slice(0, 80))}${(t.desc || '').length > 80 ? '…' : ''}</td>
              <td class="actions-cell">
                <button class="btn btn-ghost btn-sm" data-act="edit" data-id="${t.id}">✏</button>
                <button class="btn btn-danger btn-sm" data-act="del" data-id="${t.id}">🗑</button>
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>
  `;
  $('#at-add').addEventListener('click', () => openTariffEditor());
  $$('#admin-tariffs [data-act="edit"]').forEach(b => b.addEventListener('click', () => openTariffEditor(tariffs.find(x => x.id === +b.dataset.id))));
  $$('#admin-tariffs [data-act="del"]').forEach(b => b.addEventListener('click', async () => {
    if (!confirm('Удалить тариф?')) return;
    try { await api.del('/api/tariffs/' + b.dataset.id); state.tariffs = []; toast('Удалено', 'success'); renderAdminTariffs(); }
    catch (err) { toast(err.message, 'error'); }
  }));
}

function openTariffEditor(t = null) {
  const x = t || { name: '', key: '', price: 0, unit: '₽/мин', desc: '', conditions: '', highlight: false };
  const modal = openModal(`
    <h2>${t ? 'Редактирование' : 'Новый'} тариф</h2>
    <form id="tariff-form">
      <div class="form-grid">
        <div class="field"><label>Название</label><input name="name" value="${escapeHtml(x.name)}" required></div>
        <div class="field"><label>Ключ</label><input name="key" value="${escapeHtml(x.key)}" ${t ? 'disabled' : 'required'}></div>
        <div class="field"><label>Цена</label><input type="number" name="price" value="${x.price}" required></div>
        <div class="field"><label>Единица</label><input name="unit" value="${escapeHtml(x.unit)}"></div>
        <div class="field full"><label>Описание</label><textarea name="desc" rows="2">${escapeHtml(x.desc)}</textarea></div>
        <div class="field full"><label>Условия</label><textarea name="conditions" rows="2">${escapeHtml(x.conditions)}</textarea></div>
      </div>
      <div class="modal-actions">
        <button type="button" class="btn btn-ghost" data-act="cancel">Отмена</button>
        <button type="submit" class="btn btn-primary">Сохранить</button>
      </div>
    </form>
  `);
  modal.querySelector('[data-act="cancel"]').addEventListener('click', closeModal);
  modal.querySelector('#tariff-form').addEventListener('submit', async e => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const data = Object.fromEntries(fd);
    data.price = +data.price;
    try {
      if (t) await api.put('/api/tariffs/' + t.id, data);
      else await api.post('/api/tariffs', data);
      closeModal();
      state.tariffs = [];
      toast('Тариф сохранён', 'success');
      renderAdminTariffs();
    } catch (err) { toast(err.message, 'error'); }
  });
}

/* ---------- Admin: users ---------- */
async function renderAdminUsers() {
  const users = await api.get('/api/admin/users');
  const search = state.adminSearch.toLowerCase();
  const filtered = users.filter(u =>
    !search || `${u.name} ${u.email} ${u.phone || ''}`.toLowerCase().includes(search)
  );
  const pageSize = 10;
  const page = state.adminPage.users;
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const list = filtered.slice((page - 1) * pageSize, page * pageSize);

  $('#admin-users').innerHTML = `
    <div class="table-wrap">
      <div class="table-head">
        <h3>Пользователи (${filtered.length})</h3>
        <input id="au-search" placeholder="Поиск..." value="${escapeHtml(state.adminSearch)}">
      </div>
      <table>
        <thead><tr><th>ID</th><th>Имя</th><th>Контакты</th><th>Роль</th><th>Баланс</th><th></th></tr></thead>
        <tbody>
          ${list.map(u => `
            <tr>
              <td>${u.id}</td>
              <td><b>${escapeHtml(u.name)}</b><div class="muted small">ВУ ${escapeHtml(u.license || '—')}</div></td>
              <td>${escapeHtml(u.email)}<div class="muted small">${escapeHtml(u.phone || '')}</div></td>
              <td><span class="status-pill status-${u.role === 'admin' ? 'busy' : 'available'}">${u.role}</span></td>
              <td>${fmtMoney(u.balance || 0)}</td>
              <td class="actions-cell">
                <button class="btn btn-ghost btn-sm" data-act="edit" data-id="${u.id}">✏</button>
                <button class="btn btn-danger btn-sm" data-act="del" data-id="${u.id}" ${u.role === 'admin' ? 'disabled' : ''}>🗑</button>
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
      ${totalPages > 1 ? `<div class="pagination">${Array.from({ length: totalPages }, (_, i) => `<button ${i + 1 === page ? 'class="active"' : ''} data-pg="${i + 1}">${i + 1}</button>`).join('')}</div>` : ''}
    </div>
  `;

  const reload = () => renderAdminUsers();
  $('#au-search').addEventListener('input', e => { state.adminSearch = e.target.value; state.adminPage.users = 1; reload(); });
  $$('#admin-users [data-pg]').forEach(b => b.addEventListener('click', () => { state.adminPage.users = +b.dataset.pg; reload(); }));
  $$('#admin-users [data-act="edit"]').forEach(b => b.addEventListener('click', () => openUserEditor(users.find(x => x.id === +b.dataset.id))));
  $$('#admin-users [data-act="del"]').forEach(b => b.addEventListener('click', async () => {
    if (!confirm('Удалить пользователя?')) return;
    try { await api.del('/api/admin/users/' + b.dataset.id); toast('Пользователь удалён', 'success'); reload(); }
    catch (err) { toast(err.message, 'error'); }
  }));
}

function openUserEditor(u) {
  const modal = openModal(`
    <h2>Пользователь: ${escapeHtml(u.name)}</h2>
    <p class="sub">${escapeHtml(u.email)}</p>
    <form id="user-form">
      <div class="form-grid">
        <div class="field"><label>Имя</label><input name="name" value="${escapeHtml(u.name)}" required></div>
        <div class="field"><label>Телефон</label><input name="phone" value="${escapeHtml(u.phone || '')}"></div>
        <div class="field"><label>Роль</label>
          <select name="role">
            <option value="user" ${u.role === 'user' ? 'selected' : ''}>user</option>
            <option value="admin" ${u.role === 'admin' ? 'selected' : ''}>admin</option>
          </select>
        </div>
        <div class="field"><label>ВУ</label><input name="license" value="${escapeHtml(u.license || '')}"></div>
        <div class="field full"><label>Баланс, ₽</label><input type="number" name="balance" value="${u.balance || 0}"></div>
      </div>
      <div class="modal-actions">
        <button type="button" class="btn btn-ghost" data-act="cancel">Отмена</button>
        <button type="submit" class="btn btn-primary">Сохранить</button>
      </div>
    </form>
  `);
  modal.querySelector('[data-act="cancel"]').addEventListener('click', closeModal);
  modal.querySelector('#user-form').addEventListener('submit', async e => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const data = Object.fromEntries(fd);
    data.balance = +data.balance;
    try {
      await api.put('/api/admin/users/' + u.id, data);
      closeModal();
      toast('Пользователь обновлён', 'success');
      renderAdminUsers();
    } catch (err) { toast(err.message, 'error'); }
  });
}

/* ============================================================
   Init
   ============================================================ */
function initNav() {
  const burger = $('#burger');
  const nav = $('#main-nav');
  burger.addEventListener('click', () => {
    nav.classList.toggle('open');
    burger.classList.toggle('open');
  });
  $('#year').textContent = new Date().getFullYear();
  $$('a[href="#/landing#how"]').forEach(a => a.addEventListener('click', () => {
    setTimeout(() => $('#how')?.scrollIntoView({ behavior: 'smooth' }), 100);
  }));
}

(async function init() {
  initNav();
  initAuthForms();
  await loadMe();
  renderHeaderUser();
  await renderRoute();
})();